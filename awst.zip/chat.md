# Exportación de chat de WhatsApp: +57 311 7301724
Fecha de exportación: 10 de septiembre de 2026 a las 10:39 p. m.

---

## 23 de julio de 2026

[3:01 p. m.] __[Llamada]__

[3:02 p. m.] __[Llamada]__

---

## 25 de julio de 2026

[5:49 p. m.] __[Llamada]__

---

## 5 de agosto de 2026

[7:49 p. m.] **Tú:** Cómprese la crema chantilli

[7:49 p. m.] **Tú:** Y aca se la come

[7:49 p. m.] **Tú:** [Sticker]

[7:49 p. m.] **Vale 🌙:** [Mensaje de voz]

[7:49 p. m.] **Tú:** Me hubiera dicho

[7:49 p. m.] **Tú:** Ahh pero igual mañana  no trabajas

[7:50 p. m.] **Tú:** Mañana  vamos

[7:50 p. m.] **Vale 🌙:**
> _Tú: Ahh pero igual mañana  no trabajas_
Nop

[7:50 p. m.] **Vale 🌙:**
> _Tú: Mañana  vamos_
Meno

[7:51 p. m.] **Vale 🌙:** [Mensaje de voz]

[7:51 p. m.] **Vale 🌙:** Me abres

[7:51 p. m.] **Vale 🌙:** [Sticker]

[8:53 p. m.] **Tú:** Salgaa

[8:54 p. m.] **Tú:** Después le mete un susto

[8:54 p. m.] **Vale 🌙:** Jsjsjs

---

## 6 de agosto de 2026

[12:22 p. m.] **Tú:** Cuánto vale la pastilla

[12:22 p. m.] **Tú:** Para que compres una

[12:22 p. m.] **Tú:** [Sticker]

[12:26 p. m.] **Vale 🌙:** 18

[12:26 p. m.] **Tú:** Ihs

[12:26 p. m.] **Tú:** Cono iva

[12:26 p. m.] **Tú:** Ya se los paso tonces

[12:26 p. m.] **Vale 🌙:** Vale amor

[12:38 p. m.] **Tú:** https://www.instagram.com/reel/DbfxfegvEDa/?igsh=eXppMDRtam5pcnds

[12:39 p. m.] **Tú:** https://www.instagram.com/reel/DU9xNCuE4LB/?igsh=MTFpOTAwYnBxMmZsOA==

[12:39 p. m.] **Vale 🌙:**
> _Tú: https://www.instagram.com/reel/DbfxfegvEDa/?igsh=eXppMDRtam5pcnds_
[Mensaje de voz]

[12:40 p. m.] **Tú:** https://www.instagram.com/reel/DaISEjcxmYL/?igsh=eW1vNWhrejBnNzg2

[12:41 p. m.] **Tú:** https://www.instagram.com/reel/DYYGV5oye2s/?igsh=cmZnejZ4N3BiOXYx

[12:41 p. m.] **Tú:** https://www.instagram.com/reel/DbrKF4OpKi0/?igsh=NHJocmU0em5xaW0x

[12:43 p. m.] **Tú:** https://www.instagram.com/reel/DaRkr4qhfMW/?igsh=MWUzYnY1emozZjEwdA==

[12:43 p. m.] **Vale 🌙:**
> _Tú: https://www.instagram.com/reel/DYYGV5oye2s/?igsh=cmZnejZ4N3BiOXYx_
Y si

[12:43 p. m.] **Vale 🌙:**
> _Tú: https://www.instagram.com/reel/DaRkr4qhfMW/?igsh=MWUzYnY1emozZjEwdA==_
[Mensaje de voz]

[12:43 p. m.] **Tú:** https://www.instagram.com/reel/DZoNqT-Rul0/?igsh=MW04bWg3aXFyYW1lZQ==

[12:44 p. m.] **Vale 🌙:**
> _Tú: https://www.instagram.com/reel/DZoNqT-Rul0/?igsh=MW04bWg3aXFyYW1lZQ==_
[Mensaje de voz]

[12:45 p. m.] **Tú:** https://www.instagram.com/reel/DZNQdV5ydza/?igsh=MWg3OHpqeTVsbWNqZA==

[12:46 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Miralo todo

[12:47 p. m.] **Tú:** https://www.instagram.com/reel/DYcobXDBxAs/?igsh=MXh6NWJtbnRlZzVsZQ==

[12:47 p. m.] **Vale 🌙:**
> _Tú: Miralo todo_
[Mensaje de voz]

[12:47 p. m.] **Vale 🌙:**
> _Tú: https://www.instagram.com/reel/DZNQdV5ydza/?igsh=MWg3OHpqeTVsbWNqZA==_
🤣🤣

[12:47 p. m.] **Tú:** https://www.instagram.com/reel/DZqmgSqxQvM/?igsh=MWtoaGMyZDJ3b3ZsNQ==

[12:48 p. m.] **Tú:** https://www.instagram.com/reel/DY0YCC0xonC/?igsh=NXpvb2p4YXFjbWly

[12:50 p. m.] **Vale 🌙:**
> _Tú: https://www.instagram.com/reel/DY0YCC0xonC/?igsh=NXpvb2p4YXFjbWly_
🤣🤣🤣

[12:50 p. m.] **Tú:** https://www.instagram.com/reel/DayWUw7RYS7/?igsh=MWs2Z2xtMmZuY20xdA==

[12:50 p. m.] **Vale 🌙:**
> _Tú: https://www.instagram.com/reel/DayWUw7RYS7/?igsh=MWs2Z2xtMmZuY20xdA==_
[Mensaje de voz]

[12:52 p. m.] **Tú:** https://www.instagram.com/reel/DaB0Wttslqd/?igsh=MWp5b3ByZ3JwZjFmcA==

[12:53 p. m.] **Vale 🌙:**
> _Tú: https://www.instagram.com/reel/DaB0Wttslqd/?igsh=MWp5b3ByZ3JwZjFmcA==_
Yo cuando me enojo

[12:55 p. m.] **Tú:** https://www.instagram.com/reel/DawHGtIil3a/?igsh=MTNzcGl0ZzN4MGR6ag==

[12:58 p. m.] **Tú:** https://www.instagram.com/reel/DaITG_0x4oM/?igsh=YWsxZG85Mm9iMWZn

[1:00 p. m.] **Vale 🌙:** Ya miro que pague la pastilla y me quedé sin megas

[1:01 p. m.] **Tú:** https://www.instagram.com/reel/DbMjrO2zEv9/?igsh=MXFhajV6amxxOW5obw==

[1:05 p. m.] **Tú:** https://www.instagram.com/reel/DaJEitwJDWX/?igsh=emE5MnloMmg2c3N1

[1:06 p. m.] **Tú:** https://www.instagram.com/reel/DWo_mmjFT9K/?igsh=MXQxZG53b2x2d2x3MA==

[1:07 p. m.] **Tú:** https://www.instagram.com/reel/Dbop5lSjKg9/?igsh=MWFscHAzZDQ5N3hraQ==

[1:08 p. m.] **Tú:** https://www.instagram.com/reel/DYkliGVsYj_/?igsh=MXdyajAwazAycm0zZg==

[1:09 p. m.] **Tú:** https://www.instagram.com/reel/DZlVkxMvHhl/?igsh=cXhoZXJmY3RhNmNw

[1:13 p. m.] **Tú:** https://www.instagram.com/reel/DZ-nveFRCbs/?igsh=MXd3eGQ0cGhjYW1sMg==

[1:15 p. m.] **Tú:** https://www.instagram.com/reel/Dbr2iZUpzMe/?igsh=emFoYWJvamE2bWw1

[1:58 p. m.] **Tú:** https://www.instagram.com/reel/Dacy-sexUBj/?igsh=MWtrcXZ0ZWtjcmd3Yg==

[2:07 p. m.] **Tú:** https://www.instagram.com/reel/DaMoCFDu8Im/?igsh=MXQxaTY2ajVjdWQwNg==

[2:08 p. m.] **Tú:** https://www.instagram.com/reel/DZ48K8MONdV/?igsh=aTVxNWN0eDNrbTAz

[3:33 p. m.] **Tú:** Holaaa

[3:33 p. m.] **Tú:** Me dio pereza ir

[3:33 p. m.] **Tú:** Jajaja

[3:33 p. m.] **Tú:** Que haces

[3:36 p. m.] **Vale 🌙:** Cuidado alas bbs

[3:36 p. m.] **Tú:** Me vas acompañar a sacarle unas copias a mi mamá

[3:37 p. m.] **Tú:** Se me está dañando el control

[3:38 p. m.] **Tú:** [Imagen]

[3:38 p. m.] **Tú:** Necesito esa palanquita

[3:38 p. m.] **Tú:** Gotda

[3:38 p. m.] **Tú:** Tú estás cerca de la papeleria

[3:38 p. m.] **Tú:** Puedes ver si está abierta

[4:43 p. m.] **Vale 🌙:** No flaco yo estoy en suba mi prima vive acá

[4:47 p. m.] **Tú:** Flaco

[4:47 p. m.] **Tú:** Jum

[4:47 p. m.] **Tú:** Po lo menos que me responda Valentina

[4:47 p. m.] **Tú:** [Sticker]

[4:55 p. m.] **Vale 🌙:** Amor no tengo megas por eso no e respondido los reels

[4:55 p. m.] **Vale 🌙:** Y las niñas están molestando

[5:03 p. m.] **Vale 🌙:**
> _Tú: https://www.instagram.com/reel/DawHGtIil3a/?igsh=MTNzcGl0ZzN4MGR6ag==_
Soy

[5:05 p. m.] **Vale 🌙:**
> _Tú: https://www.instagram.com/reel/DWo_mmjFT9K/?igsh=MXQxZG53b2x2d2x3MA==_
En la vida soy esa

[5:05 p. m.] **Vale 🌙:**
> _Tú: https://www.instagram.com/reel/DYkliGVsYj_/?igsh=MXdyajAwazAycm0zZg==_
Osea si pero donde sea linda

[5:07 p. m.] **Vale 🌙:** https://www.instagram.com/reel/DawVAgAOkJI

[5:09 p. m.] **Vale 🌙:**
> _Tú: https://www.instagram.com/reel/DZ48K8MONdV/?igsh=aTVxNWN0eDNrbTAz_
Jsgsjs

[5:11 p. m.] **Vale 🌙:** https://www.instagram.com/reel/Dbq1PL6J8_c

[5:13 p. m.] **Tú:** Y vos volves

[5:13 p. m.] **Tú:** Hoy

[5:13 p. m.] **Tú:** Eso de estar por alla

[5:13 p. m.] **Tú:** Ya me está dando como celos

[5:13 p. m.] **Tú:** [Sticker]

[5:13 p. m.] **Tú:** [Sticker]

[5:13 p. m.] **Vale 🌙:** Sip

[5:13 p. m.] **Vale 🌙:** Estoy esperando que llegue mi tía con mi prima

[5:14 p. m.] **Vale 🌙:** Una de las chiquis ya se durmió la terremo si anda por hay

[5:14 p. m.] **Vale 🌙:** https://www.instagram.com/reel/DVNrJs-AH-a

[7:14 p. m.] **Tú:** Cómo vas

[7:15 p. m.] **Tú:** No me da batalla

[7:15 p. m.] **Tú:** Tengo una escondids

[7:26 p. m.] **Tú:** Quédate hoy

[7:26 p. m.] **Tú:** Y traes para que te cambies y eso para que mañana vayas al trabajo

[7:32 p. m.] **Vale 🌙:**
> _Tú: Tengo una escondids_
Que

[7:37 p. m.] **Tú:**
> _Vale 🌙: Que_
Que toca comprarlas

[7:37 p. m.] **Tú:** Primero

[7:42 p. m.] **Tú:** Cómo vas ya saliste de allá, cómo le fue a tu prima

[7:45 p. m.] **Vale 🌙:**
> _Tú: Cómo vas ya saliste de allá, cómo le fue a tu prima_
Bien ahorita el tema es la recuperación

[7:50 p. m.] **Tú:** Y que le hicieron

[7:50 p. m.] **Tú:**
> _Vale 🌙: Bien ahorita el tema es la recuperación_
Pero ya llegó a la casa

[7:50 p. m.] **Tú:** Está bien

[7:58 p. m.] **Tú:** Entonces mi reina

[7:59 p. m.] **Tú:** _Esperando el mensaje… Esto puede demorar un poco._

[7:59 p. m.] **Tú:** _Esperando el mensaje… Esto puede demorar un poco._

[8:01 p. m.] **Vale 🌙:**
> _Tú: Pero ya llegó a la casa_
Si amor mio

[8:01 p. m.] **Tú:**
> _Vale 🌙: Si amor mio_
Y hoy si me vienes arrunchar

[8:01 p. m.] **Tú:** [Sticker]

[8:09 p. m.] **Vale 🌙:** Amor yo la verdad ahorita estoy molida de cuidar enanas

[8:09 p. m.] **Tú:** Amor

[8:09 p. m.] **Tú:** Pues ven y descnasas

[8:09 p. m.] **Tú:** Mi mami llega tarde hoy

[8:09 p. m.] **Tú:** [Sticker]

[8:09 p. m.] **Vale 🌙:** Aparte tu quieres estar dándole. Cad rato y yo ya no puedo más

[8:09 p. m.] **Tú:**
> _Vale 🌙: Aparte tu quieres estar dándole. Cad rato y yo ya no puedo más_
No

[8:09 p. m.] **Tú:** Ya mucho

[8:09 p. m.] **Tú:** También me duele la picha

[8:10 p. m.] **Tú:** Vente pa que duermas acaaaa

[8:10 p. m.] **Tú:** Está haciendo frío aparecme sirve que estés acá calientita

[8:10 p. m.] **Tú:** [Sticker]

[8:12 p. m.] **Tú:** Solo

[8:12 p. m.] **Tú:** Siii

[8:12 p. m.] **Tú:** [Sticker]

[8:13 p. m.] **Vale 🌙:** [Mensaje de voz]

[8:13 p. m.] **Tú:** Encerioo

[8:13 p. m.] **Tú:** Le propongo

[8:13 p. m.] **Tú:** Cómo se que no va a pasar nada

[8:14 p. m.] **Tú:** Pero si pasa algo le doy un peluche bien bonito antes de que se vaya

[8:14 p. m.] **Tú:** Si no pues uno más pequeño por temas de presupuesto

[8:14 p. m.] **Tú:** [Sticker]

[8:14 p. m.] **Tú:** Hágale a ver qué tengo frioooo

[8:15 p. m.] **Vale 🌙:** [Mensaje de voz]

[8:15 p. m.] **Tú:** Pureleee

[8:15 p. m.] **Tú:** Acá tiene una pijama

[8:15 p. m.] **Tú:** Y a mí

[8:15 p. m.] **Vale 🌙:** [Mensaje de voz]

[8:15 p. m.] **Tú:** Pero está haciendo mucho frío

[8:16 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Sáquele copia y la deja acá

[8:16 p. m.] **Tú:** Jsjsj

[8:16 p. m.] **Tú:** Ósea estás en tu casa

[8:16 p. m.] **Vale 🌙:**
> _Tú: Sáquele copia y la deja acá_
Va tocar

[8:16 p. m.] **Tú:** De acá a que lleguen le da sueño

[8:16 p. m.] **Tú:** [Sticker]

[8:16 p. m.] **Vale 🌙:**
> _Tú: Ósea estás en tu casa_
[Mensaje de video]

[8:17 p. m.] **Vale 🌙:**
> _Tú: De acá a que lleguen le da sueño_
[Mensaje de voz]

[8:17 p. m.] **Tú:** Llegueee

[8:17 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Ya bien

[8:17 p. m.] **Tú:** Tráeme algo pa la picha me duele y el dedo también jajaja

[8:17 p. m.] **Vale 🌙:**
> _Tú: Tráeme algo pa la picha me duele y el dedo también jajaja_
A mi también me duele la cuca  jshs

[8:30 p. m.] **Tú:** Avisas pa abrirte

[8:30 p. m.] **Tú:** Ya me está dando sueñito

[8:30 p. m.] **Vale 🌙:** [Mensaje de voz]

[8:31 p. m.] **Tú:** Bueno no se duerma

[8:31 p. m.] **Tú:** Que estamos igual

[8:32 p. m.] **Vale 🌙:** Meno

[8:34 p. m.] **Tú:** Tienes pa traer alguito

[8:34 p. m.] **Tú:** Gomitas o algo

[8:34 p. m.] **Vale 🌙:** No amor lo que tenía se los preste ami tia

[8:34 p. m.] **Tú:** Pa otro día porque ya no tengo nada en nequi

[8:35 p. m.] **Vale 🌙:** Aunque voy a ver en el monedero si tengo algo

[9:26 p. m.] **Vale 🌙:** No amor ya está re tarde  apenas llegaron

[9:27 p. m.] **Vale 🌙:** Te dormiste

[9:27 p. m.] **Vale 🌙:** Descansa mi bb

[9:27 p. m.] **Vale 🌙:** [Sticker]

[9:40 p. m.] **Tú:** Nooo

[9:40 p. m.] **Tú:** Estaba descansando los pjps

[9:40 p. m.] **Tú:** Tú verás mi mamá apenas salió de all

[9:40 p. m.] **Tú:** Yo voy a esperar a que llegir

[9:41 p. m.] **Tú:** Por eso solo digo

[9:41 p. m.] **Vale 🌙:** Dame 5 que se fueron a buscar a a es china

[9:54 p. m.] **Vale 🌙:** Amorr

[9:54 p. m.] **Tú:** Cuéntamelos

[9:55 p. m.] **Vale 🌙:** Ya toy en tu cuadra

[9:56 p. m.] **Vale 🌙:** Abreme

[9:57 p. m.] **Vale 🌙:** [Sticker]

---

## 7 de agosto de 2026

[3:27 p. m.] **Vale 🌙:** Holi amor

[3:27 p. m.] **Tú:** Holaaa

[3:27 p. m.] **Tú:** Gotda que haces

[3:29 p. m.] **Vale 🌙:** Nada amor acabo de llegar

[3:36 p. m.] **Tú:** A tu casa

[3:36 p. m.] **Tú:** Cómo te fue

[3:41 p. m.] **Vale 🌙:** Bien amor mio

[3:41 p. m.] **Vale 🌙:**
> _Tú: A tu casa_
Si

[3:45 p. m.] **Tú:** Me alegro

[3:45 p. m.] **Tú:** Hasta cuando trabajas ahí

[4:22 p. m.] **Vale 🌙:**
> _Tú: Hasta cuando trabajas ahí_
el martes

[4:43 p. m.] **Tú:**
> _Vale 🌙: el martes_
Ahí puedes ir guardando plática

[4:43 p. m.] **Tú:** Pa estos días

[4:43 p. m.] **Tú:** Y pues ahorra en dado caso en viaje

[4:52 p. m.] **Vale 🌙:** Nosé amor

[4:57 p. m.] **Tú:** [Video]

[4:57 p. m.] **Tú:** Llevo todo el día acá

[6:26 p. m.] **Vale 🌙:** Como vas

[6:30 p. m.] **Tú:** Apenas la acabo de terminar

[6:30 p. m.] **Tú:** Ya la voy a probar

[6:30 p. m.] **Tú:** Y tu bb como vas

[6:35 p. m.] **Vale 🌙:** Bien amor con dolor de cabeza

[7:19 p. m.] **Tú:** Y eso

[7:19 p. m.] **Tú:** Porque

[7:19 p. m.] **Tú:** Si acá estabas bien domieda

[7:19 p. m.] **Tú:** Dormida

[7:19 p. m.] **Tú:** Mucho estrés hoy

[7:27 p. m.] **Vale 🌙:** Hoy tocó sacar tres eventos

[7:32 p. m.] **Tú:** Uffff

[7:32 p. m.] **Tú:** Re duro

[7:33 p. m.] **Tú:** Pero bueno

[7:33 p. m.] **Tú:** Ya estas desando

[7:33 p. m.] **Tú:** Claro con todo eso que te toco hacer

[7:33 p. m.] **Tú:** Me imagino  el cansancio

[7:44 p. m.] **Vale 🌙:** Sipi

[9:10 p. m.] **Tú:** Como vas

[9:15 p. m.] **Vale 🌙:** Buen mi vida

[10:01 p. m.] **Tú:** Ya mejor del dolor de cabeza

[10:01 p. m.] **Tú:** Mañana ven

[10:01 p. m.] **Tú:** Y pasa un rato acá

[10:01 p. m.] **Tú:** Mi mamá está

[10:01 p. m.] **Tú:** Para que pases con nosotros

[10:02 p. m.] **Vale 🌙:** Vale amor

[10:53 p. m.] **Tú:** Dale bb entonces descansa

---

## 8 de agosto de 2026

[12:22 a. m.] **Tú:** Que haces mi vida

[12:24 a. m.] **Vale 🌙:** No puedo dormir 😔

[12:24 a. m.] **Vale 🌙:** Tengo pesadillas

[12:32 a. m.] **Tú:** Verga y eso

[12:32 a. m.] **Tú:** Preciso hoy que no te quedaste aquí

[12:32 a. m.] **Vale 🌙:** Nosé amor

[12:33 a. m.] **Vale 🌙:**
> _Tú: Preciso hoy que no te quedaste aquí_
Si creo igual voy a tratar de dormir colo sea por que mañana madrugo

[12:40 a. m.] **Tú:** Cierra los ojos quédate así un rato si te pegas al celular no te va a dar sueño

[12:40 a. m.] **Tú:** Ya mañana te quedas si algo

[12:44 a. m.] **Vale 🌙:** Meno amor

[2:43 p. m.] **Vale 🌙:** [Mensaje de voz]

[2:43 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Verga

[2:44 p. m.] **Tú:** Mandas fotos entonces

[2:44 p. m.] **Tú:** Y ya almorzaste y eso

[2:44 p. m.] **Tú:** No te vayas a ir sin comer algo

[2:45 p. m.] **Vale 🌙:**
> _Tú: Y ya almorzaste y eso_
No amor

[2:45 p. m.] **Vale 🌙:**
> _Tú: Mandas fotos entonces_
Tii

[2:46 p. m.] **Tú:**
> _Vale 🌙: No amor_
Y que esperas

[2:46 p. m.] **Tú:** Te sirven 10

[2:46 p. m.] **Tú:** Así sea para un corrientazo

[2:46 p. m.] **Vale 🌙:** [Imagen] Asta mi compañera le tocó ponerse hacer papa para un pure

[2:47 p. m.] **Tú:**
> _Vale 🌙: Imagen: Asta mi compañera le tocó ponerse hacer papa para un pure_
Joa

[2:47 p. m.] **Tú:** Está duro entonces hoy

[2:47 p. m.] **Tú:** Si te los mando o que

[2:47 p. m.] **Tú:** [Imagen]

[2:56 p. m.] **Vale 🌙:**
> _Tú: Está duro entonces hoy_
Horrible mi vida

[2:56 p. m.] **Vale 🌙:**
> _Tú: Imagen_
Y eso amor

[4:18 p. m.] **Tú:** Pa que te compres algo

[4:19 p. m.] **Tú:** No pases hambre

[4:19 p. m.] **Vale 🌙:** Gracias amor mío

[4:19 p. m.] **Vale 🌙:** Ya voy a ver qué como

[4:19 p. m.] **Vale 🌙:** Areglerme y salir

[7:10 p. m.] **Tú:** Vale

[8:30 p. m.] **Vale 🌙:** [Imagen]

[8:30 p. m.] **Vale 🌙:** [Video]

[9:29 p. m.] **Tú:**
> _Vale 🌙: Video_
Aprendiendo a cocinar

[10:01 p. m.] **Vale 🌙:** Yo se cosinar no me gusta hacerlo

[11:03 p. m.] **Tú:** Jsjsjssj

[11:03 p. m.] **Tú:** Toca

[11:03 p. m.] **Tú:** Que le cojas cariño

[11:03 p. m.] **Tú:** Mor

[11:03 p. m.] **Tú:** Izquierda derecha o centro

[11:30 p. m.] **Tú:** Cómo vas princesa

[11:30 p. m.] **Tú:** [Sticker]

[11:33 p. m.] **Tú:** Mir

[11:33 p. m.] **Tú:** Mor

[11:39 p. m.] **Tú:** Amooor

[11:39 p. m.] **Tú:** De esto equivale que tan grande el peluche

[11:39 p. m.] **Tú:**
> _Tú: Izquierda derecha o centro_
…

---

## 9 de agosto de 2026

[12:04 a. m.] **Vale 🌙:** Centro

[12:04 a. m.] **Vale 🌙:** [Mensaje de voz]

[12:04 a. m.] **Tú:**
> _Vale 🌙: Centro_
Jodaaa

[12:05 a. m.] **Tú:** Te puedo pagar el tamaño del peluche con especie

[12:05 a. m.] **Tú:** [Sticker]

[12:05 a. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Ya casi sales menos mal

[12:05 a. m.] **Tú:** Pensé que ibas hasta las 3

[12:05 a. m.] **Tú:** Y donde es el evento

[12:22 a. m.] **Tú:** Me avisas cuando llegues a la casa

[12:22 a. m.] **Tú:** Y cuando salgas

[12:23 a. m.] **Vale 🌙:**
> _Tú: Te puedo pagar el tamaño del peluche con especie_
Nop

[12:23 a. m.] **Vale 🌙:**
> _Tú: Pensé que ibas hasta las 3_
No estamos solo recojiendonlonde la comida todavía falta

[12:23 a. m.] **Tú:**
> _Vale 🌙: Nop_
Mañana  vamos

[12:26 a. m.] **Tú:**
> _Vale 🌙: No estamos solo recojiendonlonde la comida todavía falta_
Ahh

[12:26 a. m.] **Tú:** Yo pensé que ya

[12:27 a. m.] **Tú:** Me avisa

[12:27 a. m.] **Tú:** Igual

[12:29 a. m.] **Vale 🌙:**
> _Tú: Y donde es el evento_
/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAgIDAQEAAAAAAAAAAAAAAwQABgIFBwEI/8QAPBAAAgEDAgQEBAMFBgcAAAAAAQIDAAQRBSEGEhMxIkFRYRQycYEHkfAVI1KhsRZCYoLB0TNEcpKy4fH/xAAaAQADAQEBAQAAAAAAAAAAAAAAAQIDBQQG/8QAMBEAAQMDAwIDBQkAAAAAAAAAAQACEQMhMQQSQQVhFDJRE3GBodEGIiQzkZLB4vD/2gAMAwEAAhEDEQA/APpeQosZL4CY3zWrjgluTzQxsVJwDnYD6mlbm8ighuLq8dmtrSMyyLnc+ij6muYane6pxTp+rarc3fJbWBixarkIA7FQFHbbHc71nUqilbJXS6f0x2vlxdtaCBPcmAF2wjoCNCjAHYHGQPqa8mjLgFTh13U1xTTL3VOFdP0nVbW757a/MubVslCEYKQR23z3G4rsFjfx3+nQXNnnp3MYeIN3BOxU/Q0qVUVOxT6j0x2ih27c0kicXFiE11h8N1SMbZxQ9PQiEu3zOck0G7lgazjMVxB8Ny83W6g5OUHGebt3ojKhlKxXDRyL4eXO23sa24XMIIN02RkYoC2wVwQxK5LFW33NYNJcQqTKiyINyyHB/KsheRMh5Th8ZCtsTSg8IkKn/iDZ2s8vDsstrbuza9aRFjEpLLhgQTjcbdvaveMuhYcb/h/cydG1sILi8iMhxHHGz2zBFzsBkggVcbfoTQoFaCcRSFcjDcsqkg/Rgc+9Z3FvDdwNb3UMU8D7NHKgdW+oO1EplpFiuO6qwueB/wATru2Mc1vPrC9GQHKSYMAOCO4ztke9bfSbaVOKeM31C0sNK1CLR1i+DsCTFcRkOwn5iq8xBynyjGPcV0a1Wzl0+OO0S3exwVWNEHT2bGAuMbEVjNJEl9Es/wAO91NG4jyo6jouCwG243G2aJRtMxF1qfwpXP4bcNb/APIQ/wDiKlbuK4ihjWOPlhRRgIF5Qo9AKlCSqPENvJeaHrVnCpM81skqKO7dN+ZgPU+1Ubg3XRoegcQPFLCt9J8P0I5F5ufDtzbewNdSe0ecLcQuYriJswt6bYwfbG1Vy84I0ziGeWW3kfS9RBzPCqh4yf4lXI2PsftXnr03OdvZld7pOuoUqLtNqvI4gznBBg9jCqHGWujXNA4feWWFr6P4jrxxry8mXXl29wK6HwbA9lp2g2NweWWGB5pFPkZH5lU+432rVWfBGm8PXEUs8japqBOYIGTkQH+Jhk7D3NWa3gltVee5KzXUhDvL28XYbentRQpuDt78lPq2uoVaLdNpfI0kzHqSYHYSqoE1A/h6W6tn8OLceHpP1OTqdubmxnPtSvGnHJ07V9Ut4bm6+NtphHbwRKnQChFJaUkZbmJYYHYDy71b9bC2XC2oXUcMGILOSRYDEvTwqlgOXHqK+bL24eOOSZ2aSVjlmY5LMTuSfrvXn1VR1GGtyV7ekUKevL6tUfdaSeOYP8X966hafiW1xqhe9W70+1Lp01t3WeNEGOYOhVSwPi3ByMjA23t0eqTz6bPrFpqks6DUxDBD4WiliaVVCAYzkhsg5yMema+d7C8eaUpIB2yCK7F+B6W8x1NZbW3eW1eOaGZowXQuGBAP+T+Z9ay0+oe9+x/K9PUtBptPQ8RSFhAIt7ufXlWeVZb+bSJZ7q4DLr9zCoR8AKvxGPuAoH0zRv2re/tqznguLmSzn1J7QmRkWMqOcFVjHi2K/MTk49DVlms7SaIRS2lu0Ql64UxjHUznn/6sknPuaGNL04XrXg06z+KZg5m6K83N65x32G/tXQ2FfOeLpnzN9fTmfr8v01fDs72vBnxESc8kKXMir/ERJIQP5VppXuLTUtAvzfTajO+mXdyOoVKlunG3hCgYBO2Pb65u8KJAipBGkSLnCxqFAycnYe5NIxadYWMolsrC0gnd/njhUNv82/uM0FhIAUs1bGue8jM/MER2zwq/ZHWruxtbkS6yTNEsjPFcWgRyRnKg9h6CpW8fh/RXdnfR9PZmJJJt1O57+VSlsP8AitDq6U4H7f7JgOEfpkcoAHKSe/tQL7T4bxkdzJHKnyyROUYfcb0/MUC/vFyp2O2cULo+ENBJgHsDutaQvAKnBStjp8Nmzuhkklf5pJXLsfud6kitJMkDbgtzE58v/lMlmT/iIR/iXcUrbzqk7yShvFsDjt+tqbQcpVHNgAJ2+tYr2yuLScZhnjaJwPNWGD/I18za/o8+kajcabfrlkPhfGBKmdnHscfY5HlX0y86GFmjYM2MAe/lVX/EPhdNd4eboJnUbNC9uwG74G6f5sfng15dXp/askZC6/ROpeDrbH+R2e3f6r57ht4rfmZBj1JPlV90a7vOGeHr4WLG01ScFpbuWEskLKP3dspIK9U82Tn5Q2O4wC/hHw5HrWoyandqWs7Ir0x5PMRkf9owcepX0rtF/ZxahYyWl6XkhcqTg4PhYMO3uBWPT6MH2r/guh9o+oB34OjgZ+iCupwPe3Nusys8E62zByELSGNX5V8mOGGw96dRw3bv6HYiqTrvDs8Z1q90y6uJtUnnEsZRPFaxMUWXojIzIUXHNkHAAGKRt9V1XRYLqPkgnitIpNQl+JkmDQwlQscIZ8urs6yNhubAwPSupsBwvkt0ZXRaEv7ydm/up4R9fP8AX1rV2ev29xPNG7wW4QpABPLyObgqGaPB2blDIDg5zkYp2xvLa401bqymE8B5gsgBAdgxU4z7g7+dTBCqQVlN15JG6DhVXwn3NSjwpyRKp3Pcn386lEohDSJyoYyMrncjOR9MUIiRZWCL4hgkp2OfVT/pTgOaXvbmHTbG8v7jm6NvE9xLgZPKq5OPsKQMoIVW4n1m+kvm0zTHgmSPpvdpZXYjvUT+8Ar4Hcr2bPl5itnwg95Pplyb43jwfEMtt8fFyXHTCrkSDAz4ubB8xiq5fWsF3GlpqGhyQy3dzJPaPfslxaCSfdgWjzg7sVDeZAB7YvFtD+ztJt7fqvN8LAsXUf5n5VAyfc4q3WEBSMygw20cxlbdV5yF5fQVk8M0KM0c5KgZwfSmLROnbRqe+Mn61hfvy2zf4tqmbwnAiUpw9ptlpWm9HTrZLeJ3aRkQndidzv8ASnVuIyP73N5qFJI+uK9tOXoIFYHA3x61nGioCFHc5J9amALKi5zjJMlK2hD3dw49hv8Ar2o17aW19CIb2FZYudH5SSMlGDLnHcAjODtQbJl68+SOZm2H3NOUzYpDCo2q8GTorRaQILmO4tfg5Jbx/wB7CZJWaWceHDswfceH5FxntQeHr++/tNa6VaxyW9hBHKHsZd+hDF4IzjprhmblYEO2QW9jV/rLmPrvVb7XS2+iqk2ta/eXt4nD+l2NxaWkxtnmuZ2QvKoHPygD5QTy/VTUo97pkNveTtaalq9iJ3M0kNo0Zj52+ZsMjEEncjON6lOQoLwDcrfqwydxt39qS1ybUYrOL9j2ttdSyTBJFuSRGIyrEkkZxuAM4PftRMERKh+aQ+L+p/2rTcXa3d6ZLZwWlrayLNgyPdStEhy6qFDgEA+LOT5AbHNY0hwtXm0oHDmkWXxuZNDvtLktmE6QfFGSyL74aNVblyM9uUY74qzXUTzJyqwAPdT2NarRpk1bQ7G/Fu1qbmMSiPqB8A9jkbHIwfvTiyXEHf8Aep/P9fnWpuVAwmhMAcSgxn37H70C98c0EfkWyf1+dFiuopvCTgnblbzoECK185QYSPYfX9ZpCyZum3iRzzYw38S7GvOkfKWT8x/tRDsPWgkzcpcsiY35SucfzpJpWy2iYtHzpzZz3IOB5U8jq4yhBFK2OVs2b6n+VEhjEkEbsSJCoPONjTKQTFeOwRGZjhVGSaGDKhAcB1/iXY/cV5P4njjPynxt9Bj/AFIqUybLyFljTMrKsj+NgT2z5fbt9qlAe0S9PWm5hnZANvD5f7/epQs5fwLe9eQCYXABzIoPJzelUqxv21XiG5ntJFitNRlhiNvfRJcwzgJIQBy4MbBYmbBLY5hnvtYeLL9NP4Zm5bw2jXDLaLdqCeg0hwZCQRjAyc5GKDwppUCTz6lLpulLdSAFNQsZzIlxzDxMFPyMcDJ3znuappAaXFWbkAKws6mQqg8IG2BsB5CpQI3xzNHAelzHDJ5/aixyJJ8jAn08/wAqSaxlhST5hv6jvWKwT22TCQ6nuuKYQZYUaiUQlo7xGPLIDG3mD2ol04W2kbOxXA+9ZSRJKMOoP9a11xDySrDGzsp3K+n63pgApEkIivLHYkdHwcp8XMPP2+9PQjliQHuFAobiO5gaNWwOxx3H2rFJJo3CTLzg7CRR/UeVBugWTFKTgy3YiweXkyx9ie33x+WaLNL4XEbKGXdi3ZR6/wDqsIsQQSTyDDv422we2APrjFSk69kzUrCAu0SmQAORkgeVShWqfxi91Jq1la29/d2cZWMk2z8pJeUKS2xDbbAMCN+1OcFPngiwuwkKT3MRnlaKJIg8jd2IUAZ2Hl5VKlUfyh8FA85VjtlC28YHblFYXkSNDIzICyqSD59qlSlyq4WVsP3ERO5Kjc/Si1KlI5TClJ2XjuJ3b5gcfr8hUqUxgpHKZkiVyCchh2YbEUn8VJyKMjJlEecb4z/WpUo4UvsEeZFXpRqoVHk8QAxnYt/UUDUpCskC4BXOSD51KlNuUeqM6mMgRuyLjOBjA/MVKlSqAsglf//Z: Ubicación: 4.7528272, -74.0903028 — https://maps.google.com/?q=4.7528272,-74.0903028

[12:36 a. m.] **Tú:**
> _Vale 🌙: /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAgIDAQEAAAAAAAAAAAAAAwQABgIFBwEI/8QAPBAAAgEDAgQEBAMFBgcAAAAAAQIDAAQRBSEGEhMxIkFRYRQycYEHkfAVI1KhsRZCYoLB0TNEcpKy4fH/xAAaAQADAQEBAQAAAAAAAAAAAAAAAQIDBQQG/8QAMBEAAQMDAwIDBQkAAAAAAAAAAQACEQMhMQQSQQVhFDJRE3GBodEGIiQzkZLB4vD/2gAMAwEAAhEDEQA/APpeQosZL4CY3zWrjgluTzQxsVJwDnYD6mlbm8ighuLq8dmtrSMyyLnc+ij6muYane6pxTp+rarc3fJbWBixarkIA7FQFHbbHc71nUqilbJXS6f0x2vlxdtaCBPcmAF2wjoCNCjAHYHGQPqa8mjLgFTh13U1xTTL3VOFdP0nVbW757a/MubVslCEYKQR23z3G4rsFjfx3+nQXNnnp3MYeIN3BOxU/Q0qVUVOxT6j0x2ih27c0kicXFiE11h8N1SMbZxQ9PQiEu3zOck0G7lgazjMVxB8Ny83W6g5OUHGebt3ojKhlKxXDRyL4eXO23sa24XMIIN02RkYoC2wVwQxK5LFW33NYNJcQqTKiyINyyHB/KsheRMh5Th8ZCtsTSg8IkKn/iDZ2s8vDsstrbuza9aRFjEpLLhgQTjcbdvaveMuhYcb/h/cydG1sILi8iMhxHHGz2zBFzsBkggVcbfoTQoFaCcRSFcjDcsqkg/Rgc+9Z3FvDdwNb3UMU8D7NHKgdW+oO1EplpFiuO6qwueB/wATru2Mc1vPrC9GQHKSYMAOCO4ztke9bfSbaVOKeM31C0sNK1CLR1i+DsCTFcRkOwn5iq8xBynyjGPcV0a1Wzl0+OO0S3exwVWNEHT2bGAuMbEVjNJEl9Es/wAO91NG4jyo6jouCwG243G2aJRtMxF1qfwpXP4bcNb/APIQ/wDiKlbuK4ihjWOPlhRRgIF5Qo9AKlCSqPENvJeaHrVnCpM81skqKO7dN+ZgPU+1Ubg3XRoegcQPFLCt9J8P0I5F5ufDtzbewNdSe0ecLcQuYriJswt6bYwfbG1Vy84I0ziGeWW3kfS9RBzPCqh4yf4lXI2PsftXnr03OdvZld7pOuoUqLtNqvI4gznBBg9jCqHGWujXNA4feWWFr6P4jrxxry8mXXl29wK6HwbA9lp2g2NweWWGB5pFPkZH5lU+432rVWfBGm8PXEUs8japqBOYIGTkQH+Jhk7D3NWa3gltVee5KzXUhDvL28XYbentRQpuDt78lPq2uoVaLdNpfI0kzHqSYHYSqoE1A/h6W6tn8OLceHpP1OTqdubmxnPtSvGnHJ07V9Ut4bm6+NtphHbwRKnQChFJaUkZbmJYYHYDy71b9bC2XC2oXUcMGILOSRYDEvTwqlgOXHqK+bL24eOOSZ2aSVjlmY5LMTuSfrvXn1VR1GGtyV7ekUKevL6tUfdaSeOYP8X966hafiW1xqhe9W70+1Lp01t3WeNEGOYOhVSwPi3ByMjA23t0eqTz6bPrFpqks6DUxDBD4WiliaVVCAYzkhsg5yMema+d7C8eaUpIB2yCK7F+B6W8x1NZbW3eW1eOaGZowXQuGBAP+T+Z9ay0+oe9+x/K9PUtBptPQ8RSFhAIt7ufXlWeVZb+bSJZ7q4DLr9zCoR8AKvxGPuAoH0zRv2re/tqznguLmSzn1J7QmRkWMqOcFVjHi2K/MTk49DVlms7SaIRS2lu0Ql64UxjHUznn/6sknPuaGNL04XrXg06z+KZg5m6K83N65x32G/tXQ2FfOeLpnzN9fTmfr8v01fDs72vBnxESc8kKXMir/ERJIQP5VppXuLTUtAvzfTajO+mXdyOoVKlunG3hCgYBO2Pb65u8KJAipBGkSLnCxqFAycnYe5NIxadYWMolsrC0gnd/njhUNv82/uM0FhIAUs1bGue8jM/MER2zwq/ZHWruxtbkS6yTNEsjPFcWgRyRnKg9h6CpW8fh/RXdnfR9PZmJJJt1O57+VSlsP8AitDq6U4H7f7JgOEfpkcoAHKSe/tQL7T4bxkdzJHKnyyROUYfcb0/MUC/vFyp2O2cULo+ENBJgHsDutaQvAKnBStjp8Nmzuhkklf5pJXLsfud6kitJMkDbgtzE58v/lMlmT/iIR/iXcUrbzqk7yShvFsDjt+tqbQcpVHNgAJ2+tYr2yuLScZhnjaJwPNWGD/I18za/o8+kajcabfrlkPhfGBKmdnHscfY5HlX0y86GFmjYM2MAe/lVX/EPhdNd4eboJnUbNC9uwG74G6f5sfng15dXp/askZC6/ROpeDrbH+R2e3f6r57ht4rfmZBj1JPlV90a7vOGeHr4WLG01ScFpbuWEskLKP3dspIK9U82Tn5Q2O4wC/hHw5HrWoyandqWs7Ir0x5PMRkf9owcepX0rtF/ZxahYyWl6XkhcqTg4PhYMO3uBWPT6MH2r/guh9o+oB34OjgZ+iCupwPe3Nusys8E62zByELSGNX5V8mOGGw96dRw3bv6HYiqTrvDs8Z1q90y6uJtUnnEsZRPFaxMUWXojIzIUXHNkHAAGKRt9V1XRYLqPkgnitIpNQl+JkmDQwlQscIZ8urs6yNhubAwPSupsBwvkt0ZXRaEv7ydm/up4R9fP8AX1rV2ev29xPNG7wW4QpABPLyObgqGaPB2blDIDg5zkYp2xvLa401bqymE8B5gsgBAdgxU4z7g7+dTBCqQVlN15JG6DhVXwn3NSjwpyRKp3Pcn386lEohDSJyoYyMrncjOR9MUIiRZWCL4hgkp2OfVT/pTgOaXvbmHTbG8v7jm6NvE9xLgZPKq5OPsKQMoIVW4n1m+kvm0zTHgmSPpvdpZXYjvUT+8Ar4Hcr2bPl5itnwg95Pplyb43jwfEMtt8fFyXHTCrkSDAz4ubB8xiq5fWsF3GlpqGhyQy3dzJPaPfslxaCSfdgWjzg7sVDeZAB7YvFtD+ztJt7fqvN8LAsXUf5n5VAyfc4q3WEBSMygw20cxlbdV5yF5fQVk8M0KM0c5KgZwfSmLROnbRqe+Mn61hfvy2zf4tqmbwnAiUpw9ptlpWm9HTrZLeJ3aRkQndidzv8ASnVuIyP73N5qFJI+uK9tOXoIFYHA3x61nGioCFHc5J9amALKi5zjJMlK2hD3dw49hv8Ar2o17aW19CIb2FZYudH5SSMlGDLnHcAjODtQbJl68+SOZm2H3NOUzYpDCo2q8GTorRaQILmO4tfg5Jbx/wB7CZJWaWceHDswfceH5FxntQeHr++/tNa6VaxyW9hBHKHsZd+hDF4IzjprhmblYEO2QW9jV/rLmPrvVb7XS2+iqk2ta/eXt4nD+l2NxaWkxtnmuZ2QvKoHPygD5QTy/VTUo97pkNveTtaalq9iJ3M0kNo0Zj52+ZsMjEEncjON6lOQoLwDcrfqwydxt39qS1ybUYrOL9j2ttdSyTBJFuSRGIyrEkkZxuAM4PftRMERKh+aQ+L+p/2rTcXa3d6ZLZwWlrayLNgyPdStEhy6qFDgEA+LOT5AbHNY0hwtXm0oHDmkWXxuZNDvtLktmE6QfFGSyL74aNVblyM9uUY74qzXUTzJyqwAPdT2NarRpk1bQ7G/Fu1qbmMSiPqB8A9jkbHIwfvTiyXEHf8Aep/P9fnWpuVAwmhMAcSgxn37H70C98c0EfkWyf1+dFiuopvCTgnblbzoECK185QYSPYfX9ZpCyZum3iRzzYw38S7GvOkfKWT8x/tRDsPWgkzcpcsiY35SucfzpJpWy2iYtHzpzZz3IOB5U8jq4yhBFK2OVs2b6n+VEhjEkEbsSJCoPONjTKQTFeOwRGZjhVGSaGDKhAcB1/iXY/cV5P4njjPynxt9Bj/AFIqUybLyFljTMrKsj+NgT2z5fbt9qlAe0S9PWm5hnZANvD5f7/epQs5fwLe9eQCYXABzIoPJzelUqxv21XiG5ntJFitNRlhiNvfRJcwzgJIQBy4MbBYmbBLY5hnvtYeLL9NP4Zm5bw2jXDLaLdqCeg0hwZCQRjAyc5GKDwppUCTz6lLpulLdSAFNQsZzIlxzDxMFPyMcDJ3znuappAaXFWbkAKws6mQqg8IG2BsB5CpQI3xzNHAelzHDJ5/aixyJJ8jAn08/wAqSaxlhST5hv6jvWKwT22TCQ6nuuKYQZYUaiUQlo7xGPLIDG3mD2ol04W2kbOxXA+9ZSRJKMOoP9a11xDySrDGzsp3K+n63pgApEkIivLHYkdHwcp8XMPP2+9PQjliQHuFAobiO5gaNWwOxx3H2rFJJo3CTLzg7CRR/UeVBugWTFKTgy3YiweXkyx9ie33x+WaLNL4XEbKGXdi3ZR6/wDqsIsQQSTyDDv422we2APrjFSk69kzUrCAu0SmQAORkgeVShWqfxi91Jq1la29/d2cZWMk2z8pJeUKS2xDbbAMCN+1OcFPngiwuwkKT3MRnlaKJIg8jd2IUAZ2Hl5VKlUfyh8FA85VjtlC28YHblFYXkSNDIzICyqSD59qlSlyq4WVsP3ERO5Kjc/Si1KlI5TClJ2XjuJ3b5gcfr8hUqUxgpHKZkiVyCchh2YbEUn8VJyKMjJlEecb4z/WpUo4UvsEeZFXpRqoVHk8QAxnYt/UUDUpCskC4BXOSD51KlNuUeqM6mMgRuyLjOBjA/MVKlSqAsglf//Z_
Con ubicando en tiempo real

[12:36 a. m.] **Tú:** [Sticker]

[1:00 a. m.] **Tú:** jfkskdjfjskBésameksjdfkjskdfsinjskdfk jskdfmotivosfjskdjfksjyksjdfkjskdestar éjfkskdjfkssiempreksjdfkjskcontigofjs kdjfksjohksjdfkjskdbésamejfkskdjfksc omoksjdfkjsksifjskdjfksjelksjdfkjskdm undojfkskdjfksseksjdfkjskacabaráfjsk difksjdespuésksjdfkjskdbésamejfkskd jfksyksjdfkjskbesofjskdjfksjaksjdfkjsk dbesojfkskdjfksponksjdfkjskenfjskdjfk sjcieloksjdfkjskdaljfkskdjfksrevésksjdf kjskbésamefjskdjfksjsinksjdfkjskdrazó njfkskdjfksporqueksjdfkjskquierefjskd jfksjelksjdfkjskdcorazónjfkskdjfksbés ameksjdfkjsk

[1:06 a. m.] **Vale 🌙:** [Sticker]

[1:07 a. m.] **Tú:** No me gusta toca hacer otro más bonito

[1:07 a. m.] **Vale 🌙:** [Sticker]

[1:07 a. m.] **Vale 🌙:** Tii

[1:07 a. m.] **Tú:** https://vt.tiktok.com/ZS4sSPo4r/

[1:07 a. m.] **Tú:** Como va

[1:07 a. m.] **Tú:** A

[1:07 a. m.] **Tú:** Me acostaré cuando llegues más bien

[1:07 a. m.] **Vale 🌙:** Bien amor

[1:08 a. m.] **Vale 🌙:** Ya me duelen los pies

[1:10 a. m.] **Tú:** https://vt.tiktok.com/ZS4sSo2Ps/

[1:10 a. m.] **Tú:**
> _Vale 🌙: Ya me duelen los pies_
Me imagino todo el día para amor

[1:11 a. m.] **Tú:** Mañana me imagino te levantarás por ahí a las 3

[1:11 a. m.] **Vale 🌙:**
> _Tú: Me imagino todo el día para amor_
Si amor mío

[1:11 a. m.] **Vale 🌙:** Mi jefa se fue

[1:11 a. m.] **Tú:**
> _Vale 🌙: Mi jefa se fue_
Y entonces

[1:11 a. m.] **Tú:** Y tu que

[1:11 a. m.] **Tú:** Quien te lleva

[1:11 a. m.] **Vale 🌙:** Así que el resto nos toca entres los meseros

[1:11 a. m.] **Tú:**
> _Vale 🌙: Así que el resto nos toca entres los meseros_
Que abuso la verdad

[1:12 a. m.] **Vale 🌙:**
> _Tú: Quien te lleva_
El hijo de mi jefa nos recoje a todos y vamos asiendo paradas

[1:12 a. m.] **Tú:** Pero les dejo transporte

[1:12 a. m.] **Tú:**
> _Vale 🌙: El hijo de mi jefa nos recoje a todos y vamos asiendo paradas_
Ósea todos en un solo taxi

[1:12 a. m.] **Tú:** Jul

[1:12 a. m.] **Tú:** Jum

[1:12 a. m.] **Tú:** Bueno me cuentas

[1:13 a. m.] **Vale 🌙:**
> _Tú: Ósea todos en un solo taxi_
Si

[1:13 a. m.] **Tú:** https://vt.tiktok.com/ZS4sAf4DC/

[1:13 a. m.] **Vale 🌙:**
> _Tú: https://vt.tiktok.com/ZS4sAf4DC/_
Te adoro mi flaco

[1:37 a. m.] **Tú:**
> _Vale 🌙: Te adoro mi flaco_
También mi vida

[2:12 a. m.] **Tú:** Como tas amor

[2:13 a. m.] **Vale 🌙:** Bien cielo

[2:16 a. m.] **Tú:** Ya casi sales

[4:08 a. m.] **Vale 🌙:** Voy en camino

[4:31 a. m.] **Vale 🌙:** Ya llegué

[10:05 a. m.] **Tú:** No alcancé

[10:05 a. m.] **Tú:** Me gano el sueño

[10:05 a. m.] **Tú:** Como vas

[10:05 a. m.] **Tú:** Si estás despierta

[12:27 p. m.] **Vale 🌙:** Me acabo de levantar

[12:37 p. m.] **Tú:** Me imagine

[12:37 p. m.] **Tú:** Que haces  mi vida

[12:43 p. m.] **Tú:** Vas a venir

[12:43 p. m.] **Tú:** Y al rato salimos

[12:48 p. m.] **Vale 🌙:** Dale amor espera y m baño

[12:48 p. m.] **Tú:** Dale mi amor

[12:48 p. m.] **Tú:** O venga y se baña acá

[12:48 p. m.] **Tú:** Nos bañamos

[12:49 p. m.] **Vale 🌙:** Bueno

[1:05 p. m.] **Vale 🌙:** Ya me pongo zapatos y salgo

[1:29 p. m.] **Tú:** Va

[1:42 p. m.] **Vale 🌙:** Abreme

[6:29 p. m.] **Tú:** Mi mamá ya está cerca

[6:29 p. m.] **Tú:** Jajaja

[6:29 p. m.] **Tú:** Si le haces el favor

[6:29 p. m.] **Tú:** Corazón

[6:44 p. m.] **Vale 🌙:** Bueno

[6:45 p. m.] **Vale 🌙:** Amor le eche mucha leche y no hay más chocolate

[7:17 p. m.] **Vale 🌙:** Amor ya vienes

[7:17 p. m.] **Vale 🌙:** Tengo que ir a lavar el uniforme pa mañana

[7:17 p. m.] **Tú:**
> _Vale 🌙: Amor le eche mucha leche y no hay más chocolate_
Ajajaj

[7:17 p. m.] **Tú:** Ya que

[7:18 p. m.] **Tú:**
> _Vale 🌙: Amor ya vienes_
Ya estoy cerca

[7:18 p. m.] **Tú:**
> _Vale 🌙: Tengo que ir a lavar el uniforme pa mañana_
Vale

[7:18 p. m.] **Tú:** Que te dijo mi mamá

[7:18 p. m.] **Vale 🌙:** Nada me saludo y me preguntó onde tabas

[7:18 p. m.] **Vale 🌙:** Y por que no fui con Tigo

[7:58 p. m.] **Vale 🌙:** _Esperando el mensaje… Esto puede demorar un poco._

[7:58 p. m.] **Tú:**
> _Vale 🌙: Imagen_
Ajá

[7:58 p. m.] **Tú:** Niña

[7:58 p. m.] **Tú:** Que soy tu modo

[7:58 p. m.] **Vale 🌙:** Como le ponemos a snoopi

[7:58 p. m.] **Tú:** O que putas

[7:59 p. m.] **Vale 🌙:** [Imagen]

[7:59 p. m.] **Tú:** A mi me manda las fotos normal

[7:59 p. m.] **Tú:**
> _Vale 🌙: Imagen_
Ahh si podía

[7:59 p. m.] **Vale 🌙:**
> _Vale 🌙: Imagen_
Es por que me veo terrible

[7:59 p. m.] **Tú:** Me avisas

[7:59 p. m.] **Tú:** Vas a volver

[7:59 p. m.] **Tú:** O vienes mañana

[7:59 p. m.] **Tú:**
> _Vale 🌙: Como le ponemos a snoopi_
Sinóptico

[7:59 p. m.] **Tú:** Snoopy

[7:59 p. m.] **Tú:** Jajaja

[7:59 p. m.] **Tú:** José Manuel retrepo

[8:00 p. m.] **Vale 🌙:** Yo creo que mañana por que mientras lavo los uniformes y mañana me tocaría salir corriendo para venir a ponerme los y ir a trabajar

[8:00 p. m.] **Vale 🌙:**
> _Tú: José Manuel retrepo_
Jsjsj tampoco

[8:02 p. m.] **Vale 🌙:** [Mensaje de album]

[8:02 p. m.] **Vale 🌙:** [Imagen]

[8:02 p. m.] **Vale 🌙:** [Imagen]

[8:02 p. m.] **Vale 🌙:** [Imagen]

[8:02 p. m.] **Vale 🌙:** [Imagen]

[8:02 p. m.] **Vale 🌙:** Te amoo gachas por el peluche

[8:37 p. m.] **Tú:**
> _Vale 🌙: Yo creo que mañana por que mientras lavo los uniformes y mañana me tocaría salir corriendo para venir a ponerme los y ir a trabajar_
Dale mi corazón

[8:37 p. m.] **Tú:**
> _Vale 🌙: Jsjsj tampoco_
Jjaajkaak

[8:37 p. m.] **Tú:**
> _Vale 🌙: [album]_
Uy uy uy

[8:37 p. m.] **Tú:** Todo eso me voy a comer estos días

[8:37 p. m.] **Tú:**
> _Vale 🌙: Te amoo gachas por el peluche_
De nada mi rey

[8:37 p. m.] **Tú:** Después con más platica

[8:37 p. m.] **Tú:** Vamos por uno más grande

[8:43 p. m.] **Tú:** [Mensaje de album]

[8:43 p. m.] **Tú:** [Imagen]

[8:43 p. m.] **Tú:** [Imagen]

[9:42 p. m.] **Tú:** _Esperando el mensaje… Esto puede demorar un poco._

---

## 10 de agosto de 2026

[4:27 p. m.] **Tú:** Holiii

[4:27 p. m.] **Tú:** Corazón  como tas

[4:27 p. m.] **Tú:** Que tal ese temblor

[4:27 p. m.] **Vale 🌙:** Holi amor

[4:27 p. m.] **Vale 🌙:**
> _Tú: Que tal ese temblor_
Horrible

[4:27 p. m.] **Vale 🌙:** Tu mami paso por el local

[4:28 p. m.] **Tú:** Si me dijo que la miraste con cara de culo

[4:28 p. m.] **Tú:** Qie estabas como seria

[4:28 p. m.] **Tú:**
> _Vale 🌙: Horrible_
Que les dijeron

[4:28 p. m.] **Tú:** Si los sacaron

[4:29 p. m.] **Vale 🌙:** Jsjsb es mi cara de trabajo

[4:29 p. m.] **Vale 🌙:**
> _Tú: Si los sacaron_
Si yo primero pensé que estaba mariada asta que mi jefa vi que las lámparas se estaban moviendo re duro y salimos

[4:31 p. m.] **Tú:**
> _Vale 🌙: Jsjsb es mi cara de trabajo_
Toca que le digas

[4:31 p. m.] **Tú:** Porque si llego y me dijo jum

[4:31 p. m.] **Tú:** Fui a comprarle flores a valentina

[4:31 p. m.] **Tú:** Y me miro toda seria

[4:31 p. m.] **Tú:**
> _Vale 🌙: Si yo primero pensé que estaba mariada asta que mi jefa vi que las lámparas se estaban moviendo re duro y salimos_
Me imagino

[4:31 p. m.] **Tú:** Claro y con todo eso

[4:32 p. m.] **Tú:** Pero todo bien la plaza

[4:34 p. m.] **Vale 🌙:** [Mensaje de voz]

[5:06 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Es que me estaba tirando una paja

[5:06 p. m.] **Tú:** Por eso tanto tembleteo

[5:06 p. m.] **Tú:** Así fue

[5:06 p. m.] **Tú:** Acá si se sintió pero no se

[5:06 p. m.] **Tú:** Relax

[5:06 p. m.] **Tú:** Que andas haciendo

[7:47 p. m.] **Vale 🌙:** Me avía dormido

---

## 11 de agosto de 2026

[12:29 a. m.] **Vale 🌙:** Se metieron a robar en mi casa
Un Man rompió la puerta de abajo
Y estaba pasando metiendo el cuchillo por la orilla de todas las puertas y gritaba disque buenas
Yo llamé ala policía

[12:30 a. m.] **Vale 🌙:** [Mensaje de album]

[12:30 a. m.] **Vale 🌙:** [Imagen]

[12:30 a. m.] **Vale 🌙:** [Imagen]

[12:30 a. m.] **Tú:** En tu apartamento

[12:31 a. m.] **Tú:** Y ese reguero de sangre que

[12:31 a. m.] **Tú:** Pero cómo estás

[12:31 a. m.] **Vale 🌙:**
> _Tú: Pero cómo estás_
Bien amor

[12:31 a. m.] **Tú:** Te pasó algo

[12:31 a. m.] **Tú:** Pero entro a la casa

[12:31 a. m.] **Vale 🌙:**
> _Tú: Y ese reguero de sangre que_
El Man cuando rompio la puerta se cortó la mano

[12:32 a. m.] **Tú:** Pero como se metió

[12:32 a. m.] **Vale 🌙:**
> _Tú: Pero como se metió_
Nosé como putas solo senticuando rompieron la puerta

[12:34 a. m.] **Vale 🌙:** Y yo que me dio nervios ojibun bate y me asome por la rendija de la  puerta  cuando es que veo se asoma un cuchillo levanté a todos los de la casa me nos malmno abri la puerta sino que llamé ala policía

[12:40 a. m.] **Tú:**
> _Vale 🌙: Y yo que me dio nervios ojibun bate y me asome por la rendija de la  puerta  cuando es que veo se asoma un cuchillo levanté a todos los de la casa me nos malmno abri la puerta sino que llamé ala policía_
Lo bueno fue que no pasó a mayores

[12:40 a. m.] **Tú:** Y cogieron al tipo

[12:41 a. m.] **Tú:** Muy denso eso

[12:41 a. m.] **Tú:** Pero raro porque que entre así

[12:41 a. m.] **Tú:** En que quiera robar hace la maldad enseguida

[12:41 a. m.] **Tú:** Para mí que el tipo buscaba algo

[12:42 a. m.] **Tú:** Y entonces que van hacer porque con la puerta así

[12:54 a. m.] **Vale 🌙:**
> _Tú: Y cogieron al tipo_
Si amor

[12:54 a. m.] **Vale 🌙:**
> _Tú: Y entonces que van hacer porque con la puerta así_
Pues paila por hoy  toca dejar eso así

[12:56 a. m.] **Tú:**
> _Vale 🌙: Si amor_
Y que le dijeron o que

[12:56 a. m.] **Tú:**
> _Vale 🌙: Pues paila por hoy  toca dejar eso así_
Jum

[12:56 a. m.] **Tú:** Y la policía que

[12:57 a. m.] **Vale 🌙:** El Man según lo que dijo la policía vive a dos casas de acá que supuestamente  se avía quibocado que estaba medio borracho  que tal pura mierda
Se va a equibocar con llave maestra y cuchillo Primero decía disque vivía acá  y cuando salió la dueña de la casa fue que se equivocó que tales entonces que tenía que mañana pagar por los daños

[12:58 a. m.] **Tú:**
> _Vale 🌙: El Man según lo que dijo la policía vive a dos casas de acá que supuestamente  se avía quibocado que estaba medio borracho  que tal pura mierda
Se va a equibocar con llave maestra y cuchillo Primero decía disque vivía acá  y cuando salió la dueña de la casa fue que se equivocó que tales entonces que tenía que mañana pagar por los daños_
Ósea solo tiene que pagar y ya

[12:58 a. m.] **Tú:** No lo van encañar ni nada

[12:58 a. m.] **Tú:** Que le metan una demanda entonces

[12:58 a. m.] **Tú:** Con cuchillo y no en mi casa

[12:59 a. m.] **Vale 🌙:** Pues  hay se lo llevaron igual la dueña de la casa dijo que va poner la denuncia por daños por intento de urto y algo así

[1:00 a. m.] **Tú:** Claro porque y entonces

[1:00 a. m.] **Tú:** Y acostumbrar a hechar pasador

[1:00 a. m.] **Tú:** No solo llave y ya

[1:00 a. m.] **Tú:** Es que eso toca así

[1:00 a. m.] **Vale 🌙:** [Mensaje de voz]

[1:01 a. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
J

[1:01 a. m.] **Tú:** Algo buscaba

[1:01 a. m.] **Tú:** Toca que estés pilas más bien

[1:01 a. m.] **Tú:** Y en tu apartamento

[1:01 a. m.] **Tú:** Estos días

[1:02 a. m.] **Vale 🌙:** Si amor

[1:02 a. m.] **Vale 🌙:** [Mensaje de voz]

[1:03 a. m.] **Tú:** Fue a todos

[1:03 a. m.] **Tú:** Joa

[1:03 a. m.] **Vale 🌙:** Sii

[1:03 a. m.] **Tú:** Tons ese mk está era mirando cuál estaba sin llave

[1:03 a. m.] **Tú:** Acá pasó una vez

[1:03 a. m.] **Tú:** Se iban a llevar el televisor de donde oscar

[1:04 a. m.] **Tú:** La mamá fue la que escuchó algo raro y gritó ese mk salió volando

[1:04 a. m.] **Vale 🌙:** [Mensaje de voz]

[1:05 a. m.] **Tú:** Ya dejar así

[1:05 a. m.] **Tú:** Más bien trata de descansar lo más que puedas

[1:05 a. m.] **Tú:** Hecharle bien seguro de lo que se pueda

[1:06 a. m.] **Vale 🌙:** [Mensaje de voz]

[1:06 a. m.] **Tú:** Maginage

[1:06 a. m.] **Tú:** Maginate

[1:06 a. m.] **Tú:** Descansa

[1:11 p. m.] **Tú:** Holiii

[1:11 p. m.] **Tú:** Como tas

[1:11 p. m.] **Tú:** Si dormiste

[2:38 p. m.] **Vale 🌙:** Holi amor

[2:38 p. m.] **Vale 🌙:** Pues no pero que se le va hacer

[2:52 p. m.] **Tú:** Y como vas en el trabajo

[2:52 p. m.] **Tú:** Que te dijeron

[2:52 p. m.] **Vale 🌙:** [Mensaje de voz]

[3:21 p. m.] **Tú:**
> _Tú: Que te dijeron_
Aca yo le ayudo a calentarse

[3:21 p. m.] **Tú:** Eso no se preocupe

[3:22 p. m.] **Tú:** Yo acabo de terminar  una lavadora

[3:22 p. m.] **Tú:** Ahi que estaba arreglando

[4:09 p. m.] **Tú:** Ayy no

[4:09 p. m.] **Tú:** Mi niña  como vas

[4:31 p. m.] **Vale 🌙:** [Mensaje de voz]

[4:31 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Como así que para la cas

[4:31 p. m.] **Tú:** Y no para acá

[4:54 p. m.] **Tú:** Porque no viene y se queda

[4:55 p. m.] **Tú:** Acá le da mucha pena quedarse aca

[4:55 p. m.] **Tú:** O que

[6:38 p. m.] **Tú:** Tonces

[6:38 p. m.] **Tú:** Niña

[6:38 p. m.] **Tú:** Te vas a quedar o qué

[6:39 p. m.] **Vale 🌙:**
> _Tú: Acá le da mucha pena quedarse aca_
No amor sjjs solo que quedamos en que íbamos a comer todos los de la casa acá ya que Sandra cosino pasta y pues ajá

[6:40 p. m.] **Tú:**
> _Vale 🌙: No amor sjjs solo que quedamos en que íbamos a comer todos los de la casa acá ya que Sandra cosino pasta y pues ajá_
Entonces

[6:40 p. m.] **Tú:** Jum esas excusas

[6:40 p. m.] **Tú:**
> _Tú: Te vas a quedar o qué_
….

[6:43 p. m.] **Tú:** Pa que trajiera

[6:43 p. m.] **Tú:** Salchipapa

[6:43 p. m.] **Tú:** Y comíamos acá

[6:44 p. m.] **Vale 🌙:** Me tocaría llevar el uniforme

[6:44 p. m.] **Tú:** Pa que lo lave

[6:44 p. m.] **Tú:** Igual acá ya dejó un poco de ropa jskdks

[6:44 p. m.] **Vale 🌙:** Si quieres tenés dame 10 me cambio y voy

[6:44 p. m.] **Tú:** Ya mi mamá le lavó eso

[6:44 p. m.] **Tú:** Relax

[6:44 p. m.] **Vale 🌙:**
> _Tú: Ya mi mamá le lavó eso_
Hay noo

[6:44 p. m.] **Tú:** Cuando pueda

[6:44 p. m.] **Tú:** Apenas voy hacer la comida

[6:45 p. m.] **Tú:** Y si viene me desconcentró

[6:45 p. m.] **Tú:** Y me la culeo

[6:45 p. m.] **Tú:** Agurta

[6:45 p. m.] **Tú:** Ahorita

[6:45 p. m.] **Vale 🌙:** Wueno amor

[6:45 p. m.] **Tú:** Vengamonos ahorita

[6:45 p. m.] **Tú:** [Sticker]

[8:54 p. m.] **Tú:** Ya puedes venir

[8:54 p. m.] **Tú:** Ya llego mi madrecita

[8:54 p. m.] **Tú:** Pero vente

[8:55 p. m.] **Tú:** Con el uniforme como quieras

[8:57 p. m.] **Vale 🌙:** Amor ya no creo que valla acá estoy con Sandra que estamos ablando lo de ayer y pues  de que como me voy ella tiene que cuadrar cuentas y eso  me anda doliendo mucho la porra ando como mariada amor

[8:57 p. m.] **Vale 🌙:** Me duele el estómago

[8:57 p. m.] **Tú:** Y esa vaina que comiste o que

[8:57 p. m.] **Vale 🌙:** [Mensaje de video]

[8:57 p. m.] **Tú:** Pues igual si quieres venir y tomar un poco de aire vienes

[8:57 p. m.] **Vale 🌙:**
> _Tú: Y esa vaina que comiste o que_
Nada el almuerzo

[8:58 p. m.] **Tú:** Vente y comes acá entonces

[8:58 p. m.] **Tú:** Ya mañana cuadras cuentas

[8:58 p. m.] **Tú:** Quién es ella la dueña

[8:58 p. m.] **Vale 🌙:**
> _Tú: Quién es ella la dueña_
No Sandra

[8:58 p. m.] **Tú:**
> _Vale 🌙: No Sandra_
No sé quién es

[8:59 p. m.] **Vale 🌙:** Nos está diciendo que la dueña de la casa anda poniendo quejas

[8:59 p. m.] **Vale 🌙:**
> _Tú: No sé quién es_
Es la amiga de mi ama con la que vivo

[8:59 p. m.] **Tú:**
> _Vale 🌙: Nos está diciendo que la dueña de la casa anda poniendo quejas_
Ahhh

[8:59 p. m.] **Tú:** Ya ya

[8:59 p. m.] **Tú:** Y eso que dijo

[8:59 p. m.] **Tú:** Pues igual acá tengo sopita pa que coma

[9:00 p. m.] **Tú:** O tráete una Salchipapa de dos

[9:00 p. m.] **Tú:** Para que comas con mi mamá que tiene hambre

[9:01 p. m.] **Tú:** Antes de que se acueste

[9:03 p. m.] **Vale 🌙:** Ya voy entonces

[9:08 p. m.] **Tú:** Va

[9:20 p. m.] **Vale 🌙:** Estaba ablando unas cosas acá en la casa

[9:20 p. m.] **Vale 🌙:** Amor ya nos vemos te amo

[9:20 p. m.] **Tú:** Traes

[9:20 p. m.] **Tú:** Eso

[9:20 p. m.] **Tú:** Para que comas con mi mama

[9:20 p. m.] **Tú:** Y me dices cuánto es

[9:29 p. m.] **Vale 🌙:** 24 vale

[9:29 p. m.] **Tú:** Tienes ahí

[9:29 p. m.] **Vale 🌙:** No

[9:29 p. m.] **Vale 🌙:** Todavía no me an pagado

[9:29 p. m.] **Tú:** Tienes Nequi

[9:29 p. m.] **Vale 🌙:**
> _Tú: Tienes Nequi_
Si

[9:44 p. m.] **Vale 🌙:** Amorr

[9:45 p. m.] **Tú:** Ya está

[9:45 p. m.] **Tú:** Revisa

[9:47 p. m.] **Vale 🌙:** Listo amor

[9:56 p. m.] **Tú:** Que si te demoras

[9:56 p. m.] **Tú:** Mi madre se va acostar

[9:56 p. m.] **Tú:** Ya la andan preguntando

[9:58 p. m.] **Vale 🌙:** Amor las salxhipaoas están cerradas  y ya miré y no hay donde más comprar

[9:58 p. m.] **Tú:** Ahh y porque no dijiste

[9:58 p. m.] **Tú:** Se hubiera venido

[9:58 p. m.] **Vale 🌙:** Por que no sabía

[9:58 p. m.] **Tú:** Pasa venga

[9:58 p. m.] **Vale 🌙:** Ya ábreme

[10:24 p. m.] **Tú:** Traes limonada porfa

[10:24 p. m.] **Tú:** También toma para que no se atore

[10:24 p. m.] **Vale 🌙:** Voy

[10:25 p. m.] **Tú:** Cuando termines

[10:25 p. m.] **Tú:** Una sola entrada

[10:25 p. m.] **Tú:** Para que mi mamá pueda dormir

---

## 12 de agosto de 2026

[1:07 a. m.] **Tú:** [Video]

[7:08 a. m.] **Vale 🌙:** Amor deje la camisa del uniforme en tu casa

[7:08 a. m.] **Tú:** La morada

[7:08 a. m.] **Tú:** Me puedo hacer una paja con ellla

[7:08 a. m.] **Vale 🌙:**
> _Tú: La morada_
Sii

[7:08 a. m.] **Tú:**
> _Vale 🌙: Sii_
Siii epaaa

[7:08 a. m.] **Tú:** Voy

[7:09 a. m.] **Tú:** Pere y ya ahorita se la llevo

[7:11 a. m.] **Vale 🌙:** Vale amor

[7:11 a. m.] **Tú:** La demora es el pájaro

[7:17 a. m.] **Vale 🌙:** Amor ya voy yo no o trabajo hoy

[7:18 a. m.] **Tú:** Voy voy

[2:05 p. m.] **Vale 🌙:** https://share.google/iinZ7RybE1h2iIZrn

[2:06 p. m.] **Vale 🌙:** https://maps.app.goo.gl/TcrXqy3gy3HxfAeN8?g_st=aw

[7:59 p. m.] **Vale 🌙:**
> _Tú: Video_
Me encanto

[9:41 p. m.] **Vale 🌙:** [Mensaje de voz]

[10:34 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
No

[10:34 p. m.] **Tú:** Estaba muy caro

[10:34 p. m.] **Tú:** Demasiado

[10:34 p. m.] **Tú:** Me devolví me encontré a mi tío en la cancha de tejo

[10:34 p. m.] **Tú:** Lo acompañe un rato

[10:35 p. m.] **Tú:** Me acompañó para una pasta para el dolor de cabeza

[10:35 p. m.] **Tú:** Me tocó entrar a clases

[10:35 p. m.] **Tú:** Presentar el proyecto

[10:35 p. m.] **Tú:** Me fui a entregar la lavadora le enseñé como se usaba a la señora

[10:35 p. m.] **Tú:** Y llegué me quedé hablando con mi mamá

[10:35 p. m.] **Tú:** Y ya acabó de cambiarle

[10:35 p. m.] **Tú:** Cambiarme y tu

[10:35 p. m.] **Tú:** Cómo te fue

[10:57 p. m.] **Vale 🌙:** [Mensaje de voz]

[11:51 p. m.] **Tú:** Joa

[11:51 p. m.] **Tú:** También alcanzaste hacer varias cosas

[11:52 p. m.] **Tú:** Manda pa ver

[11:52 p. m.] **Tú:** Cual esta viendo

[11:52 p. m.] **Tú:** Me suena

---

## 13 de agosto de 2026

[12:07 a. m.] **Vale 🌙:** [Imagen]

[12:07 a. m.] **Vale 🌙:** Ya voy a mimir

[12:08 a. m.] **Tú:** Ahh bueno mi vida

[12:08 a. m.] **Tú:** Que descanses

[12:08 a. m.] **Tú:** Nos vemos mañana

[12:08 a. m.] **Tú:** Mañana  trabajas verdad

[12:08 a. m.] **Vale 🌙:** Igual amor te amo

[12:08 a. m.] **Vale 🌙:**
> _Tú: Mañana  trabajas verdad_
No cielo

[3:17 p. m.] **Tú:** Que andas haciendo

[3:17 p. m.] **Vale 🌙:** Almorzando

[3:18 p. m.] **Tú:** Hasta ahora

[3:18 p. m.] **Tú:** Y eso

[3:18 p. m.] **Tú:** Jajaja

[3:18 p. m.] **Tú:** Estás en la casa

[3:18 p. m.] **Vale 🌙:** Sii

[3:22 p. m.] **Tú:** Ahh bueno mi vida

[3:22 p. m.] **Tú:** Qué vas hacer hoy

[3:33 p. m.] **Tú:** Salchipapa hoy o miedo

[3:33 p. m.] **Tú:** Tiris mañana

[3:33 p. m.] **Tú:** Jajaja

[5:28 p. m.] **Vale 🌙:** Bueno amor mío

[10:24 p. m.] **Tú:** Cómo vas mi vida bella

[10:28 p. m.] **Vale 🌙:** Bien amor

[10:41 p. m.] **Tú:** Que haces

[10:41 p. m.] **Tú:** Cómo te fue hoy en tu día de descanso

[10:44 p. m.] **Tú:** [Video]

[10:49 p. m.] **Tú:** [Imagen]

[10:50 p. m.] **Tú:** [Imagen]

[11:04 p. m.] **Vale 🌙:**
> _Tú: Imagen_
Me encanta pásame todas las que tengas

[11:05 p. m.] **Vale 🌙:**
> _Tú: Cómo te fue hoy en tu día de descanso_
Bien fui hacer una vuelta con mi tía en la mañana y me acosté y salí ahorita

[11:05 p. m.] **Vale 🌙:** Un rato.

---

## 14 de agosto de 2026

[5:51 a. m.] **Tú:** Y esa cambiadora de foto

[5:51 a. m.] **Tú:** Jajaja

[5:51 a. m.] **Tú:** Buenos días mi reina como estás

[5:51 a. m.] **Tú:**
> _Vale 🌙: Me encanta pásame todas las que tengas_
Ahora miro

[5:51 a. m.] **Tú:** Cuáles tengo

[5:51 a. m.] **Tú:**
> _Vale 🌙: Bien fui hacer una vuelta con mi tía en la mañana y me acosté y salí ahorita_
Y eso que estabas haciendo dando vueltas en la noche

[9:21 a. m.] __[Llamada]__

[10:48 a. m.] __[Llamada]__

[10:49 a. m.] __[Llamada]__

[10:50 a. m.] __[Llamada]__

[11:26 a. m.] **Vale 🌙:** Buenos días amor

[11:26 a. m.] **Vale 🌙:**
> _Tú: Y eso que estabas haciendo dando vueltas en la noche_
No osea salí un rato y me entre

[11:27 a. m.] **Vale 🌙:** Me encontré con las pelas un rato

[11:28 a. m.] **Tú:** A que horas piensas venir

[11:28 a. m.] **Tú:** Por su desayuno

[11:28 a. m.] **Tú:** Toda la mañana  llamandola

[11:28 a. m.] **Vale 🌙:** Ya voy amor

[11:29 a. m.] **Vale 🌙:**
> _Tú: Toda la mañana  llamandola_
Amor si mi jefa también me llamo para que le trabajará hoy y yo en el quinto sueño

[11:30 a. m.] **Tú:** A dormir donde la trasnocharon apurele

[11:36 a. m.] **Vale 🌙:** En mi casita jsjs

[11:36 a. m.] **Vale 🌙:** [Mensaje de voz]

[11:36 a. m.] **Tú:** Bueno

[1:07 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
[Sticker]

[1:46 p. m.] **Vale 🌙:** Ya amor

[1:46 p. m.] **Vale 🌙:** Me estaba bañando

[1:47 p. m.] **Vale 🌙:** Fui por el sueldo y llevar esos pétalos

[1:52 p. m.] **Tú:** Toca que salgas rápido

[1:52 p. m.] **Tú:** Que empezó a llovee

[1:54 p. m.] **Vale 🌙:** Bueno

[2:19 p. m.] **Tú:** Te encargo una leche condensada

[2:19 p. m.] **Tú:** [Sticker]

[2:32 p. m.] **Vale 🌙:** Vale amor

[2:32 p. m.] **Vale 🌙:** Ya la compro

[2:59 p. m.] **Vale 🌙:** Amor algo más

[3:02 p. m.] **Tú:** Solo eso

[3:02 p. m.] **Tú:** O una Coca-Cola

[3:02 p. m.] **Tú:** Si te alcanza

[3:05 p. m.] **Vale 🌙:** Oki

[3:08 p. m.] **Vale 🌙:**
> _Tú: O una Coca-Cola_
Normal o cero

[3:08 p. m.] **Tú:** 1.5

[3:09 p. m.] **Vale 🌙:** Vale

[3:17 p. m.] **Vale 🌙:** Amor abreme

[4:09 p. m.] **Vale 🌙:** [Reenviado] [Mensaje de album]

[4:09 p. m.] **Vale 🌙:** [Reenviado] [Video]

[4:09 p. m.] **Vale 🌙:** [Reenviado] [Imagen]

[4:09 p. m.] **Vale 🌙:** [Reenviado] [Imagen]

[4:09 p. m.] **Vale 🌙:** [Reenviado] [Video]

[4:09 p. m.] **Vale 🌙:** [Reenviado] [Imagen]

[4:09 p. m.] **Vale 🌙:** [Reenviado] [Video]

[4:09 p. m.] **Vale 🌙:** [Reenviado] [Video]

[4:09 p. m.] **Vale 🌙:** [Reenviado] [Imagen]

[4:09 p. m.] **Vale 🌙:** [Reenviado] [Imagen]

[4:09 p. m.] **Vale 🌙:** [Reenviado] [Imagen]

[4:09 p. m.] **Vale 🌙:** [Reenviado] [Imagen]

[8:15 p. m.] **Tú:** [Imagen]

[8:15 p. m.] **Tú:** [Imagen]

[8:42 p. m.] **Tú:**
> _Vale 🌙: Video_
[Sticker]

[10:35 p. m.] **Tú:** [Sticker]

[10:37 p. m.] **Vale 🌙:** [Sticker]

[10:48 p. m.] **Vale 🌙:** [Reenviado] Hoy no vengo a despedirme. Vengo a pedir perdón. Perdón por la veces q falle, por la veces q no pude demostrarte todo lo q sentía,  por las veces  que en vez de abrazarte me aleje. Se que te lastime y créeme cada dia desde q no estas me arrepiento de no haber dado mas, de no haber cuidado lo nuestro mejor y lo q hice fue lastimarte.  Tu fuiste mi compañera en lo bueno y en lo malo. Me enseñaste amar de verdad, a creer q 3l amor si existe. Me enseñaste con tus risas,  tus besos,  tus mordidas hasta con tus enojos.

Y se q me toca mejorar muchas cosas de mi por ejemplo no ser tan indeciso y hablar las cosas por q se q pa ti tampoco fue fácil pero yo fui el no tuvo el valor de quedarme y hoy me arrepiento por eso .

Por q ahora tu te vas y tal ves esta despedida sea un rato o se vuelva un adiós para siempre pero yo entiendo y comprendo .

Y eres una persona q mereces la felicidad no digo q yo sea tu felicidad ni nada por estilo... aunq me encantaría q fuera yo pero no se save q tenga el futuro para ti y depronto en tu viaje conozcas a una persona q no dude y no se confunda con lo q siente y te ame mas q yo.

Pero yo se q es lo q siento ahora mismo por ti y q siento es amor por q quiero estar contigo quiero siempre estar contigo pero al final eres tu la q tiene la última decisión si aun quieres q sea yo.

Y si consigues a otra persona en ti viaje y tu ves q lo quieres de verdad solo haslo y sigue adelante por q yo te quiero ver feliz. 

Pero eso no significa q lo vas hacer por mi aunq viniendo de ti lo dudo jsjsjs haslo por ti flaca yo se q si puedes por q eres una mujer guerrera y muy fuerte

[10:48 p. m.] **Vale 🌙:** [Reenviado] Y yo siempre estaré aquí tal vez como un enamorado o como un amigo o incluso como un desconocido aquí boy a estar igual yo no voy a cambiar de número y siempre voy a esperar ese mensaje q diga "yo también quiero intentar las cosas contigo " pero aun q lo dudo sjsj

[10:48 p. m.] **Vale 🌙:** [Reenviado] Y pues yo dejaré de molestarte para q puedas concentrarte en lo tuyo y puedas tener paz por fin y puedas ser feliz sea solo o con alguien mas pero lo importante es q tu seas feliz por q ya has sufrido mucho

[10:48 p. m.] **Vale 🌙:** [Reenviado] Y tal ves si te dejo de escribir me olvides asi como siempre me dijiste q si no te hablaba o no te escribía ya en tres dia me olvidarías y tal vez eso sea bueno para ti flaca

[10:48 p. m.] **Vale 🌙:** [Reenviado] Pero igual flaca si me necesitas siempre voy a estar aquí igual mente tu sabes q si me escribes yo siempre te voy a responder rápido no importa si estoy ocupado jdsjsj

[10:48 p. m.] **Vale 🌙:** [Reenviado] Pero se feliz flaca y olvida el pasado no olvidar no mejor soltar el pasado  como en una película q decía para tener un futuro tienes q soltar el pasado sjsj y yo se q tu puedes por q eres una mujer grandiosa

[10:48 p. m.] **Vale 🌙:** [Reenviado] Bueno ya te dejo flaca para q descanses y yo se q mi ayuda no la vas a necesitar por q ya tienes personas q te van apoyar con todo como jean y brayan o otros amigos tuyos se feliz flaca

[10:48 p. m.] **Vale 🌙:** [Reenviado] Y si quieres no contestes esos mensajes sjjs yo soy feliz si solo lo miras

[10:48 p. m.] **Vale 🌙:** [Reenviado] Bueno flaca descansa recuerda q te llevo siempre en mi corazón donde estes

[10:48 p. m.] **Vale 🌙:** Eso es lo que no quería que vieras me lo mandó Israel por que pues ya salí con el como 3 semanas antes de que trabajará con migo

[10:50 p. m.] **Vale 🌙:**
> _Vale 🌙: Eso es lo que no quería que vieras me lo mandó Israel por que pues ya salí con el como 3 semanas antes de que trabajará con migo_
Luego terminamos el aún me escribe para que volvamos y lo último fue eso

[10:53 p. m.] **Vale 🌙:** Entiendo que estés enojado si quieres me voy

[10:53 p. m.] **Tú:** Ya ni cagar puede uno se espera y ya hablamos

[10:53 p. m.] **Vale 🌙:**
> _Tú: Ya ni cagar puede uno se espera y ya hablamos_
Oki

---

## 15 de agosto de 2026

[3:02 p. m.] **Tú:** Ya almorzaron ???

[3:02 p. m.] **Tú:** Apenas voy para alla

[3:08 p. m.] **Vale 🌙:** Yo espero va que llegues

[3:08 p. m.] **Vale 🌙:** Pero el almuerzo ya está

[3:08 p. m.] **Vale 🌙:**
> _Tú: Apenas voy para alla_
Vale amor

[6:33 p. m.] **Vale 🌙:** [Video]

[8:16 p. m.] **Tú:**
> _Vale 🌙: Video_
Asss

[8:16 p. m.] **Tú:** Aquí si no cocina

[8:34 p. m.] **Vale 🌙:** Ya me falta nada más el arroz

[9:10 p. m.] **Tú:** Entonces  a que hora llegas

[9:10 p. m.] **Vale 🌙:** Amor eso de pende de lo que demore llegar al lugar servir y lavar los trastes

[9:10 p. m.] **Vale 🌙:** Son 100 personas

[9:24 p. m.] **Tú:** Avisas entonces

[9:24 p. m.] **Vale 🌙:** Dip

[10:49 p. m.] **Tú:** Cómo vas

[11:33 p. m.] **Tú:** ???

---

## 16 de agosto de 2026

[1:29 a. m.] **Vale 🌙:** Acabo de llegar

[1:31 a. m.] **Vale 🌙:** Mi jefa me dejó en la puerta de mi casa

[10:50 a. m.] **Tú:** Puede venir y quedarse hoy

[10:50 a. m.] **Tú:** Ahi quedo mucha  sopa

[10:50 a. m.] **Tú:** Para que almuerce acá

[10:52 a. m.] **Vale 🌙:** Amor quedarme no creo porque me toca alistar todavía lo de la ropa pero  más tarde

[10:52 a. m.] **Tú:** Entonces  venga y se va en la tarde  a organizar

[10:53 a. m.] **Vale 🌙:** Voy amor

[11:34 a. m.] **Tú:** ???

[11:35 a. m.] **Vale 🌙:** Ya amor me estoy poniendo zapatos

[11:50 a. m.] **Tú:** [Sticker]

[11:52 a. m.] **Vale 🌙:** Ábreme

---

## 17 de agosto de 2026

[6:32 p. m.] **Tú:** Holiii

[6:32 p. m.] **Tú:** Cómo vas

[7:21 p. m.] **Vale 🌙:** Holi bien amor mio

[7:44 p. m.] **Tú:** Ya terminaste de organizar

[7:49 p. m.] **Vale 🌙:** No amor ya voy por la mitad la me acosté un rato por que me dolía la cabeza

[7:49 p. m.] **Vale 🌙:** Voy a comer y sigo

[7:50 p. m.] **Tú:** Claro me imagino

[7:50 p. m.] **Tú:** No aca llego mi prima

[7:50 p. m.] **Tú:** Almorzamos hablamos un rato y nos acostamos a dormir

[7:51 p. m.] **Tú:** Me levante adelantar trabajoz

[7:51 p. m.] **Vale 🌙:** A bueno mi amor

[7:51 p. m.] **Tú:** Trabajos

[7:51 p. m.] **Tú:** Y ya

[7:51 p. m.] **Tú:** Ahi dijo

[7:51 p. m.] **Tú:** Sigo

[7:51 p. m.] **Tú:** Pero que mucha ropa

[7:51 p. m.] **Vale 🌙:** Es más como de saber a comodar los zapatos

[7:51 p. m.] **Tú:** [Imagen]

[7:51 p. m.] **Tú:** Ya

[7:51 p. m.] **Tú:**
> _Vale 🌙: Es más como de saber a comodar los zapatos_
Estripar

[7:52 p. m.] **Tú:** Pa que entre todito

[7:52 p. m.] **Tú:** Hechale babas

[7:52 p. m.] **Tú:** Eso entra

[7:52 p. m.] **Vale 🌙:** Jsjdhs

[7:52 p. m.] **Vale 🌙:**
> _Tú: Ya_
Sipi gachas 🥰

[7:52 p. m.] **Tú:** [Sticker]

[7:52 p. m.] **Tú:** [Sticker]

[7:58 p. m.] **Tú:** Si no terminas

[7:58 p. m.] **Tú:** Mañana  te ayudo

[7:58 p. m.] **Vale 🌙:** Vale mi amor

[7:58 p. m.] **Vale 🌙:** Espero que termines todos tus trabajitos

[7:59 p. m.] **Tú:** Pues ya termine por hoy

[7:59 p. m.] **Tú:** Np fue mucho pero funcionó

[7:59 p. m.] **Tú:** Voy a comer

[7:59 p. m.] **Vale 🌙:** Vale mi cielo

[8:53 p. m.] **Tú:** Me cuentas

[8:54 p. m.] **Tú:** Como vas

[8:55 p. m.] **Tú:** Ya terminaste

[9:03 p. m.] **Vale 🌙:** [Imagen] Toy comiendo

[9:04 p. m.] **Tú:** Jojodaa

[9:04 p. m.] **Tú:** Y no invitas

[9:04 p. m.] **Tú:** Jajajas se ve rico vale

[9:04 p. m.] **Tú:** Me guardas

[9:45 p. m.] **Tú:** Como vas

[9:46 p. m.] **Vale 🌙:**
> _Tú: Como vas_
Deje el resto para mañana me ando viendo un drama

[9:49 p. m.] **Tú:** Jajaaj

[9:49 p. m.] **Tú:** Y eso

[9:49 p. m.] **Tú:** Va

[9:49 p. m.] **Tú:** Mañana  a que horas paso

[9:53 p. m.] **Tú:** Y no invitas

[9:53 p. m.] **Tú:** Pa arrunchis

[10:18 p. m.] **Vale 🌙:** Voy a tratar de levantarme temprano y te aviso

[10:21 p. m.] **Tú:** Va mi vida

[10:22 p. m.] **Tú:** Y que andas viendo

[10:49 p. m.] **Vale 🌙:** Familia por desición

[11:41 p. m.] **Tú:** Uyy

[11:41 p. m.] **Tú:** Ni idea

[11:41 p. m.] **Tú:** Si es bueno

[11:41 p. m.] **Tú:** Así como ka que estábamos viendo

[11:41 p. m.] **Tú:** Aca

[11:41 p. m.] **Tú:** Que no lo terminamos

[11:41 p. m.] **Vale 🌙:** Más o menos sii

[11:42 p. m.] **Vale 🌙:**
> _Tú: Que no lo terminamos_
Jsjs si como es que se llama

[11:42 p. m.] **Vale 🌙:** [Mensaje de voz]

[11:44 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Joa

[11:44 p. m.] **Tú:** De esos

[11:44 p. m.] **Tú:** Hay libros muy chimbas

[11:45 p. m.] **Tú:** Pero siempre son los mismo nombres

[11:45 p. m.] **Tú:** Y siempre mencionan Seúl

[11:45 p. m.] **Tú:** Jajajaaj

[11:45 p. m.] **Tú:** Pero ya vas por la mitad

[11:45 p. m.] **Tú:** Prácticamente

[11:45 p. m.] **Tú:**
> _Vale 🌙: Jsjs si como es que se llama_
Ahora miro

[11:45 p. m.] **Vale 🌙:** [Mensaje de voz]

[11:52 p. m.] **Tú:** Joaaa

[11:53 p. m.] **Tú:** Me refiero a que en las series siempre aparece esa escuela

[11:53 p. m.] **Tú:** Y la ciudad

[11:53 p. m.] **Vale 🌙:** [Mensaje de voz]

[11:54 p. m.] **Vale 🌙:**
> _Tú: Y la ciudad_
Si creo en la mayoría

[11:54 p. m.] **Tú:** Me quedé sin wifi

[11:54 p. m.] **Tú:** A punta de datos jsjsjsj

[11:55 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Es como las dietas

[11:55 p. m.] **Tú:** Jajajaaj

[11:55 p. m.] **Tú:** Frutas

[11:55 p. m.] **Tú:** Hay unas que ajá

[11:55 p. m.] **Tú:** Siempre hay unas malas y eso

[11:55 p. m.] **Tú:** Andas con tu bfo

[11:55 p. m.] **Tú:** Najajaj

[11:55 p. m.] **Tú:** Por hay lo escuché como quejandose

[11:55 p. m.] **Vale 🌙:** Jsjsj si

[11:56 p. m.] **Tú:** Yo que me quería ver una serie

[11:56 p. m.] **Vale 🌙:** Lo obligó a ver mis estupideces para poderme quejar Agusto

[11:56 p. m.] **Tú:** O algo mientras me cogia el sueño

[11:56 p. m.] **Tú:** Ya no me puedo con utd

[11:56 p. m.] **Tú:** Jsjsjs

[11:56 p. m.] **Tú:** Turis

[11:56 p. m.] **Tú:**
> _Vale 🌙: Lo obligó a ver mis estupideces para poderme quejar Agusto_
Jajajaaj

[11:56 p. m.] **Tú:** Hay unas que son melas

[11:56 p. m.] **Tú:** Yo me acuerdo que con mi ex mejor amiga

[11:57 p. m.] **Tú:** Me vi

[11:57 p. m.] **Tú:** Una de culpa

[11:57 p. m.] **Tú:** Culpa mía

[11:57 p. m.] **Tú:** Tuya

[11:57 p. m.] **Tú:** De todos modos

[11:57 p. m.] **Tú:** Era buena

[11:58 p. m.] **Vale 🌙:** Así yo también me la vi ya que está basada en una trilogía

[11:59 p. m.] **Vale 🌙:** Igual que bulevar el fabricante de lágrimas y atravez del ti ventana atravez del mar

---

## 18 de agosto de 2026

[12:02 a. m.] **Tú:** Jajaja

[12:02 a. m.] **Tú:** Yo solo me vi

[12:02 a. m.] **Tú:** Esa no soy de muchas series

[12:03 a. m.] **Tú:** Aveces aburren

[12:05 a. m.] **Tú:** Ya ya tengo Netflix

[12:06 a. m.] **Tú:** [Imagen]

[12:06 a. m.] **Tú:** Esaaa

[12:12 a. m.] **Vale 🌙:** La voy a guardar pa verla

[12:13 a. m.] **Vale 🌙:**
> _Tú: Esa no soy de muchas series_
A mi me gustan mi problema es que me quiero ver todas las temporadas en un solo día

[12:13 a. m.] **Vale 🌙:** O lo antes posible por eso prefiero las cortas

[7:32 a. m.] **Tú:** Holiii

[7:32 a. m.] **Tú:** Como estassss

[8:53 a. m.] **Vale 🌙:** Holi buenos días amor

[9:52 a. m.] **Tú:** Que andas haciendo

[9:52 a. m.] **Tú:** Ya terminaste

[10:15 a. m.] **Tú:** ???

[10:15 a. m.] **Tú:** Si necesitas ayuda

[10:16 a. m.] **Vale 🌙:** Si quieres ven

[10:16 a. m.] **Vale 🌙:** Eso sí tengo un poquito de desorden

[10:17 a. m.] **Vale 🌙:** Simpre saque arta ropa que ya no uso

[10:17 a. m.] **Vale 🌙:** Para no llevar todo eso

[10:17 a. m.] **Tú:** Tons me cambio como algo y salgo

[10:17 a. m.] **Vale 🌙:** Vale amor

[11:26 a. m.] **Tú:** Ya voy

[11:26 a. m.] **Tú:** Sale a la panadería

[11:26 a. m.] **Tú:** Que no sé dónde es

[11:26 a. m.] **Vale 🌙:** Voy

[11:28 a. m.] **Vale 🌙:** Me avisas y salgo

[11:28 a. m.] **Tú:** Salga

[11:28 a. m.] **Tú:** La demora e utd

[11:29 a. m.] **Vale 🌙:** Oki

[12:27 p. m.] __[Llamada]__

[2:54 p. m.] **Vale 🌙:** [Reenviado] [Audio]

[3:07 p. m.] **Tú:** [Mensaje de voz]

[5:41 p. m.] **Vale 🌙:** Lunes 9 1:18

[7:43 p. m.] **Tú:** 78.108.218.49:25567

[8:29 p. m.] **Vale 🌙:** Amor me acompañas a lo de la cama

[8:30 p. m.] **Tú:** Ya

[8:30 p. m.] **Tú:** Todavia ando configurando

[8:30 p. m.] **Tú:** Avisas pa salir

[8:33 p. m.] **Vale 🌙:** Ya voy pa tu casa

[8:39 p. m.] **Tú:** Ya llego mi mamá si quieres salimos ahorita

[8:39 p. m.] **Tú:** Es que no hice nada de la comida

[8:40 p. m.] **Tú:** Si quieres quedate donde tu tía o ven

[8:40 p. m.] **Tú:** Y salimos ahorita

[8:42 p. m.] **Tú:** Como quieras

[8:45 p. m.] **Vale 🌙:** [Mensaje de voz]

[8:46 p. m.] **Tú:** [Mensaje de voz]

[8:47 p. m.] **Vale 🌙:** [Mensaje de voz]

[8:48 p. m.] **Vale 🌙:** [Mensaje de voz]

[8:48 p. m.] **Tú:** [Mensaje de voz]

[8:48 p. m.] **Tú:** [Mensaje de voz]

[8:52 p. m.] **Vale 🌙:** Una que mi vida

[8:53 p. m.] **Vale 🌙:** No amor yo ahorita  me voy

[8:55 p. m.] **Tú:** [Mensaje de voz]

[9:15 p. m.] **Vale 🌙:** Amor compré salchipapa pero en otro lado

[9:17 p. m.] **Tú:** Vale

[9:17 p. m.] **Tú:** Y una gaseosa

[9:17 p. m.] **Tú:** Si alcanza

[9:17 p. m.] **Vale 🌙:** Si

[9:17 p. m.] **Tú:** De 1.5

[9:19 p. m.] **Vale 🌙:** Oki amor

[9:37 p. m.] **Tú:** [Mensaje de album]

[9:37 p. m.] **Tú:** [Imagen]

[9:37 p. m.] **Tú:** [Imagen]

[9:37 p. m.] **Tú:** [Imagen]

[9:37 p. m.] **Tú:** [Imagen]

[9:37 p. m.] **Tú:** [Imagen]

[9:37 p. m.] **Tú:** [Imagen]

[9:37 p. m.] **Tú:** [Imagen]

[9:37 p. m.] **Tú:** [Imagen]

[9:37 p. m.] **Tú:** [Imagen]

[9:37 p. m.] **Tú:** [Imagen]

[9:37 p. m.] **Tú:** [Imagen]

[9:37 p. m.] **Tú:** [Imagen]

[10:24 p. m.] **Tú:** Avisas  cuando vayas a jugar

[10:25 p. m.] **Vale 🌙:** [Mensaje de voz]

[10:25 p. m.] **Tú:** Vale

[10:25 p. m.] **Tú:** Yo me demoro 10

[10:26 p. m.] **Tú:** No se si tu bfo

[10:26 p. m.] **Tú:** Te vaya a enseñar

[10:26 p. m.] **Tú:** Pa quitarte el creativo

[10:26 p. m.] **Vale 🌙:** Meno ya le digo

[10:26 p. m.] **Tú:** No pero yo te lo quito

[10:26 p. m.] **Tú:** Por si el va a jugar

[10:26 p. m.] **Tú:** Que no sepa que tenemos  comandos

[10:27 p. m.] **Tú:** Jajajsk

[10:27 p. m.] **Tú:** Ni que hay administradores

[10:27 p. m.] **Tú:** Ni na

[10:27 p. m.] **Tú:** Jaksks

[10:27 p. m.] **Vale 🌙:** Dale amor

[10:28 p. m.] **Vale 🌙:** Amor que versión es esta

[10:29 p. m.] **Tú:** [Mensaje de voz]

[10:30 p. m.] **Vale 🌙:** Vale cielo

[10:35 p. m.] **Tú:** El va a jugar

[10:35 p. m.] **Tú:** Ya sabes igual como colocarle los mods

[10:35 p. m.] **Vale 🌙:** Vale amor

[11:03 p. m.] **Tú:** M

[11:06 p. m.] **Vale 🌙:** [Imagen]

[11:06 p. m.] **Tú:**
> _Vale 🌙: Imagen_
Epaaa

[11:06 p. m.] **Vale 🌙:** Se me avía pagado el cel

[11:18 p. m.] **Tú:** ???

[11:27 p. m.] **Vale 🌙:** Ya amor

[11:36 p. m.] **Tú:** [Imagen]

[11:37 p. m.] **Tú:** [Imagen]

[11:40 p. m.] **Tú:** [Imagen]

---

## 19 de agosto de 2026

[1:16 a. m.] **Vale 🌙:** [Imagen] Mi nuevo fondo

[1:25 a. m.] **Vale 🌙:** [Imagen] Mira lo que ise jiji

[6:03 a. m.] **Tú:** Jajaj

[6:03 a. m.] **Tú:** Esta super

[6:03 a. m.] **Tú:** Pa fondo

[6:03 a. m.] **Tú:** Kajajzk

[6:05 a. m.] **Tú:** A que horas piensas ir por eso

[6:19 a. m.] **Vale 🌙:** A las 8

[6:20 a. m.] **Tú:** Va

[6:20 a. m.] **Tú:** Me avisas antes para alistarme jajaja

[6:20 a. m.] **Vale 🌙:** Ok

[6:21 a. m.] **Tú:** Que  tiene ???

[7:41 a. m.] **Vale 🌙:** Me dormí ya me levanté aliste

[7:47 a. m.] **Vale 🌙:** Amorrr

[7:48 a. m.] __[Llamada]__

[7:56 a. m.] **Tú:** Voy saliendo

[7:56 a. m.] **Vale 🌙:** Listo amor

[8:01 a. m.] **Vale 🌙:** Onde tas

[10:28 a. m.] **Vale 🌙:** [Imagen]

[10:56 a. m.] **Vale 🌙:** [Imagen]

[10:56 a. m.] **Vale 🌙:** [Imagen]

[10:56 a. m.] **Vale 🌙:** [Imagen]

[10:56 a. m.] **Vale 🌙:** [Imagen]

[11:35 a. m.] **Vale 🌙:** [Video]

[12:44 p. m.] **Tú:** Avisa cuando llegues a la terminal y eso

[12:45 p. m.] **Vale 🌙:** Vale amor

[12:49 p. m.] **Tú:** O mándame la ubicación

[12:49 p. m.] **Tú:** Para estar pendiente

[12:49 p. m.] **Vale 🌙:** /9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCABkAGQDASIAAhEBAxEB/8QAHAAAAQUBAQEAAAAAAAAAAAAAAAIDBAUGBwEI/8QAORAAAgIBAwIEAwUHAwUBAAAAAQIDBBEABSESMQYTQVEiMmEHFFJxgSMzQpGhseFTkvAVJEPB0fH/xAAaAQACAwEBAAAAAAAAAAAAAAABAgADBAUG/8QALBEAAgEDAgUCBQUAAAAAAAAAAAECESExAwQFEhNBYSIyBhSBodEkQ1GRwf/aAAwDAQACEQMRAD8A+kKtgS/BIMSDgg+umLEptSeXGf2Y7n30m4VnnCxAFhwW0/EgjTpX+fvo4uDNih8W2bO1bUj7SEW/bsxUoJJRlIXkOPMYeuPb1ONM0tn3TY932iStuG67hXmaSLcnu2OuMjyyVkCk/AesAALxg4PvrQXala/TmqXq8dirMOmSKRcqw1z3xltFnakWntW32LGxzKpippGtqOa4z9rHmEuFICYYEY5OfQsnWwrVLnTpX8texLHgL6k6QOmEdcp+Jj8Teg/xrme3+Ib20bbRrG0Jqe1OIbtyJPNa5OWJWlWByWxkKW7gL6Y1vonsXY4DLC9V5I1kmgZw/lMRyuRwcaDjQPNUWoe3IV6m8hT3PrqbI6V4snhRwAPX6aiI70n6JAWiJ4IGvY0a5L5kgxEPlX30H9gr7nteJrD+fOOP4V17SzFLLAfQ5H5f8xp+xMsEfUe/oPfUEpMoFpvmznp+mpkmBd1uitPGDw0gUfrgn+51AmGYmHuMfz07Zm8+wQnMakPk/i6cY/Qf3026SygrB86jr/l2H6nTwVipsXY6aspjbOO68en/ADj9NGravItiCOUAYdQefTRqhwuUvaqV4uzINZhExidel89/fUrUdw16UlcLGowGI76I5Gjfyp+COzH11a1U1KxI05EM9QIBQjDA9iPbSUXqP003amORBB854JHppRjnvjPZhssMN7Y7UVQQyx0ajPGBX2iJ1PXKB2LM2FMh7df0zqs2/wC0KfYDepXY7t+WN4/KWewkuPg+P9sPmQkgqcE4JyBxrpe8SttHhvc7UAVpYKssvxDIYqhIBHtxr5jtzNDC8rEu5OST6k9ydZd5upaaUY5Z3eB8K095KWrrP0x7fydho/axTsTCLddpkr124MkU3ndP1I6VOPyyfprd1LSCCKzUlWxSnAaN1OQQfbXyzQuPNKUkA7ZBGuy/YpNLar7lSlctWqtHKik9i/VkD6ZTP5k6o2m6nKfT1O5t4xwfQ0tv8ztrUyjpNeJrEnnzjj+FdKv2BEnlqA0jjsewHudOW7Arx5xlzwq+/wDjVVkks7nLtyx100q3PJt0seEhEyx4Hc6mbO6NG/pKx6iD+H0x/wA76ri4JDnkZxGv4j76dii8s9SkiTOeoen5fT6aWc+xklr8s6ImPRso7fdLXlRMeroK5wT3x9NGnI76hcTKwcfhUkH66NN1X4/pFiWi7qVPq1/ok7ntle19wF+kLinpFb7wgkJ746c5zqHcvbfXmxvG5U6Uzr1JFPYSNunJGcMc4yD/ACOuU+MIJ5pPHRmo7adrk3WCGzuEuWnpBooQZVQLyFyDnqBHtjWj8VnyvtVIF/YKwGxQASb1F5qv+3m+X40+L3POhg0ZNjNvVLb4447O6bbF5sYlhaS3GvUh7MMnkHnB1Opy04tuN83KzVSvU1nzlMeM4+fOO/8AXWN+0bc9qmG17BBPtUNvc4V/75/LCVKY+aRC3qclUAPck+mmfEkGz1ZfAtdWpN4RisTRqS6vW81YWEPW2SCeoPyf4vrqENneWPeqTVoXSajajZWljcMroRg4YcY183bvRFLcLe3yTQ2fJcoZInDK49CCD/T0PHprrO1R7W1H7SY6szQ+GG6U83b16kRzXAnaILnsSpIHrnWZs7RX3Vk2avDs1vc6+2G1R3HZm6BPFGyjy5oskBmzwcnntjkaybvb9WFY5R2+CcS+S1uWfslnx5/Jz+GvFX6mQY9yTrtP2abLY2Ta5LFhWhvWiHaNxgogHwqw/Un9cemsv9kvh+HdL8m73lBo0WURq2AJJjggc+2VOPdl11idnkmLyjpYcBfwj21Tw/b/ALsvodD4k4kn+j0sLP4EuzSSNJIcufbsB7DQsEliJmVcxg/7vy9xpBKyKyhvpxq0pWFkQRkBHUfKOxH011JWVjyKVclWqK/V1jJPGPYfTQrGMhJDkH5WPr9D9dWdyp5mXi4k9vfVeDnhuD2wdZ5R7oxa2g4XWBWjSPKj/wBNP5aNIZy6aKNkmVoYis370FBh+MfF78e+q7cYKliRIzSqzTKoRS8KN0KOwGR2/tqnkvX4txobrJuEcm1XpDUWGueqKJJP3MvVj4mLAAnsOsADjJ0tauIAc8yHudaKUyditRk7bTlSMWalSZkQIpeBD0qOyjjgD20m4lSOiaRq13ruOn7sYlMZBOeVxjvp+1YEC+7nsNIqVyGM03Mp559NDyw+EQ1ilpVYo4USCugAWOFAqoPbpHA1IqQbdt0EktKrWriU5cwQqhkb64AydSrEscURaX5Txj3+msjBZ3DcvFW41KW4pttbapoQ1f7ssr2FdAxZmblVOSoK9sEnPbTK4MFRuyVNssihsH3Gw0Jaxe8OBld5QWD+bH1Z/bLgEKcjAAAHGrHwPcubrD5FiaTcaAj82ru6gAzR5wYph3WZTweOQM99U+4eHJN83iYbECKMVx1++NYaOXb7QnLzyBSPjLKVVT2AHsTnohEG3QGOtGis7F26UCmRz3dukAFj6nRtFUQG3NuUnUTfESxpEiDrHyBR8uoUiPFIFcFHHKkH+oOrGpXKEyy8yt7+mmrLfephDEAQpyWx20E+xGq3HKdvzCI5eJPQ+jf517cqiYdSYEn99QJ4Wifok/NWHr/8OplO31ERzH4+yt6N/nUa7oidbMglipKsp6h30auJIY5Gy6Kx9yNGk5YlL20TKeENit1qs1beIHWk0MSGpPa+8q8ysWaVfwKT0kKMc+g1Zbt4lp1xuMCW6tbcIpDWgNxwkUk5jVwO+cDrTPbvjTfime62zpJthnwJC9pK8gjnMIVifLJ9erp+pGcayfh+hJ4kmtSy3YEty7dDDds1ytmO0kikfFkL0TAIM4yMdPHbTxrJc0i52tEufBG47lf3O9Be67lWDqK2pUEcsD9ZXynAVVYkDq+EfDnBzkE629bgoUrFu25jrwRtLIwUsQoGScDk/pr0vFUrJGC/lxR4RACzEKvYDuTgay8u5Tb34au7l4YsLNblryLULrgxSgfuyp+Vx7H1x6anudSe1EXxR4pi2+KjPVWrfa5DJZhd7Bih8lOnPSwVizsXUBQOSfTjUr/pFTxMau5q93at0roIZJas6pYgJVWMEnBVgAwOCOMjtrFeHdl2zdt3p7ds5vna41NyzDZMkFjabIwOqOQDhnOcp2+EsPTXVto22ttNIVaSuE6jI7yOXeR2+Z3Y8lj76aTUcASqRKO1x7JRjg23zGiVmeQysXkldjlndv4iT/jjUmiomdppGDSZ7e2pFqcQJ7uew1WWHjoNTazZSCa5OK8KsD8chDMF4HsrHnjjS5Vw4ZOtzMWEEPLtwT7acjRKkBJPbufc6Z28xLE8jOAwBZ2Y9h3z+Wou2XaviGpX3DbrMdnbJQTFLHnDYJBHPOcgg6HgPkkRxG45lnyI+yqDjUaxA0D9DnqU/K3v+ent73zbNihhfdLkdYSkrEmCzyEDnpVQSccZwONV1nfdmg22tvF/cYH2+5IIa0sQaVZGIY9ICgn+FvTuDopgaJ8d2aNApVZMdmLYOjUbaZIN5rvY2iws1ZXMeZUkiYNgHGGUE9xzo0fSD1FJtLeIavix4Z5prNZT1WhYjYQqvSD5sMmMD4mKiMeiEnHfWtjeCKsfuscUal8hFCp1Of8A2dIjWvtW3w1KocQRDoijaQscegycnA/oMDWM+0Gao2wPQsTVQ73K6WJi2TtgckpOQCCpBACnIHxDPGRpKdV+Bq8hN8R+I6m1ST17NuSvuDxeULXkkwU5JFIi8xuy5PPr7nWf8J0rNbfNvG2Utyo2mTp36O6JHgnx/wCVJTkNIWPwlTyDzgDRFtO673udjbZbFE7hRVhY3E1fOhuxSxqiyMAw6Z1QYAPGGJHB1vqVJNjo06dNHNCrGIo1ZyxA9ySe/wD+casqlZCUbuy2Qv5aq7EkaasTLBH1Hk+g99Ja1EIfMByOwHrn20xDAbBMtjOD8q9tV07ssr2QV48g2rByTyB7azP2hzfdV8LXrIlEEG+RSy9EbP5aCGYZIUE+o/nrRkNVlUSZaDOR9DqxR8qCjcH1B0WBGE8bbgu7+D5o/C4lsW92mG2Rny3iCdf7xj1LlQE6vix3I76T9ngubNuu+bNf2+KhVcruVOOvMZ4kRvgkQP0rz1r1Yx/Hrf8AW34j/PUa3C0sZ6HYHHy54OhUNDFeOJay7ls24TXLuz2okmFfdYq4ngjyVDQyrz8wAIPHI4OqDd7dm34E8IX5oDszrvvmyTUKRGF6bA+8CFlbHXw3xA/N9ddPhu+VGySAo6cdI4zpVQTO5nldgW7KCdEBG8IWo9x2jzIt1tboY5GjezYriByeDjpCIOARyBo1ZPYCHDyhT7FsaNAJnRcszb4K4mMcT7Y8w6UXKyeZgMCQTkDsO3uDrnNvcp9y+z/w/wCLLSxNvX3laE0gQdNmBpCjRyp2YEDOPQ8jGjRq2KoVyOvbZtVDZ6zVdqpV6dfrLmOFAoLHuT9f/mpZ5GDo0aoRaUkoAmkAAABOMfnrxrMy9pG/3HRo1eikDYldCrOSp7g86cjlkiGI3IHtgHRo1KEqL+9T/wCp/QaDcmAz1A/oNGjQaQU2NSytOQz4z24GrOtKz1Q7Y6sH+mjRpZYGjkrQDMS7seonRo0aYU//2Q==: Ubicación en tiempo real: 4.7096633, -74.09519 — https://maps.google.com/?q=4.7096633,-74.09519

[12:49 p. m.] **Tú:** [Sticker]

[1:24 p. m.] **Tú:** So

[1:24 p. m.] **Tú:** Fue rápido

[1:24 p. m.] **Vale 🌙:** Ti

[1:27 p. m.] **Tú:** Me avisas cuando te vayas a montar y eso

[1:27 p. m.] **Tú:** Si pudiste llevar todo ese vulto

[1:32 p. m.] **Vale 🌙:** Tii

[1:32 p. m.] **Vale 🌙:** [Imagen]

[1:33 p. m.] **Tú:**
> _Vale 🌙: Imagen_
Epaa

[1:33 p. m.] **Tú:** Ese era que te decia

[1:33 p. m.] **Tú:** Y ya comiste algo

[1:33 p. m.] **Vale 🌙:** Nop

[1:33 p. m.] **Vale 🌙:** Ya miro que como

[1:33 p. m.] **Tú:** Me avisa cuando comas porque el viaje el largo

[1:36 p. m.] **Vale 🌙:** Vale amor

[1:53 p. m.] **Tú:** Voy a salir a que me den el papel ese

[1:53 p. m.] **Tú:** El cel está muerto me voy a llevar el otro

[1:53 p. m.] **Tú:** No tiene datos pero no creo que me demore mucho

[1:59 p. m.] **Vale 🌙:** Vale amor yo solo tengo WhatsApp

[2:02 p. m.] **Tú:** Ya voy a salir

[2:02 p. m.] **Tú:** Ahora hola mal

[2:02 p. m.] **Tú:** Hablamos

[2:25 p. m.] **Vale 🌙:** Amor tienes 15 que me pases por nequi y apenas mi jefa me consigne te los paso

[2:25 p. m.] **Vale 🌙:** _Se eliminó este mensaje_

[2:30 p. m.] **Vale 🌙:** [Mensaje de album]

[2:30 p. m.] **Vale 🌙:** [Imagen]

[2:30 p. m.] **Vale 🌙:** [Imagen]

[2:30 p. m.] **Vale 🌙:** [Imagen]

[2:30 p. m.] **Vale 🌙:** [Imagen]

[2:30 p. m.] **Vale 🌙:** [Imagen]

[2:30 p. m.] **Vale 🌙:** [Imagen]

[2:58 p. m.] **Tú:** [Mensaje de voz]

[2:58 p. m.] **Tú:**
> _Vale 🌙: Amor tienes 15 que me pases por nequi y apenas mi jefa me consigne te los paso_
Verga

[2:58 p. m.] **Tú:** Te dije que no tenía datos

[2:58 p. m.] **Tú:** Mala mia

[2:58 p. m.] **Tú:** Como vas

[3:01 p. m.] **Vale 🌙:** Ya me consigno

[3:01 p. m.] **Vale 🌙:** Bien amor

[3:01 p. m.] **Tú:** Ahh

[3:01 p. m.] **Tú:** Y eso para que era

[3:01 p. m.] **Tú:** Todavía los necesitas

[3:01 p. m.] **Tú:** O no

[3:01 p. m.] **Tú:** Ya arrancaste

[3:01 p. m.] **Tú:**
> _Vale 🌙: [album]_
Ojo

[3:01 p. m.] **Tú:** Jajajaka

[3:01 p. m.] **Tú:** Todas mis fotos

[3:01 p. m.] **Vale 🌙:** [Mensaje de voz]

[3:01 p. m.] **Tú:** Porque las tienes

[3:02 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Toca que metas un recarga o algo

[3:02 p. m.] **Vale 🌙:**
> _Tú: Porque las tienes_
Por que si jdjd

[3:02 p. m.] **Tú:** Para que aja si quiera mires videos mientras sales

[3:02 p. m.] **Tú:** L así

[3:02 p. m.] **Tú:**
> _Vale 🌙: Por que si jdjd_
Jajajaja

[3:02 p. m.] **Tú:** [Sticker]

[3:03 p. m.] **Vale 🌙:** [Mensaje de voz]

[3:04 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Verga

[3:04 p. m.] **Vale 🌙:** [Mensaje de voz]

[3:04 p. m.] **Tú:** Osea solo tienes efectivo  sk

[3:04 p. m.] **Tú:** Jajaj

[3:04 p. m.] **Vale 🌙:** [Mensaje de voz]

[3:04 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Segura

[3:04 p. m.] **Tú:** Jajaja

[3:04 p. m.] **Tú:** Porque aja

[3:04 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
No fue mucho

[3:04 p. m.] **Tú:** Por severo bulto

[3:04 p. m.] **Vale 🌙:** [Mensaje de voz]

[3:06 p. m.] **Tú:** Igiak toca que lleves algo para el camino

[3:06 p. m.] **Tú:** Asi sea mani

[3:06 p. m.] **Tú:** Algo que no sea tan fuerte

[3:06 p. m.] **Tú:** Para que no te pegue el olor

[3:06 p. m.] **Tú:** Y que operador eres tu

[3:06 p. m.] **Vale 🌙:** Claro

[3:07 p. m.] **Vale 🌙:**
> _Tú: Igiak toca que lleves algo para el camino_
[Mensaje de voz]

[3:07 p. m.] **Tú:** Manii

[3:07 p. m.] **Tú:** Eso no tiene olor

[3:07 p. m.] **Vale 🌙:**
> _Tú: Eso no tiene olor_
Bueno

[3:07 p. m.] **Tú:** Y es bueno pa que calme el hambre

[3:07 p. m.] **Tú:** Este  es tu número

[3:08 p. m.] **Tú:** Osea el que usas para datos

[3:08 p. m.] **Vale 🌙:** Sii es el que uso para todo

[3:08 p. m.] **Tú:** Mira si te llego

[3:08 p. m.] **Tú:** Una de 5k

[3:08 p. m.] **Tú:** Pa que no se aburra

[3:08 p. m.] **Tú:** Jajaaj

[3:09 p. m.] **Vale 🌙:** Si amor

[3:11 p. m.] **Tú:** Dalw

[3:11 p. m.] **Tú:** Me avisas cuando arranques entonces

[3:11 p. m.] **Tú:** Cómprate algo para el camino mecato

[3:11 p. m.] **Tú:** Algo

[3:15 p. m.] **Vale 🌙:** [Mensaje de voz]

[3:16 p. m.] **Vale 🌙:** [Mensaje de voz]

[3:19 p. m.] **Vale 🌙:** [Video]

[3:20 p. m.] **Tú:** [Mensaje de voz]

[3:20 p. m.] **Tú:**
> _Vale 🌙: Video_
Najakaaj

[3:20 p. m.] **Tú:** Me graba infragantu

[3:22 p. m.] **Vale 🌙:** A bueno amor si claro te entiendo

[3:32 p. m.] **Vale 🌙:** Me acabo de montar y e intentado vomitar 2 veses por el olor del bus

[3:37 p. m.] **Vale 🌙:** [Imagen]

[3:37 p. m.] **Vale 🌙:** Ya me tomé un mareol

[3:37 p. m.] **Tú:** Jajaj

[3:37 p. m.] **Tú:** Dame

[3:37 p. m.] **Tú:** Dale de

[3:37 p. m.] **Tú:** Y mi snoopy

[3:37 p. m.] **Tú:** Donde lo dejaste

[3:37 p. m.] **Tú:** No lo llevaste

[3:38 p. m.] **Vale 🌙:** Esta guardado en mi ropa solo que como es blanco y ando con el bulto cada rato me toca dejar los peluches en el piso

[3:38 p. m.] **Tú:** Jajaaj

[3:38 p. m.] **Tú:** Buenoo

[3:38 p. m.] **Tú:** Ya vas a salir

[3:38 p. m.] **Tú:** De la terminal

[3:39 p. m.] **Vale 🌙:** El hello Kitty ya tiene la parte de atrás de la cabeza café

[3:39 p. m.] **Tú:** Jajaajaja

[3:39 p. m.] **Tú:** Alla lavas todo

[3:39 p. m.] **Vale 🌙:** Sii

[3:39 p. m.] **Tú:** Orgánizaa

[3:39 p. m.] **Tú:** Y eso

[3:39 p. m.] **Tú:** Procura  llegar primero

[3:40 p. m.] **Vale 🌙:**
> _Tú: Procura  llegar primero_
Si amor

[3:41 p. m.] **Vale 🌙:** Estoy respirando mi peluche mientras el mareol hace efecto por que cada que me lo quito de la cara y siento el olor a bus me dan ganas de vomitar

[3:41 p. m.] **Vale 🌙:** _Esperando el mensaje… Esto puede demorar un poco._

[3:41 p. m.] **Tú:** Le hubieras hechado algún tipo de olor

[3:41 p. m.] **Tú:** Para que aja

[3:41 p. m.] **Tú:**
> _Vale 🌙: Imagen_
Jsjsjs

[3:41 p. m.] **Tú:** [Sticker]

[3:42 p. m.] **Vale 🌙:**
> _Tú: Le hubieras hechado algún tipo de olor_
Solo llevo el desodorante y el perfume que me dio tu mama

[3:46 p. m.] **Tú:** Si

[3:46 p. m.] **Tú:** Lit me acabo de llamar

[3:47 p. m.] **Tú:** Para preguntar si llevaste eso

[3:50 p. m.] **Vale 🌙:** Tan bonita

[3:50 p. m.] **Vale 🌙:** Tu si le llevaste el vestido

[4:03 p. m.] **Tú:** Siii

[4:03 p. m.] **Tú:** Ahi lo deje

[4:03 p. m.] **Tú:** Igual dile tu

[7:18 p. m.] **Tú:** Cómo vas

[7:19 p. m.] **Tú:** Ya llegaste

[7:19 p. m.] **Tú:**
> _Vale 🌙: Video_
[Sticker]

[7:19 p. m.] **Vale 🌙:** Jumm todavía le falta resto

[7:19 p. m.] **Tú:** Por dónde vas

[7:19 p. m.] **Tú:** Ya rato sin saber de ti

[7:19 p. m.] **Tú:** [Sticker]

[7:21 p. m.] **Vale 🌙:** Amor me faltan como 5 horas me quedé dormida

[7:21 p. m.] **Tú:** Me lo imaginé

[7:21 p. m.] **Tú:** También me acabo de levantar

[7:21 p. m.] **Tú:** Estaba viendo una serie

[7:21 p. m.] **Tú:** Una novela de esas k

[7:21 p. m.] **Tú:** Jajaja

[7:22 p. m.] **Tú:** Y como vas con eso

[7:22 p. m.] **Tú:** Tranqui

[7:22 p. m.] **Vale 🌙:** Ya mejor amor

[7:22 p. m.] **Tú:** Ta bien

[7:23 p. m.] **Tú:** Y si compraste algo para el camino

[7:23 p. m.] **Vale 🌙:** Voy acostada

[7:23 p. m.] **Vale 🌙:**
> _Tú: Y si compraste algo para el camino_
Jugo

[7:23 p. m.] **Tú:** Jajaja

[7:23 p. m.] **Tú:** Como así

[7:23 p. m.] **Tú:** Que acostada Jsjsjs

[7:23 p. m.] **Tú:** No se subió mucha gente

[7:23 p. m.] **Tú:** O te dejaron acostar la silla

[7:23 p. m.] **Vale 🌙:** Tengo dos sillas

[7:23 p. m.] **Tú:** Opaaa

[7:24 p. m.] **Tú:** Y no me llevo

[7:24 p. m.] **Tú:** Que grosera

[7:24 p. m.] **Tú:** Bajajaj

[7:24 p. m.] **Tú:** Y eso

[7:24 p. m.] **Tú:** Porque dos

[7:24 p. m.] **Vale 🌙:** Pues sobraron puestos

[7:24 p. m.] **Tú:** Que bien

[7:24 p. m.] **Tú:** Mejor

[7:24 p. m.] **Tú:** Que puedas descansar jsjsjssk

[7:24 p. m.] **Vale 🌙:** Como es de dos pisos yo voy en el segundo

[7:24 p. m.] **Tú:** Y como no me aparece ni tu ubi

[7:24 p. m.] **Vale 🌙:**
> _Tú: Que puedas descansar jsjsjssk_
Pues igual es incomodo

[7:24 p. m.] **Tú:** Me apareces acá todavía Jajajaaj

[7:25 p. m.] **Tú:**
> _Vale 🌙: Pues igual es incomodo_
Pero mejor que ir sentado

[7:25 p. m.] **Tú:** Si es

[7:25 p. m.] **Tú:** Hay te vas acomodando

[7:25 p. m.] **Tú:** Mientras llegas

[7:25 p. m.] **Vale 🌙:** Estoy en villeta

[7:26 p. m.] **Vale 🌙:** Este Man va modo tortuga

[7:26 p. m.] **Tú:** Alcanzo

[7:26 p. m.] **Tú:** A llegar

[7:26 p. m.] **Tú:** Dile que me demoro dos horitas en llegar

[7:26 p. m.] **Tú:**
> _Vale 🌙: Este Man va modo tortuga_
Si me imagino

[7:26 p. m.] **Tú:** Para apenas ir en violeta

[7:26 p. m.] **Vale 🌙:**
> _Tú: Dile que me demoro dos horitas en llegar_
Jsjsj te amo

[7:26 p. m.] **Tú:** Pero es bonito el parque jajajs

[7:28 p. m.] **Tú:** No compraste nada de comida

[7:28 p. m.] **Tú:** ???

[7:37 p. m.] **Vale 🌙:** Nop

[7:39 p. m.] **Vale 🌙:** [Imagen]

[7:39 p. m.] **Vale 🌙:** Ahorita que pare de nuevo compro algo

[7:39 p. m.] **Vale 🌙:** El Man se metió por la ruta vieja envés de por ruta del sol así que peor

[8:01 p. m.] **Tú:**
> _Vale 🌙: Imagen_
Esos ojos

[8:01 p. m.] **Tú:** Bajajaja

[8:01 p. m.] **Tú:**
> _Vale 🌙: El Man se metió por la ruta vieja envés de por ruta del sol así que peor_
Encerio

[8:01 p. m.] **Tú:** Quién sabe porque

[8:01 p. m.] **Tú:** Será por lo del sismo

[8:01 p. m.] **Tú:** O por tráfico

[8:01 p. m.] **Tú:** Me vas contando

[8:34 p. m.] **Vale 🌙:** Hay también tráfico

[8:41 p. m.] **Vale 🌙:** Ubicación: 5.0672217, -74.5607817 — https://maps.google.com/?q=5.0672217,-74.5607817

[8:41 p. m.] **Vale 🌙:** Ubicación en tiempo real: 5.068465, -74.5602183 — https://maps.google.com/?q=5.068465,-74.5602183

[8:42 p. m.] **Tú:** No vas ni por la mitad

[8:42 p. m.] **Tú:** Todavía

[8:42 p. m.] **Tú:** Me avisas cuando hagas parada

[8:43 p. m.] **Vale 🌙:** Y simpre hay trancon Por que  esta es ruta de mercancías

[9:00 p. m.] **Tú:** Me imagino

[9:00 p. m.] **Tú:** Pero si está avanzando medio rápido o como lo ves

[9:00 p. m.] **Tú:** Y tu que ibas a salir más tarde

[9:01 p. m.] **Tú:** Mi madre ya llegó por si le quieres escribir

[9:28 p. m.] **Tú:** Apenas vas a mitad

[9:29 p. m.] **Vale 🌙:**
> _Tú: Apenas vas a mitad_
😭

[9:29 p. m.] **Tú:** No se mueve nada

[9:29 p. m.] **Tú:** Cómo vas del dolor de espalda

[9:29 p. m.] **Vale 🌙:** Tengo los pieza congelado literal me duelen los deditos

[9:29 p. m.] **Tú:** Y no te llevaste esas medias gruesas que tienes

[9:29 p. m.] **Tú:** Póntelas no las tienes en la maleta

[9:30 p. m.] **Tú:** O la maleta está en el baúl

[9:30 p. m.] **Vale 🌙:** Nop

[9:30 p. m.] **Vale 🌙:** Todo eso está en el bulto amor

[9:30 p. m.] **Tú:** Vergass

[9:30 p. m.] **Tú:** Precioso

[9:31 p. m.] **Tú:** Y en la maleta que llevas

[9:31 p. m.] **Tú:** Aparte del pc

[9:31 p. m.] **Tú:** Que supongo que no lo mandaste a bodega

[9:32 p. m.] **Vale 🌙:** El secador perfume  desodorante cepillo bloqueador  cargador billetera y un bolsito con mis labiales anillo collares y eso

[9:32 p. m.] **Vale 🌙:**
> _Tú: Que supongo que no lo mandaste a bodega_
Obio nop

[9:32 p. m.] **Tú:**
> _Vale 🌙: El secador perfume  desodorante cepillo bloqueador  cargador billetera y un bolsito con mis labiales anillo collares y eso_
Conecta ese secador

[9:33 p. m.] **Tú:** Y te das en los pies que mas

[9:33 p. m.] **Tú:** Puedes hacer

[9:33 p. m.] **Tú:**
> _Vale 🌙: Obio nop_
Jajajaaj

[9:33 p. m.] **Tú:** Contigo no se sabe

[9:33 p. m.] **Vale 🌙:** Tengo cargando el cel

[9:33 p. m.] **Tú:** Hay si no sabría qué decirte

[9:33 p. m.] **Tú:** Mira si puedes sacar un saco

[9:33 p. m.] **Tú:** Del bulto

[9:33 p. m.] **Vale 🌙:** No pues ya no modo

[9:33 p. m.] **Tú:** Si te dejan en una parada que hagan

[9:34 p. m.] **Tú:** Lo sacas por un ladito

[9:34 p. m.] **Vale 🌙:**
> _Tú: Mira si puedes sacar un saco_
Tengo dos puestos uno mío y el tuyo

[9:34 p. m.] **Tú:** Y te lo pones en los pies

[9:34 p. m.] **Tú:**
> _Vale 🌙: Tengo dos puestos uno mío y el tuyo_
Bueno uno para los pies

[9:34 p. m.] **Tú:** Eso mientras llegues bien

[9:34 p. m.] **Tú:** Como estés envuelta es lo de menos

[9:34 p. m.] **Tú:** Jsjsj

[9:34 p. m.] **Vale 🌙:** Bueno sii

[9:34 p. m.] **Tú:** Si sacalo

[9:34 p. m.] **Tú:** Eso no está muy amarrado

[9:35 p. m.] **Tú:** Por un ladito lo buscas

[9:35 p. m.] **Tú:** Mientras aguanta

[9:35 p. m.] **Tú:** Y mira videoitos Jsjsj

[9:37 p. m.] **Vale 🌙:** Me puse uno de los que tengo puestos en los pies

[9:37 p. m.] **Vale 🌙:**
> _Tú: Y mira videoitos Jsjsj_
Eso aho para no marearme

[9:37 p. m.] **Tú:** Epa

[9:37 p. m.] **Tú:** Mientras

[9:37 p. m.] **Tú:** Para que cojas un poco de calor

[9:37 p. m.] **Tú:**
> _Vale 🌙: Eso aho para no marearme_
Jajajajaja

[9:37 p. m.] **Tú:** Muy suave te hubieras llevado un libro

[9:40 p. m.] **Vale 🌙:** Tii

[9:41 p. m.] **Vale 🌙:** Si creo

[9:57 p. m.] **Vale 🌙:** [Imagen] Paramos en honda

[9:57 p. m.] **Tú:** Por lo menos no te demoraste mucho el llegar si vi por tu ubicación

[9:57 p. m.] **Tú:** Que estabas cerca

[9:58 p. m.] **Tú:** Aprovecha

[9:58 p. m.] **Tú:** Y saca y compra lo que necesites

[9:58 p. m.] **Vale 🌙:** Hay dios mío yo quiero es llegar ya

[9:58 p. m.] **Tú:** Un tinto algo

[9:58 p. m.] **Tú:**
> _Vale 🌙: Hay dios mío yo quiero es llegar ya_
J

[9:58 p. m.] **Tú:** Ojalá que lo que falta sea rápido

[9:58 p. m.] **Vale 🌙:** Flaco sabes que es lo peor que no veo un hp tienda

[9:58 p. m.] **Tú:** Y la de los tintos

[9:59 p. m.] **Tú:** Ni nada

[9:59 p. m.] **Vale 🌙:** Nop

[10:07 p. m.] **Vale 🌙:** [Mensaje de voz]

[10:15 p. m.] **Tú:** Verga

[10:16 p. m.] **Tú:** Jsjssj

[10:16 p. m.] **Tú:** Tan rápido

[10:16 p. m.] **Tú:** No y no tengo mas

[10:16 p. m.] **Tú:** Para hacerte otra recarga

[10:16 p. m.] **Tú:** Voy a ver

[10:16 p. m.] **Vale 🌙:** No deja así amor

[10:17 p. m.] **Tú:** Ahora

[10:17 p. m.] **Tú:** Y como vas

[10:17 p. m.] **Tú:** Ya arrancaron

[10:17 p. m.] **Tú:** Si alcanzas a comprar

[10:17 p. m.] **Tú:** O sacar algo

[10:18 p. m.] **Vale 🌙:** Apenas arrancaron

[10:18 p. m.] **Tú:** Si sacaste algo

[10:18 p. m.] **Tú:** Porque en los buses siempre va hacer frio

[10:19 p. m.] **Vale 🌙:** Nada cielo voy en el bus

[10:19 p. m.] **Tú:** [Imagen]

[10:19 p. m.] **Tú:**
> _Vale 🌙: Nada cielo voy en el bus_
Verga

[10:19 p. m.] **Tú:** Pensé que sacaste algo por lo menos

[10:19 p. m.] **Tú:** Porque más paradas complicado

[10:19 p. m.] **Tú:** No de donde mas

[10:20 p. m.] **Vale 🌙:** No mi cielo pues ya no tengo tanto frío

[10:20 p. m.] **Tú:** En la dorada hará otra parada

[10:20 p. m.] **Tú:** Supongo

[10:20 p. m.] **Tú:**
> _Vale 🌙: No mi cielo pues ya no tengo tanto frío_
Mejor

[10:20 p. m.] **Vale 🌙:** Si

[10:20 p. m.] **Tú:** Igual arrunchate ahí

[10:20 p. m.] **Tú:** Mientras

[10:20 p. m.] **Tú:** Consigues algo caliente

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Mensaje de unknown]

[10:21 p. m.] **Vale 🌙:** Jshs te amo

[10:25 p. m.] **Vale 🌙:** [Mensaje de album]

[10:25 p. m.] **Vale 🌙:** [Imagen]

[10:25 p. m.] **Vale 🌙:** [Imagen]

[10:25 p. m.] **Vale 🌙:** [Imagen]

[10:25 p. m.] **Tú:** Tú hiciste unas fotos

[10:25 p. m.] **Tú:** Como de minecraft

[10:25 p. m.] **Tú:** Que las hiciste

[10:25 p. m.] **Tú:** La iba a poner

[10:26 p. m.] **Tú:** Las borraste

[10:26 p. m.] **Tú:** No las veo

[10:26 p. m.] **Vale 🌙:**
> _Vale 🌙: Imagen: Mira lo que ise jiji_
Cual está

[10:26 p. m.] **Tú:** Epaaaya ya

[10:26 p. m.] **Tú:** Jajaja

[10:27 p. m.] **Vale 🌙:**
> _Tú: La iba a poner_
De que jiji

[10:30 p. m.] **Tú:** [Imagen]

[10:33 p. m.] **Vale 🌙:** Asas me encanta amor mío 😍😍

[10:46 p. m.] **Vale 🌙:** [Imagen]

[10:46 p. m.] **Tú:**
> _Vale 🌙: Imagen_
Ajajaja

[10:46 p. m.] **Tú:** Tienes el computador con carga

[10:47 p. m.] **Tú:** Ese milagro jajaja

[10:47 p. m.] **Tú:** Está bien bonito

[10:47 p. m.] **Tú:**
> _Vale 🌙: Imagen: Me encanta 😍 🌙_
😍

[10:47 p. m.] **Tú:**
> _Vale 🌙: Imagen: Me encanta 😍 🌙_
😍

[10:47 p. m.] **Tú:**
> _Vale 🌙: Imagen: Me encanta 😍 🌙_
😍

[10:51 p. m.] **Vale 🌙:** [Mensaje de voz]

[10:52 p. m.] **Vale 🌙:** [Imagen]

[10:52 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Epa te rindió

[10:53 p. m.] **Tú:** Menos mal va más rápido

[10:53 p. m.] **Tú:** Epa me avisas cuando arranques

[10:55 p. m.] **Vale 🌙:** [Mensaje de voz]

[10:55 p. m.] **Vale 🌙:** [Mensaje de voz]

[10:56 p. m.] **Vale 🌙:** [Mensaje de voz]

[11:02 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Jajajaj

[11:02 p. m.] **Tú:** Como asi

[11:02 p. m.] **Tú:** Ya está haciendo calor

[11:02 p. m.] **Tú:** Jajaja

[11:02 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Boa

[11:02 p. m.] **Tú:** Joa

[11:02 p. m.] **Tú:** Si te quejas

[11:02 p. m.] **Tú:** Jajaja

[11:02 p. m.] **Tú:** Eso valen frente al hospital

[11:02 p. m.] **Tú:** El paquete de papas si está hp

[11:03 p. m.] **Vale 🌙:** Sii

[11:04 p. m.] **Tú:** Bueno ya estás cerca menos mal

[11:04 p. m.] **Tú:** Y de ahí como cojes pa la casa

[11:05 p. m.] **Vale 🌙:** [Imagen]

[11:07 p. m.] **Tú:**
> _Vale 🌙: Imagen_
Jajaja

[11:07 p. m.] **Tú:** Ahh no

[11:07 p. m.] **Tú:** Mera cometrapo

[11:07 p. m.] **Tú:** Jsksks

[11:07 p. m.] **Tú:** Y la niña que no quiso ni desayunar

[11:07 p. m.] **Tú:** Más rar

[11:07 p. m.] **Vale 🌙:** Jdjd la cuestión es de hambre

[11:10 p. m.] **Vale 🌙:** [Imagen]

[11:14 p. m.] **Tú:**
> _Vale 🌙: Imagen_
Y esa reina

[11:14 p. m.] **Tú:** Estás como medio despelucada

[11:15 p. m.] **Tú:** Jajaj

[11:15 p. m.] **Tú:**
> _Vale 🌙: Jdjd la cuestión es de hambre_
Hay verás si no

[11:17 p. m.] **Vale 🌙:** [Mensaje de voz]

[11:20 p. m.] **Vale 🌙:** [Video]

[11:21 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Pues el viaje ya va más de 5 horas

[11:21 p. m.] **Tú:**
> _Vale 🌙: Video_
Jajajaajaj

[11:22 p. m.] **Tú:** Parchadita

[11:22 p. m.] **Tú:** Por lo menos hay televisión

[11:22 p. m.] **Vale 🌙:**
> _Tú: Por lo menos hay televisión_
Nop

[11:23 p. m.] **Tú:** Joa

[11:23 p. m.] **Tú:** Que aburrimiento

[11:23 p. m.] **Tú:** En plena noche

[11:28 p. m.] **Vale 🌙:** Ni modo ando es jugando candy chuch

[11:29 p. m.] **Tú:** Conque te dure la beteria

[11:29 p. m.] **Tú:** Y te quite el aburrimiento

[11:29 p. m.] **Tú:** Todo bien

[11:39 p. m.] **Vale 🌙:** Sipo

[11:47 p. m.] **Tú:** Como vas

[11:47 p. m.] **Tú:** Ya pasaste el río

[11:52 p. m.] **Vale 🌙:** Ni idea cielo

[11:52 p. m.] **Tú:** El puerto

[11:53 p. m.] **Tú:** Es que no puedo ver la ubi

[11:53 p. m.] **Tú:** Esta bien arriba

[11:53 p. m.] **Tú:** El rio magdalena

[11:53 p. m.] **Tú:** Ya lo pasaste o todavía sigues subiendo

[11:56 p. m.] **Vale 🌙:** Estoy a 225 de Medellín

[11:57 p. m.] **Tú:** Minutos o kilómetros

[11:57 p. m.] **Tú:** Jajaja

[11:57 p. m.] **Tú:** Ya pasate la mitad

[11:57 p. m.] **Tú:** De acá allá

[11:57 p. m.] **Tú:** A las 2 estas llegando

[11:57 p. m.] **Tú:** Y hay donde te bajas o que

[11:57 p. m.] **Tú:** Para ir a la casa

[11:59 p. m.] **Tú:** Mañana voy a chambeae

---

## 20 de agosto de 2026

[12:00 a. m.] **Tú:** Asi que te acompaño hasta donde me coja  el sueño

[12:00 a. m.] **Vale 🌙:**
> _Tú: Y hay donde te bajas o que_
El la terminal y carro

[12:06 a. m.] **Tú:** Ta bien

[12:06 a. m.] **Tú:** Me avisas cuando pases el rio

[5:23 a. m.] **Vale 🌙:** Ya estoy en la terminal

[6:09 a. m.] **Vale 🌙:** Acabo de llegar a mi casa

[6:33 a. m.] **Tú:** Holii

[6:33 a. m.] **Tú:** Yerda

[6:33 a. m.] **Tú:** Madrugaste

[6:33 a. m.] **Tú:** Siempre estuvo largo el viaje

[6:34 a. m.] **Tú:** Que te dijo tu mami

[6:35 a. m.] **Vale 🌙:** [Mensaje de voz]

[7:10 a. m.] **Tú:** [Imagen]

[7:16 a. m.] **Vale 🌙:** 😍

[8:02 a. m.] **Vale 🌙:** Voy a llevar a bb a una cita

[8:03 a. m.] **Vale 🌙:** [Video]

[8:41 a. m.] **Vale 🌙:** [Imagen]

[8:47 a. m.] **Tú:** [Imagen]

[8:47 a. m.] **Tú:** Yo ya estoy con mi gordito  bello

[8:47 a. m.] **Tú:**
> _Vale 🌙: Video_
Hermosa mi mujer

[8:48 a. m.] **Tú:**
> _Vale 🌙: Voy a llevar a bb a una cita_
Y eso

[8:48 a. m.] **Vale 🌙:** [Mensaje de voz]

[12:05 p. m.] **Tú:** [Imagen]

[12:05 p. m.] **Tú:** Apenas termine

[12:05 p. m.] **Tú:** De hacer unas cosas

[12:05 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Y eso

[12:05 p. m.] **Tú:** Porque no tuvo clase

[12:05 p. m.] **Tú:** Por los exámenes

[12:07 p. m.] **Vale 🌙:** Ando onde trabaja mi mami

[12:07 p. m.] **Vale 🌙:** [Video]

[4:01 p. m.] **Tú:** [Video]

[4:22 p. m.] **Vale 🌙:** [Imagen]

[4:22 p. m.] **Vale 🌙:** A bueno amor yo estaba almorzando

[5:45 p. m.] **Tú:** Ahh que bueno

[5:45 p. m.] **Tú:** un poco tarde no

[5:45 p. m.] **Tú:** Si compraste el mouse

[5:45 p. m.] **Tú:** Si fuiste a lo de los exámenes

[5:45 p. m.] **Tú:** No que hoy tenías algo de tu trabajo

[7:48 p. m.] **Vale 🌙:**
> _Tú: Si compraste el mouse_
No amor

[7:49 p. m.] **Vale 🌙:**
> _Tú: No que hoy tenías algo de tu trabajo_
Si me sacaron sangre hoy

[8:35 p. m.] **Tú:** Encontraste el de tu casa

[8:35 p. m.] **Tú:**
> _Vale 🌙: Video_
Rosa

[8:35 p. m.] **Tú:** Y esa linda

[8:35 p. m.] **Tú:** Y eso que es una casa

[8:35 p. m.] **Tú:** Donde ella trabaja

[8:36 p. m.] **Vale 🌙:** Sip

[8:36 p. m.] **Vale 🌙:**
> _Tú: Rosa_
Si solo que eso es adentro del local

[8:38 p. m.] **Tú:** Como así

[8:38 p. m.] **Tú:** Ósea ella trabaja donde Jajaj

[8:38 p. m.] **Tú:** Toca que me muestres bien

[8:38 p. m.] **Tú:** Y como. Te fue hoy

[8:39 p. m.] **Tú:** Que hiciste con tu hermana

[8:39 p. m.] **Tú:** Cuando empiezas

[8:47 p. m.] **Tú:** Mi mamá por hay

[8:47 p. m.] **Tú:** Te anda preguntando

[8:48 p. m.] **Tú:** tú ya siquiera le escribiste

[9:22 p. m.] **Vale 🌙:** Hoy no le e escrito

[9:23 p. m.] **Vale 🌙:**
> _Tú: Cuando empiezas_
Hoy me ise los exámenes empiezo el lunes

[9:23 p. m.] **Vale 🌙:**
> _Tú: Y como. Te fue hoy_
Bien me la pasé durmiendo después de llegar me llegó el periodo tengo mareo dolor de cabeza y cólicos

[9:24 p. m.] **Vale 🌙:**
> _Tú: Que hiciste con tu hermana_
[Video]

[9:24 p. m.] **Vale 🌙:** No e ni desempacado

[9:25 p. m.] **Vale 🌙:** Me toca pedir una visita por que el internet dejo de funcionar pero el pago está al día

[10:03 p. m.] **Tú:** [Imagen]

[10:03 p. m.] **Tú:** [Mensaje de unknown]

[10:03 p. m.] **Tú:** [Video]

[10:04 p. m.] **Vale 🌙:** Si te conté que shey hace un tiempo tiene novio y se tatuó su inicial

[10:05 p. m.] **Vale 🌙:** Por hay me contó anda toda feliz

[10:16 p. m.] **Tú:**
> _Vale 🌙: Hoy no le e escrito_
Me imagino

[10:16 p. m.] **Tú:**
> _Vale 🌙: Hoy me ise los exámenes empiezo el lunes_
Que bien

[10:16 p. m.] **Tú:** Y en que vas a trabajar  al fin

[10:16 p. m.] **Tú:**
> _Vale 🌙: Bien me la pasé durmiendo después de llegar me llegó el periodo tengo mareo dolor de cabeza y cólicos_
Verga

[10:16 p. m.] **Tú:** Te llego de todo hoy

[10:16 p. m.] **Tú:** Lo bueno es que empiezas hasta el lunes

[10:16 p. m.] **Tú:** Tienes tiempo  para reposar

[10:17 p. m.] **Tú:**
> _Vale 🌙: Video_
Pero no entendí que era

[10:17 p. m.] **Tú:** Ella misma lo hizo

[10:17 p. m.] **Tú:** Parece una pelota

[10:17 p. m.] **Tú:** Anti estrés

[10:17 p. m.] **Tú:**
> _Vale 🌙: Me toca pedir una visita por que el internet dejo de funcionar pero el pago está al día_
Verga

[10:17 p. m.] **Tú:** Enserio

[10:17 p. m.] **Tú:** Yo pensé, que ya estabas bien por ese lado por lo menos

[10:17 p. m.] **Tú:** Osea andas suave de Internet

[10:18 p. m.] **Tú:**
> _Vale 🌙: Por hay me contó anda toda feliz_
La inicial

[10:18 p. m.] **Tú:** Esas indirectas

[10:18 p. m.] **Tú:** Chevere

[10:18 p. m.] **Tú:** Pero nada relevante la verdad

[10:18 p. m.] **Tú:** Se lo borra o lo cambia por otro nombre donde terminen

[10:19 p. m.] **Tú:** Todo el nombre  si me deja sin palabras

[10:19 p. m.] **Tú:** Y eso

[10:19 p. m.] **Tú:** Te escribo para eso

[10:19 p. m.] **Tú:** [Sticker]

[10:20 p. m.] **Tú:** Que andas haciendo

[10:29 p. m.] **Vale 🌙:**
> _Tú: Anti estrés_
Básicamente si si la ISO ella

[10:29 p. m.] **Vale 🌙:**
> _Tú: Osea andas suave de Internet_
Poues Masó amor

[10:30 p. m.] **Vale 🌙:**
> _Tú: Se lo borra o lo cambia por otro nombre donde terminen_
Si la verdad quedé re tiesa esa vaina le toca hacer e black aut jsjs

[10:30 p. m.] **Vale 🌙:**
> _Tú: Te escribo para eso_
Si me pareció raro pero bueno

[10:31 p. m.] **Vale 🌙:** Nada mi hermana estaba jugando en creativo de mi CEL

[10:31 p. m.] **Vale 🌙:** Mañana miro si compro lo del maus

[10:54 p. m.] **Vale 🌙:** Amor el internet está bien pero voy a cargar el compu

[10:57 p. m.] **Vale 🌙:** Me voy a bañar

[10:57 p. m.] **Tú:** Vale mi amor

[10:57 p. m.] **Tú:** Y eso que no hablabas ni a mi

[10:57 p. m.] **Tú:** Pensé que ibas a jugar

[10:58 p. m.] **Tú:** Va entras si vas a jugar

[10:58 p. m.] **Tú:** Y porque se escuchaban como gritos

[10:58 p. m.] **Tú:** Besos en esa tota

[10:58 p. m.] **Vale 🌙:** Si amor puse fue a cargar el comou

[10:58 p. m.] **Vale 🌙:**
> _Tú: Y porque se escuchaban como gritos_
Mi hermana cuando le ago cosquillas no se ríe sino que grita

[10:59 p. m.] **Vale 🌙:**
> _Tú: Va entras si vas a jugar_
Entre y casi me matan una oleada de zombis luego me caí en un volcán pero no en la parte de la lav a

[10:59 p. m.] **Tú:** Y porque no dices que te ayudehajasj

[10:59 p. m.] **Tú:** Pero te vi vica

[11:00 p. m.] **Tú:** Viva

[11:00 p. m.] **Vale 🌙:**
> _Tú: Viva_
Por que me tele trasporte para salir del volcán

[11:00 p. m.] **Vale 🌙:**
> _Tú: Y eso que no hablabas ni a mi_
Esque no se qué decir y pues me da cosita abalr con tus amigos

[11:08 p. m.] **Tú:** Pues habla conmigo

[11:08 p. m.] **Tú:** Mientras

[11:08 p. m.] **Tú:** Jajaja

[11:09 p. m.] **Tú:**
> _Vale 🌙: Por que me tele trasporte para salir del volcán_
Tramposa

[11:09 p. m.] **Vale 🌙:**
> _Tú: Tramposa_
[Mensaje de voz]

[11:11 p. m.] **Tú:** Que excusas bueno mandas foto cuenta

[11:11 p. m.] **Tú:** En cuera

[11:12 p. m.] **Tú:** Entra y juegan un rato

[11:12 p. m.] **Tú:** Yo creo que me acuesto temprano

[11:18 p. m.] **Vale 🌙:** Vale ya estoy entrando

[11:21 p. m.] **Vale 🌙:** Ya toy en el juego

[11:43 p. m.] __[Llamada]__

[11:45 p. m.] **Vale 🌙:** Ya esque mi mami va a mimir

[11:46 p. m.] **Vale 🌙:** Ya puse los fondo al contrario estaban al revés

---

## 21 de agosto de 2026

[12:03 a. m.] __[Llamada]__

[12:06 a. m.] **Vale 🌙:** [Imagen]

[12:14 a. m.] **Tú:**
> _Vale 🌙: Imagen_
Ojito

[12:14 a. m.] **Tú:** Y yo soy el de las fotos feas

[12:14 a. m.] **Tú:** Y ella me toma peores jakaks

[12:14 a. m.] **Tú:** Esa esta bonita

[12:14 a. m.] **Vale 🌙:**
> _Tú: Y ella me toma peores jakaks_
Jsjdjd

[12:16 a. m.] **Vale 🌙:** [Video]

[12:16 a. m.] **Vale 🌙:** [Video]

[12:17 a. m.] **Vale 🌙:** [Mensaje de album]

[12:17 a. m.] **Vale 🌙:** [Video]

[12:17 a. m.] **Vale 🌙:** [Imagen]

[12:17 a. m.] **Vale 🌙:** [Imagen]

[12:17 a. m.] **Vale 🌙:** [Imagen]

[12:17 a. m.] **Vale 🌙:** Tengo más fotos en tu casa que en la mia

[12:18 a. m.] **Vale 🌙:** [Video]

[12:21 a. m.] **Vale 🌙:** [Mensaje de album]

[12:21 a. m.] **Vale 🌙:** [Imagen]

[12:21 a. m.] **Vale 🌙:** [Imagen]

[12:21 a. m.] **Vale 🌙:** [Video]

[12:47 a. m.] **Tú:**
> _Vale 🌙: Video_
Y esa hermana

[12:47 a. m.] **Tú:** Que haces

[12:47 a. m.] **Vale 🌙:** Nada ya voy a mimir

[12:48 a. m.] **Tú:**
> _Vale 🌙: Video_
Uno intenta dormir

[12:48 a. m.] **Tú:** Y derrepente se le para el huevo

[12:48 a. m.] **Tú:** Jajaja

[12:48 a. m.] **Vale 🌙:** Jsjdjd

[12:48 a. m.] **Tú:**
> _Vale 🌙: [album]_
Mi amor

[12:48 a. m.] **Tú:** Todo lo que tenga que ver contigo

[12:48 a. m.] **Tú:** Lo tengo

[12:48 a. m.] **Tú:** Ya

[12:48 a. m.] **Vale 🌙:** Jsjs mejor dicho tiene copia de mi galería

[12:49 a. m.] **Tú:** Tu no tenías una de esas en destacadaz

[12:49 a. m.] **Tú:** No recuerdo donde

[12:49 a. m.] **Tú:**
> _Vale 🌙: Video_
Jaajaj

[12:49 a. m.] **Tú:** Cuandi estabas aprendiendo

[12:49 a. m.] **Tú:**
> _Vale 🌙: [album]_
Mi bella princesa

[12:49 a. m.] **Tú:** T amor

[12:49 a. m.] **Tú:** Bb

[12:49 a. m.] **Tú:** Voy a dormir que ya esta tarde

[12:49 a. m.] **Vale 🌙:**
> _Tú: Tu no tenías una de esas en destacadaz_
[Imagen] Ti

[12:49 a. m.] **Tú:** Descansa  mi amor bello

[12:50 a. m.] **Tú:**
> _Vale 🌙: Imagen: Ti_
Que rico k

[12:50 a. m.] **Tú:** [Sticker]

[12:50 a. m.] **Vale 🌙:** Descansa mi niño sueña bonito amor

[12:52 a. m.] **Vale 🌙:** [Sticker]

[8:44 a. m.] **Tú:** Holaaa

[8:44 a. m.] **Tú:** Buenos días mi reina como vas

[8:45 a. m.] **Tú:** _Eliminaste este mensaje._

[8:49 a. m.] **Vale 🌙:** Bien amor mio

[8:51 a. m.] **Tú:** [Video]

[8:51 a. m.] **Tú:** Que andas haciendo

[8:51 a. m.] **Vale 🌙:** Me acabo de levantar

[9:02 a. m.] **Vale 🌙:** [Mensaje de voz]

[7:26 p. m.] **Tú:** Holii

[7:26 p. m.] **Tú:** Cómo vas mi reina

[7:31 p. m.] **Vale 🌙:** bien amor taba juegando

[7:41 p. m.] **Tú:** [Video]

[7:41 p. m.] **Tú:**
> _Vale 🌙: bien amor taba juegando_
Y eso

[7:41 p. m.] **Tú:** Estás aprendiendo a jugar jajaja

[7:41 p. m.] **Tú:** Tan bella

[7:41 p. m.] **Tú:** Cómo te fue

[7:41 p. m.] **Tú:** Hoy

[7:41 p. m.] **Tú:** Que hiciste

[7:41 p. m.] **Vale 🌙:**
> _Tú: Estás aprendiendo a jugar jajaja_
Tii

[7:42 p. m.] **Vale 🌙:** Maña voy a trabajar con mi mami

[7:42 p. m.] **Vale 🌙:**
> _Tú: Video_
Ya vas pa tu casa

[7:53 p. m.] **Tú:**
> _Vale 🌙: Ya vas pa tu casa_
Sii

[7:53 p. m.] **Tú:** Apenas llegué

[7:53 p. m.] **Tú:** Voy a descansar un rato

[7:53 p. m.] **Tú:** Y al rato jugamos va

[7:53 p. m.] **Tú:** Y como vas con eso

[7:53 p. m.] **Tú:** Ya aprendiste a jugar un poco. Más

[7:53 p. m.] **Tú:**
> _Vale 🌙: Maña voy a trabajar con mi mami_
Que bien

[7:53 p. m.] **Vale 🌙:**
> _Tú: Ya aprendiste a jugar un poco. Más_
Hay vamos

[9:26 p. m.] **Tú:** Que alcanzaste hacer

[9:26 p. m.] **Tú:** Sigues jugando

[9:26 p. m.] **Tú:** Yo creo que al rato juego

[9:29 p. m.] **Vale 🌙:**
> _Tú: Sigues jugando_
No amor estaba comiendo

---

## 22 de agosto de 2026

[4:29 a. m.] **Tú:** Holiii

[4:30 a. m.] **Tú:** Me quedé dormido jajaja

[4:30 a. m.] **Tú:** Si jugaste

[10:28 a. m.] **Vale 🌙:** No me dormí amor

[10:40 a. m.] **Tú:** Y eso

[10:41 a. m.] **Tú:** Que estas haciendo

[10:42 a. m.] **Tú:** Luego no ibas a salir con tu mamá

[11:27 a. m.] **Vale 🌙:** Mi mami me dijo que mejor destinará isieras el almuerzo que ella llega temprano para que salgamos a comer por lo del cumple de ella

[5:39 p. m.] **Tú:** Qué bueno mi vida

[5:39 p. m.] **Tú:** Me vas contando

[5:39 p. m.] **Tú:** Yo ya casi llego al pueblo

[5:39 p. m.] **Tú:** [Imagen]

[5:51 p. m.] **Vale 🌙:** A bueno amor mío

[5:52 p. m.] **Tú:** [Imagen]

[5:53 p. m.] **Vale 🌙:** [Video]

[7:33 p. m.] **Tú:**
> _Vale 🌙: Video_
Nasjaka

[7:33 p. m.] **Tú:** Ese gatito tan lindo

[7:33 p. m.] **Tú:** Que hicieron

[7:33 p. m.] **Tú:** Si salieron

[7:33 p. m.] **Tú:** Yo apenas llegué al pueblo

[7:58 p. m.] **Vale 🌙:** No mama llegó Canda entonces que mañana igual yo avía echo arroz y tajadas solo fue fritar la carne y hacer la ensalada

[8:08 p. m.] **Vale 🌙:** [Imagen]

[10:39 p. m.] **Tú:**
> _Vale 🌙: Imagen_
Uyyy

[10:39 p. m.] **Tú:** Y esos aperitivos

[10:40 p. m.] **Tú:**
> _Vale 🌙: No mama llegó Canda entonces que mañana igual yo avía echo arroz y tajadas solo fue fritar la carne y hacer la ensalada_
Y a donde piensan ir

[10:40 p. m.] **Tú:** Luego mañana descansa

[10:40 p. m.] **Vale 🌙:**
> _Tú: Y esos aperitivos_
Deje la comidita que ise con tanto esfuerzo jsjsj

[10:40 p. m.] **Vale 🌙:**
> _Tú: Luego mañana descansa_
Cuando salga del trabajo

[10:43 p. m.] **Tú:**
> _Vale 🌙: Deje la comidita que ise con tanto esfuerzo jsjsj_
Que tú dejaste

[10:43 p. m.] **Tú:** O tu mami

[10:43 p. m.] **Tú:**
> _Vale 🌙: Cuando salga del trabajo_
Cuando salsa

[10:43 p. m.] **Tú:** Y eso anda muy salsa en el trabajo

[10:43 p. m.] **Tú:** Ojo con eso

[10:43 p. m.] **Tú:** Jajaja

[10:43 p. m.] **Tú:** Pero ya sabes a donde la vas a llevarle

[10:44 p. m.] **Vale 🌙:**
> _Tú: Que tú dejaste_
Yo la ise mi mamá solo hiso la ensalada que comió ella

[10:45 p. m.] **Vale 🌙:** [Mensaje de voz]

[10:48 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Vergaa

[10:48 p. m.] **Tú:** Ósea donde fuimos por el colchón

[10:48 p. m.] **Tú:** Y eso

[10:48 p. m.] **Tú:** Vergas

[10:48 p. m.] **Tú:** El pelao también tiene huevo

[10:48 p. m.] **Tú:** Cómo le va a levantar la mano

[10:49 p. m.] **Tú:** Yo acá estoy en recolecta de chismes

[10:49 p. m.] **Tú:** Voy a ver si ahorita que salgamos del resta hacemos algo con aleja

[10:49 p. m.] **Tú:** Si no la llevo a la casa

[10:49 p. m.] **Vale 🌙:** [Mensaje de voz]

[10:49 p. m.] **Tú:** Porque igual mañana me devuelvo

[10:49 p. m.] **Tú:**
> _Vale 🌙: Yo la ise mi mamá solo hiso la ensalada que comió ella_
Osea

[10:49 p. m.] **Tú:** No se comió lo que le diste

[10:50 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Ahhhhh

[10:50 p. m.] **Tú:** Jajajaaja

[10:50 p. m.] **Vale 🌙:**
> _Tú: No se comió lo que le diste_
Sii solo que  ami no me gusta la ensada entonces ella hiso para ella un poquito

[10:50 p. m.] **Tú:** En esa cuadra

[10:50 p. m.] **Tú:** Claro como son de ñeritod

[10:50 p. m.] **Tú:** Jsjsjs

[10:50 p. m.] **Tú:**
> _Vale 🌙: Sii solo que  ami no me gusta la ensada entonces ella hiso para ella un poquito_
Claro eso si ya lo tengo presente

[10:50 p. m.] **Tú:** Y no tomaron videos

[10:50 p. m.] **Tú:** Jajaja

[10:51 p. m.] **Vale 🌙:**
> _Tú: El pelao también tiene huevo_
[Mensaje de voz]

[10:52 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Ahh

[10:52 p. m.] **Tú:** Jajssj

[10:52 p. m.] **Tú:** Como explicas a medias

[10:52 p. m.] **Tú:** Yo no sé de la vida de tu bfa

[10:52 p. m.] **Tú:** Jajaja

[10:52 p. m.] **Tú:** Y qué más pasó

[10:52 p. m.] **Tú:** Si averiguaste todo

[10:53 p. m.] **Tú:** O todavía siguen en riña

[10:53 p. m.] **Tú:** Y tu que andas haciendo

[10:54 p. m.] **Vale 🌙:** [Mensaje de voz]

[11:00 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Ah no relax

[11:00 p. m.] **Tú:** No pasó nada entonces

[11:00 p. m.] **Tú:** Yo pensé que había muerto

[11:00 p. m.] **Tú:** Y todo

[11:00 p. m.] **Tú:** Pero bueno algo nuevo para contar jajsjs

[11:00 p. m.] **Tú:** Y tu que

[11:00 p. m.] **Tú:** Que le dijiste

[11:03 p. m.] **Vale 🌙:** [Mensaje de voz]

[11:03 p. m.] **Vale 🌙:** [Mensaje de voz]

[11:06 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Jajajaaj

[11:07 p. m.] **Tú:** En esa cuadra salen de todo

[11:07 p. m.] **Tú:** Si eso ratas si son

[11:08 p. m.] **Tú:** Tiris

[11:08 p. m.] **Tú:** Allá solo una me robó el corazón

[11:08 p. m.] **Tú:** Y como 40 k

[11:08 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Jajajasjsj

[11:08 p. m.] **Vale 🌙:** Nosé si ofenderme o reírme

[11:08 p. m.] **Tú:** Qué cosas

[11:08 p. m.] **Tú:** Te han pasado

[11:09 p. m.] **Tú:** Utd borracha es rara

[11:09 p. m.] **Vale 🌙:**
> _Tú: Utd borracha es rara_
Rara en que sentido

[11:09 p. m.] **Tú:**
> _Vale 🌙: Rara en que sentido_
No se

[11:10 p. m.] **Tú:** Tras de que hablas raro

[11:10 p. m.] **Tú:** Te comportas

[11:10 p. m.] **Tú:** No de

[11:10 p. m.] **Tú:** Como me dio ahuevada

[11:10 p. m.] **Tú:**
> _Vale 🌙: Nosé si ofenderme o reírme_
Jajakask

[11:10 p. m.] **Tú:** [Sticker]

[11:10 p. m.] **Vale 🌙:**
> _Tú: Tras de que hablas raro_
Pues esque antes de tomar ya estaba trabada

[11:12 p. m.] **Vale 🌙:** Yo en esos días me la pasaba fumando después del trabajo con el Brayan

[11:13 p. m.] **Vale 🌙:** Así que si lo acepto fuera del  hp sueño que me da de porsi tomar

[11:14 p. m.] **Tú:**
> _Vale 🌙: Pues esque antes de tomar ya estaba trabada_
Que tristeza

[11:15 p. m.] **Tú:** Tener una mujer marihuanera

[11:15 p. m.] **Tú:** Que llegaba con pis quiero a la casa

[11:15 p. m.] **Tú:** Con mi mamá no le da pena

[11:15 p. m.] **Tú:**
> _Vale 🌙: Así que si lo acepto fuera del  hp sueño que me da de porsi tomar_
Aja

[11:15 p. m.] **Tú:** [Sticker]

[11:15 p. m.] **Vale 🌙:** Ach yo dejé de fumar

[11:16 p. m.] **Vale 🌙:** Solo fui como dos veses así y antes de ir a tu casa dormí y me bañé en mi casa para no llegar tan así

[11:17 p. m.] **Vale 🌙:**
> _Tú: Tener una mujer marihuanera_
[Sticker]

[11:18 p. m.] **Tú:**
> _Vale 🌙: Ach yo dejé de fumar_
Si claro

[11:18 p. m.] **Tú:** Cono será que una semana antes de irse iba a llegar fumada a la casa

[11:18 p. m.] **Tú:** Ma raro

[11:18 p. m.] **Tú:**
> _Vale 🌙: Solo fui como dos veses así y antes de ir a tu casa dormí y me bañé en mi casa para no llegar tan así_
Eso no importa

[11:18 p. m.] **Tú:** Tiene que llegar sobria

[11:19 p. m.] **Tú:** Eso es pa gente ñera

[11:19 p. m.] **Tú:** Que no sabe qué hacer con su vida

[11:19 p. m.] **Tú:** [Sticker]

[11:20 p. m.] **Vale 🌙:**
> _Tú: Cono será que una semana antes de irse iba a llegar fumada a la casa_
Me refiero a 🍃y yo antes de empezar a quedarme como tal en tu casa deje de hacerlo  es más desde que empeze a enamorarme de ti más aún que no lo aceptara del todo al principio

[11:21 p. m.] **Vale 🌙:**
> _Tú: Que no sabe qué hacer con su vida_
Pues  bueno x no pienso ablar de lo que pasaba emocional mente en ese momento con migo

[11:22 p. m.] **Tú:**
> _Vale 🌙: Me refiero a 🍃y yo antes de empezar a quedarme como tal en tu casa deje de hacerlo  es más desde que empeze a enamorarme de ti más aún que no lo aceptara del todo al principio_
Jajajaja

[11:22 p. m.] **Tú:** Tranqui

[11:23 p. m.] **Tú:** Ya utd verá que se mete y que no

[11:23 p. m.] **Tú:** Desde que no llegue así a la casa

[11:23 p. m.] **Tú:** Vos verás que haces fuera de ella

[11:23 p. m.] **Tú:** Tú sabes que por eso no hay problema

[11:23 p. m.] **Tú:** Cuando estoy yo sol

[11:24 p. m.] **Vale 🌙:** Lo sé igual ya no pienso hacerlo  total no es lago que sea necesario ni que pase seguido

[11:26 p. m.] **Tú:**
> _Vale 🌙: Lo sé igual ya no pienso hacerlo  total no es lago que sea necesario ni que pase seguido_
Ahh yo no sé

[11:26 p. m.] **Tú:** Ahí si tú

[11:26 p. m.] **Tú:** Desde que avises

[11:26 p. m.] **Tú:** Pa tenerle algo de tragar

[11:26 p. m.] **Tú:** Jajaja

[11:26 p. m.] **Tú:** A mi si no me pasa eso

[11:27 p. m.] **Tú:** Ni el cigarro ya

[11:27 p. m.] **Tú:** Solo cuando tomo y cuando estoy en confianza

[11:27 p. m.] **Tú:** De resto no

[11:27 p. m.] **Tú:** Ahí si no te critico

[11:27 p. m.] **Tú:** Pero vos que

[11:27 p. m.] **Tú:** Qué es de tu vida

[11:27 p. m.] **Tú:** Si hablaste con tu mami

[11:27 p. m.] **Vale 🌙:** Si

[11:27 p. m.] **Tú:** Sobre lo. De tu hermana

[11:27 p. m.] **Vale 🌙:** Estamos buscando algo más grande

[11:28 p. m.] **Vale 🌙:** Y mi hermana es un poquito más organizada

[11:28 p. m.] **Tú:** Pero si planeas colocarle ese tipo de metas

[11:28 p. m.] **Tú:** O la piensas dejar

[11:28 p. m.] **Tú:** A ver cómo se comporta

[11:28 p. m.] **Tú:**
> _Vale 🌙: Estamos buscando algo más grande_
Siii

[11:28 p. m.] **Vale 🌙:** Si

[11:29 p. m.] **Tú:** Y eso para donde

[11:29 p. m.] **Tú:**
> _Vale 🌙: Si_
???

[11:32 p. m.] **Vale 🌙:**
> _Tú: Y eso para donde_
Por el cole de mi hermana

[11:45 p. m.] **Tú:** Mmm

[11:45 p. m.] **Tú:** Ya cerramos local

[11:46 p. m.] **Tú:** Me voy a Dormir más bien

[11:46 p. m.] **Tú:** No salieron con nada

[11:46 p. m.] **Vale 🌙:** Hasta hora vida

[11:46 p. m.] **Tú:** [Video]

[11:46 p. m.] **Vale 🌙:** Yo me estoy viendo una historia de 55 capítulos en tictok voy por el 30

[11:47 p. m.] **Tú:** [Video]

[11:47 p. m.] **Tú:**
> _Vale 🌙: Yo me estoy viendo una historia de 55 capítulos en tictok voy por el 30_
De 1 minuto cada 1

[11:47 p. m.] **Tú:** Jajaja

[11:47 p. m.] **Tú:** Algunos son chéveres

[11:47 p. m.] **Tú:** Vamos hacer algo o me acuesto

[11:47 p. m.] **Tú:** Creo que me voy a dar una vuelta en la moto

[11:47 p. m.] **Tú:** Y vuelvo

[11:47 p. m.] **Tú:** Si algo jugamos algo al rato

[11:47 p. m.] **Tú:** Juguemos fre

[11:47 p. m.] **Tú:** Descárgalo

[11:48 p. m.] **Vale 🌙:**
> _Tú: Creo que me voy a dar una vuelta en la moto_
Vale amor con cuidado

[11:48 p. m.] **Vale 🌙:**
> _Tú: Descárgalo_
Oki

[11:48 p. m.] **Tú:** [Imagen]

[11:48 p. m.] **Tú:** Ya lo puse

[11:56 p. m.] **Tú:** [Imagen]

[11:56 p. m.] **Tú:** Ya se guardó la moto

[11:57 p. m.] **Tú:** Voy a ver si se llevan la otra

[11:57 p. m.] **Tú:** Si no me quedo

[11:57 p. m.] **Tú:** Ya instalo en juego

[11:57 p. m.] **Tú:** [Imagen] Y el cucho ya ando armando su Barreto

[11:57 p. m.] **Tú:** Jajsjssksj

[11:57 p. m.] **Vale 🌙:** [Imagen]

[11:57 p. m.] **Tú:** Yo pensé que era una foto

[11:58 p. m.] **Tú:** De tu carita

[11:58 p. m.] **Tú:** Bien sabrosa

[11:58 p. m.] **Tú:** Que tiene mija

[11:58 p. m.] **Tú:** Está como seria hoy

[11:58 p. m.] **Tú:** Que tienes

[11:58 p. m.] **Vale 🌙:** [Mensaje de video]

[11:59 p. m.] **Vale 🌙:**
> _Tú: Que tienes_
Cólicos dolor de cabeza

---

## 23 de agosto de 2026

[12:06 a. m.] **Tú:**
> _Vale 🌙: Mensaje de video_
Medio muerta

[12:06 a. m.] **Tú:** Estás

[12:06 a. m.] **Tú:** Tienes sueño

[12:06 a. m.] **Tú:** Avers una teta

[12:07 a. m.] **Tú:** Tiris

[12:07 a. m.] **Tú:** Ya ando en el juego cuando quieras

[12:07 a. m.] **Tú:**
> _Vale 🌙: Cólicos dolor de cabeza_
Me imagino

[12:07 a. m.] **Tú:** Ni modo

[12:07 a. m.] **Tú:** Va a tocar comprarte una perra

[12:07 a. m.] **Tú:** Pa ti y una pa mi

[12:07 a. m.] **Tú:** Pa mi mestruasion de 24 h

[12:07 a. m.] **Tú:** Que se me sale el semen

[12:08 a. m.] **Vale 🌙:**
> _Tú: Va a tocar comprarte una perra_
Quedé??

[12:08 a. m.] **Vale 🌙:** _Se eliminó este mensaje_

[12:08 a. m.] **Vale 🌙:** [Sticker]

[12:08 a. m.] **Tú:** https://vt.tiktok.com/ZSVudWX1h/

[12:09 a. m.] **Tú:** Pa que mires mientras

[12:09 a. m.] **Tú:** Entras a jugar

[12:09 a. m.] **Vale 🌙:**
> _Tú: Va a tocar comprarte una perra_
Sigo sin entender que tiene que ver una perra

[12:10 a. m.] **Tú:** Así conozco yo

[12:10 a. m.] **Tú:** A las bolsas de agua caliente

[12:10 a. m.] **Tú:** No sé cómo le digas tú

[12:10 a. m.] **Tú:** Pa que si tú ya eres una en la cama

[12:10 a. m.] **Tú:** [Sticker]

[12:10 a. m.] **Tú:** [Sticker]

[12:10 a. m.] **Vale 🌙:**
> _Tú: No sé cómo le digas tú_
Sjsjsj

[12:10 a. m.] **Vale 🌙:** Una bolsa termica

[12:11 a. m.] **Tú:** https://vt.tiktok.com/ZSVudco9j/

[12:11 a. m.] **Tú:** https://vt.tiktok.com/ZSVudvmNJ/

[12:11 a. m.] **Vale 🌙:**
> _Tú: Pa que si tú ya eres una en la cama_
[Sticker]

[12:11 a. m.] **Tú:**
> _Vale 🌙: Sticker_
[Sticker]

[12:11 a. m.] **Tú:** [Sticker]

[12:11 a. m.] **Tú:** [Sticker]

[12:12 a. m.] **Tú:** [Sticker]

[12:12 a. m.] **Tú:** [Sticker]

[12:12 a. m.] **Tú:** [Sticker]

[12:12 a. m.] **Tú:** [Sticker]

[12:12 a. m.] **Tú:** [Sticker]

[12:12 a. m.] **Tú:** [Sticker]

[12:12 a. m.] **Tú:** [Sticker]

[12:15 a. m.] **Vale 🌙:**
> _Tú: https://vt.tiktok.com/ZSVudvmNJ/_
Yo vi un peluches con bolsita térmica en temu

[12:15 a. m.] **Vale 🌙:** [Sticker]

[12:15 a. m.] **Vale 🌙:** [Sticker]

[12:15 a. m.] **Vale 🌙:**
> _Vale 🌙: Sticker_
Soy está

[12:18 a. m.] **Tú:**
> _Vale 🌙: Soy está_
Jajajaj

[12:18 a. m.] **Tú:** Va sesito

[12:18 a. m.] **Tú:**
> _Vale 🌙: Yo vi un peluches con bolsita térmica en temu_
Serio

[12:19 a. m.] **Tú:** Y en cuanto

[12:19 a. m.] **Tú:** Jajsjssj

[12:19 a. m.] **Tú:** Vas a jugar

[12:19 a. m.] **Tú:** O miedo

[12:19 a. m.] **Tú:** El que pierda se quita prenda

[12:19 a. m.] **Tú:** [Sticker]

[12:22 a. m.] **Tú:** Entra pa jugar

[12:28 a. m.] **Vale 🌙:**
> _Tú: Y en cuanto_
20 creo

[12:28 a. m.] **Vale 🌙:** Amor estoy muerta mañana jugamos tii

[12:30 a. m.] **Tú:** Está bien entonces descansa

[12:30 a. m.] **Tú:** Besos

[12:30 a. m.] **Tú:** [Sticker]

[12:31 a. m.] **Tú:** [Sticker]

[12:32 a. m.] **Vale 🌙:** [Mensaje de video]

[12:32 a. m.] **Vale 🌙:** Descansa amor

[12:36 a. m.] **Tú:** [Mensaje de video]

[12:36 a. m.] **Tú:** [Sticker]

[7:27 a. m.] **Vale 🌙:** Buenos dias amor

[10:04 a. m.] **Tú:** Hola mi vida

[10:05 a. m.] **Tú:** Como estas

[10:05 a. m.] **Tú:** Como amaneciste princesa

[11:40 a. m.] **Vale 🌙:** Bien mi cielo

[12:33 p. m.] **Tú:** [Mensaje de voz]

[12:41 p. m.] **Vale 🌙:** A bueno mi cielo

[12:41 p. m.] **Vale 🌙:** Yo voy a lavar la nevera

[6:42 p. m.] **Tú:** Como vas

[6:43 p. m.] **Tú:** Mi cielo

[6:43 p. m.] **Tú:** Apenas  termine

[6:43 p. m.] **Tú:** Tu como vas

[6:43 p. m.] **Vale 🌙:** Bien amor mio

[6:51 p. m.] **Tú:** Ya voy a arrancar para Bogotá

[6:51 p. m.] **Tú:** Si no te respondo

[6:51 p. m.] **Tú:** Ando de viaje

[6:51 p. m.] **Vale 🌙:** Meno mi amor bello

[7:41 p. m.] **Tú:** No

[7:41 p. m.] **Tú:** Alfin  nl

[7:41 p. m.] **Tú:** Tengo la cita a medio  dia

[7:41 p. m.] **Tú:** Me voy mañana

[7:42 p. m.] **Tú:** [Video]

[7:42 p. m.] **Vale 🌙:** A bueno amor

[7:44 p. m.] **Tú:** Sii

[7:44 p. m.] **Tú:** Y tu que andas haciendo

[7:44 p. m.] **Tú:** Estos días casi no hemos hablado bien

[7:44 p. m.] **Tú:** Que me cuentas

[7:51 p. m.] **Vale 🌙:** [Imagen]

[7:51 p. m.] **Tú:** Ojito

[7:51 p. m.] **Vale 🌙:** Juegando en el cel

[7:51 p. m.] **Tú:** Amor

[7:51 p. m.] **Tú:** Eso está súper lindo

[7:51 p. m.] **Tú:** Mira a ver si puede invitar me a jugar

[7:52 p. m.] **Tú:** Y jugamos juntos hacemos una casita

[7:52 p. m.] **Tú:** Pero lo tienes en creativo

[7:52 p. m.] **Tú:** Jajaja

[7:52 p. m.] **Vale 🌙:**
> _Tú: Pero lo tienes en creativo_
Tii

[7:52 p. m.] **Vale 🌙:** Esque yo solo quiero cuntruir no crear tanta cosa y buscar en mil lugares

[7:53 p. m.] **Tú:**
> _Vale 🌙: Esque yo solo quiero cuntruir no crear tanta cosa y buscar en mil lugares_
Jajajajaaj

[7:54 p. m.] **Tú:** Pero estás usando alguna aplicación

[7:54 p. m.] **Tú:** O estás viendo un Tutorial

[7:54 p. m.] **Tú:** Ya miro si podemos hacer un server

[7:54 p. m.] **Tú:** Hay

[7:55 p. m.] **Tú:** Espera

[7:58 p. m.] **Vale 🌙:** Nada solo estoy en modo creativo usando mi creatividad y bloques que combinen

[7:58 p. m.] **Vale 🌙:** [Mensaje de voz]

[7:59 p. m.] **Tú:** Guaracha-enAR.aternos.me

[8:00 p. m.] **Vale 🌙:**
> _Tú: Guaracha-enAR.aternos.me_
??

[8:01 p. m.] **Tú:** Esa es la ip

[8:01 p. m.] **Tú:** Del servidor

[8:01 p. m.] **Tú:** Jajaja

[8:04 p. m.] **Tú:** Y coloca el puerto es

[8:04 p. m.] **Tú:** 49775

[8:05 p. m.] **Tú:** [Imagen]

[8:06 p. m.] **Vale 🌙:** [Mensaje de voz]

[8:07 p. m.] **Tú:** [Mensaje de voz]

[8:07 p. m.] **Vale 🌙:** Vale amor

[8:11 p. m.] **Vale 🌙:** Ya entre

[8:11 p. m.] **Tú:** Si vi amor

[8:11 p. m.] **Tú:** Vente

[8:12 p. m.] **Tú:** Entre

[8:12 p. m.] **Tú:** Entraa

[8:15 p. m.] **Vale 🌙:** Amor cómo se consiguen armas

[8:16 p. m.] **Tú:** Vida

[8:16 p. m.] **Tú:** Ayudame

[8:16 p. m.] **Tú:** Y ya te explico

[9:34 p. m.] **Tú:** [Documento] minecraft-1.26.50.26-.apk

[9:48 p. m.] **Vale 🌙:** [Contacto: BEGIN:VCARD
VERSION:3.0
N:;;;;
FN:Andrea
item1.TEL;waid=573043760668:+57 304 3760668
item1.X-ABLabel:Celular
PHOTO;BASE64:/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCABgAGADASIAAhEBAxEB/8QAHAAAAgIDAQEAAAAAAAAAAAAABgcDBQAECAEC/8QAQRAAAQIEAwMKBAIGCwAAAAAAAQIDAAQFEQYhMQcSQRMiMlFhcXSBscEUN5GhYtEVIyQmcvAXJzQ2UlVkgrLh8f/EABkBAAIDAQAAAAAAAAAAAAAAAAMFAQIEAP/EACYRAAICAQMEAgIDAAAAAAAAAAABAhEDBBIhBRMiMRQjMkFRYYH/2gAMAwEAAhEDEQA/AGnHseRkFBmRzltMxGqt4vmG0KJlZEmXaTwuDzj5q+wEdCVCaEjTZqbOjDK3D/tBPtHI77q33lurN1uKKlHrJ1jmSiYLUogARK2glK1a2GcTSbB+HLik8LDtizalmxTnTnmTw4Wyiu4solBfeXnoIiWf1mWkTzKA0tQB1MaxMcRR0NskqiqhgpDDi95ySdUznru5KT628oOzCX2HzhFQqsmVZLaQ6B/CSD/yEOiLog8gX2jfL2t+H9xBTAttG+Xlb8P7iOfo4KoyMjI4go8ZLLeC6yoG37G6PqkxzBKyj02oltslKSATwEdM47Vu4GrJ/wBMoQntnks1MSU0CkFQcz+gik3QTHHc6KSnSzjjQTurASroqHV/JiRanJeSUkouBkbm3CGaxT2EzzTYaSLc5WXCNecpMtUd9SkJBBPRHXlAb5NHb4E9NJU4wp8Iy39RpGhfOGDWcLy1Ppky43vCyDbPLrzheXzgidmecXF8h/sjnhKY6ZbUoJEw041nxNt4fdMdDxyPTJx2nVGXnWVWcYcS6k9oIMdVUmpsVilS0/LKCmn0BQtw6x5HKCIozdgX2jfL2teH9xBRAvtG+Xtb8P7iJfo4KoyMjUqNTkqTKqmZ6YQy0OKjmewDUnuiVFydIhtJWyg2juFrAFWUNS2lP1UB7wktn9UElV3WFmyXQCO8QWbQNoqaxSJimU+X3ZVwgLdc6SgFAiw4advlANhBbSKk+la0hbrRQhJ4m4OR68o7UYZYuJrknTzU5XEar86sTPKSj7KlKRuqSpWkfDr0xTaS+8hpMxNEFSGkHK8D7lLbDKplBbCgnnozvfyiwClsoZpUvz31jfdXe+4gcT1X0H/UZP7GLqvYM1eYnGMMOS7xcmKjOKLr1sw2nq7Mha0L7jDBxzMKalGpdghDRuFkarP5QvgYLF3yY8vDo25VwNPoWpO8kajrEMnZ1jVFEnP0a9yiqY+olJIuWFe6T9YWIOcXFPIaTfMk6mN+i06zSqRjz5HBWjp6SqMnUWuUk5lp5I13FXt3jhFDtF+Xtb8OfUQoaRXpmlzzUzLuqQpKrEA9IcQeyGxjqabnNmNUmmiS29KBab9RsYtrNJ8emnaZTTZ3k4kqaN7GGJVYckWSyhC5l9RSgLOSQBmbcdRl2wmKxU5mqzSpiefdmHDpvZJSOoDgIN9sCV8tS1X5pQ4B3gp/MQsmZojmLNyOuGvTseOOJSrl/sx6lzlN88L9GlUwn4dRTewIimC1NqS4glKkm4I4GLyqONrlFbpsoEZRQnQiFvVa73H8G3Rt7ORq4RrctU2Fl4JS+oBKzbQiCpyksJC0NrBW5znHb3VbqBhPYOW4mtpbRchYNx3Q0iQ1LlS7gAawnmtrGuN7o2wMx6hKG2ucN5a7ISDogA2gCI3SIvMQVI1SqqUAQ20ShIMVD6d0iNUcT7W4x5JpzpHynpRbsHdbHdFQnWLJJ5oEMOmunIzahXRttruoHgMhDkrd/wChN6/+XIPpCcl0b60oGZJAEPLG0smS2X1KUR0WZNLY7hYQbqUvCKB6ZebZvbQaGa3hV9LSN6Yljy7YAuTYZgd4v5gRz46ntNxHVsIHaJhwUDESlsItKTd3WgB0TfnJ8j9iIp0/N7xP/C2ohT3oAppRW0QrURXGLmZG+0oWGkU6haAdRi1kTL6d3EKNnzYcxCq46LJP3EM2oIPwiwP8JhcbN03rryupr3ENOoIHwTh/CYVSXIzxfgIu133SdSs+sRzQyBidX9pe/jPrEU10BDlxXxhZf2GsmLJk3AitT+UGVKwfPzsqh5p1jdUL2Uog+kA0WaGOT3ui+XHKa8VZDQmPiK3IsnRyYQk+ahDq2hH+r+teH9xALhPBs3L4ilX5l1rcYVytkEkkjTgONoN9oJ/cCteHPqIJrs8MrWx3RTBjlBvcqDPegbxvh4Ykw+uXQQmYZVyrSj1jUeYv52ghvHl4xxk4PdH2GaUlTFFSdn9PSyHZ15UyojoJ5qfzP2hU1qQNPrM3KWtyayEjs4R0NMs/AVN1gZNqO+gdh/m0KLaNTVM14TiE8x1AJ7xrAp58mSX2OzQ8UIwTgj3ZewVz067bIJSkfeGXVBuyDo/CYEdmUiWaY/MG36126T2AAet4Lasr9lWOyBN8h8aqIilC0y8Pxn1iKZzbETTBCZ+ZHU6r1iB5W8mHO5dihS15kDQu4kdoh40BrkqY0NOaIScmjem2E9a0j7w85AclIoH4RCbIMtOvZf0JO8++51JCfr/5EG0A/uDWfDn1Eb9DaKJEuHVxRI7tIr9oH9waz4f3EFgqiByO5s//2Q==
END:VCARD]

[10:22 p. m.] **Vale 🌙:** Ya le compré el Minecraft a mi hermana

[10:41 p. m.] **Tú:** Ojito y eso

[10:41 p. m.] **Tú:** El que le pasé no le funcionó

[10:41 p. m.] **Tú:** Bueno ya

[10:41 p. m.] **Tú:** Que en cuanto está el juego

[11:22 p. m.] **Vale 🌙:** En los mismos 3000 mil

[11:22 p. m.] **Tú:** 3k

[11:22 p. m.] **Tú:** Amor

[11:22 p. m.] **Tú:** Vas a seguir jugando

[11:22 p. m.] **Tú:** Ya vamos a cerrar el local

[11:22 p. m.] **Vale 🌙:** Si un rato

[11:27 p. m.] **Tú:** El servidor

[11:27 p. m.] **Tú:** Ya está abierto

[11:27 p. m.] **Tú:** Corazón

[11:27 p. m.] **Tú:** Si quieres ve entrando

[11:27 p. m.] **Tú:** Mientras ciérralos

[11:27 p. m.] **Tú:** Cerramos

---

## 24 de agosto de 2026

[12:41 a. m.] **Vale 🌙:** 64420070680559076

[12:49 a. m.] **Vale 🌙:** Sí. Revisé opciones actuales para Minecraft Bedrock/PE 26.40, que es la versión que aparece en los catálogos actuales; si con “26.44” te refieres a una compilación concreta, conviene comprobar la versión exacta dentro del juego. 

Mods/Add-ons que puedes probar en Android

🧟 Verity – Bedrock Edition — añade un personaje/compañero con temática de terror. Tiene millones de descargas y aparece compatible con 26.40. 

🏃 More Actions — doble salto, gancho y dash aéreo; bueno para supervivencia, parkour o PvP. 

🌎 Core Craft – A Vanilla Expansion — expande la supervivencia con nuevos mobs, animales, estructuras, misiones y muebles. 

🌙 Night Vision [ON/OFF] — permite activar visión nocturna fácilmente y está marcado para 26.40. 

⛏️ Simple Ore Detector — ayuda a localizar minerales sin usar X-Ray. 

🎲 Rains Random Items — hace que caigan objetos aleatorios del cielo; ideal para un mundo de desafío. 

🪑 Pudun Craft – Rustic Furniture — añade elementos decorativos y muebles de estilo rústico. 

⚡ Bedrock Performance Optimizer — pensado para mejorar el rendimiento sin reducir demasiado la calidad visual; aparece actualizado para 26.40. 


[Ver todos los Add-ons de Minecraft Bedrock 26.40 en CurseForge](https://www.curseforge.com/minecraft-bedrock/search?class=addons&version=26.40&utm_source=chatgpt.com)

Si quieres, puedo : 🧟 terror, 🏠 decoración, ⚔️ armas, 🐉 criaturas, 🌳 supervivencia o ✨ shaders, y buscarte específicamente 10 mods de.darte los enlaces para descargarlos en Android

[12:56 a. m.] **Tú:** Action and stuf

[12:59 a. m.] **Tú:** https://mcpedl.com/prizma-pbr-deferred-pack/

[1:03 a. m.] **Tú:** https://actionandstuffs.com/

[6:26 a. m.] **Tú:** Holiii

[6:26 a. m.] **Tú:** Buenos días

[8:07 a. m.] **Tú:** Apenas voy a salir

[8:07 a. m.] **Tú:** Luego tu no iniciabas hoy

[8:07 a. m.] **Tú:** A trabajar

[9:55 a. m.] **Vale 🌙:** Hoy es festivo entro mañana alas 9am

[10:20 a. m.] **Tú:** Ahh bueno amor

[10:20 a. m.] **Tú:** Cómo estás

[10:20 a. m.] **Tú:** Tanto tiempo sin saber de ti

[10:21 a. m.] **Tú:** [Sticker]

[10:21 a. m.] **Tú:** Que haces

[10:39 a. m.] **Tú:** [Video]

[11:23 a. m.] **Vale 🌙:**
> _Tú: Que haces_
Nada amor veo un anime

[11:24 a. m.] **Vale 🌙:** Y mi mamá está alistando para ahorita ir al centro

[11:24 a. m.] **Vale 🌙:**
> _Tú: Video_
Ya vas para Bogotá

[11:32 a. m.] **Tú:**
> _Vale 🌙: Nada amor veo un anime_
Que ves

[11:32 a. m.] **Tú:**
> _Vale 🌙: Y mi mamá está alistando para ahorita ir al centro_
Vas a salir con ella

[11:33 a. m.] **Tú:**
> _Vale 🌙: Ya vas para Bogotá_
Si ya estoy cerca de la casa

[11:33 a. m.] **Tú:** Pero cancelaron la cita médica

[11:33 a. m.] **Tú:** Ya que pero bueno jajaa

[11:33 a. m.] **Tú:** Igual me toca llegar hacer trabajos

[11:33 a. m.] **Tú:** O subir unos que ya tenía

[11:39 a. m.] **Vale 🌙:** A vale mi vida

[11:39 a. m.] **Vale 🌙:**
> _Tú: Vas a salir con ella_
Si amor

[11:50 a. m.] **Tú:**
> _Vale 🌙: A vale mi vida_
Acábe de llegar

[11:51 a. m.] **Tú:** A la casa

[11:51 a. m.] **Tú:** Ya es raro mirar a la plaza y que no estés

[11:51 a. m.] **Tú:** Ya no tienen sentido pasar por ahí

[11:51 a. m.] **Tú:** Si tú no estás

[11:52 a. m.] **Tú:** Me duele la garganta

[11:52 a. m.] **Tú:** ;(((

[11:59 a. m.] **Vale 🌙:**
> _Tú: Si tú no estás_
Hay mi amor me haces mucha falta mi rey

[12:00 p. m.] **Vale 🌙:**
> _Tú: Me duele la garganta_
Y que as tomado

[5:09 p. m.] **Tú:** Me quede dormido

[5:09 p. m.] **Tú:** Apenas  mi mama me dio vinagre

[5:09 p. m.] **Tú:** Jajaja

[5:09 p. m.] **Tú:** Y tu como vas

[5:09 p. m.] **Vale 🌙:**
> _Tú: Apenas  mi mama me dio vinagre_
Vinagre ??

[5:09 p. m.] **Tú:** Me quemo pero dice que es bueno

[5:09 p. m.] **Tú:** Jajaja

[5:09 p. m.] **Vale 🌙:** Bien amor

[5:09 p. m.] **Tú:** Si

[5:10 p. m.] **Tú:**
> _Vale 🌙: Bien amor_
Que  andas haciendo

[5:10 p. m.] **Tú:** Andrea me mordió por todo lado

[5:10 p. m.] **Tú:** En ensaño esta vez

[5:15 p. m.] **Tú:** Vas hacer algo

[5:15 p. m.] **Tú:** O hago trabajos

[5:15 p. m.] **Tú:** Y jugamos un rato

[5:15 p. m.] **Vale 🌙:**
> _Tú: Andrea me mordió por todo lado_
Umm

[5:15 p. m.] **Vale 🌙:**
> _Tú: Y jugamos un rato_
Vale amor

[5:22 p. m.] **Tú:**
> _Vale 🌙: Umm_
[Imagen]

[5:22 p. m.] **Tú:** Casi me arranca el brazo

[5:22 p. m.] **Vale 🌙:** cuidado amor

[5:22 p. m.] **Tú:** Jum que

[5:22 p. m.] **Tú:** No me cree

[5:23 p. m.] **Tú:** [Imagen]

[5:23 p. m.] **Vale 🌙:** Si solo que no me gusta que alguien te muerda

[5:23 p. m.] **Tú:**
> _Vale 🌙: Si solo que no me gusta que alguien te muerda_
Si es mi hermana

[5:23 p. m.] **Vale 🌙:**
> _Tú: Si es mi hermana_
Lose amor

[5:23 p. m.] **Vale 🌙:** Te duele

[5:23 p. m.] **Tú:** Fuera otra persona  si seria raro

[5:23 p. m.] **Tú:** Y entendería

[5:24 p. m.] **Tú:** Le deje una pata morada jsjssjsjsjz

[5:24 p. m.] **Vale 🌙:**
> _Tú: Le deje una pata morada jsjssjsjsjz_
Jsjsjsj

[5:24 p. m.] **Tú:** Y ella que con cualquier  golpe se le pone la piel morada

[5:24 p. m.] **Tú:** Me dio fu cosita

[5:24 p. m.] **Vale 🌙:** Pobrecita

[5:24 p. m.] **Tú:** Me hizo sentir mal la tonta esa

[5:25 p. m.] **Tú:** Voy hacer eso

[5:25 p. m.] **Tú:** Lo que me pide el instructor

[5:25 p. m.] **Tú:** Y ya jugamos va

[5:41 p. m.] **Vale 🌙:** Vale amor

[6:03 p. m.] **Tú:** Mor

[6:03 p. m.] **Tú:** Ya terminé

[6:03 p. m.] **Tú:** Si quieres descarga lo que te envié

[6:03 p. m.] **Tú:** Y si tu hermana esta

[6:03 p. m.] **Tú:** Para que entre también

[6:04 p. m.] **Tú:** No sé si quiere o mientras aprende que que juegue solita mientras

[6:04 p. m.] **Tú:** Y ya miro lo de los mods

[6:04 p. m.] **Tú:** Y eso

[6:04 p. m.] **Tú:** Voy a dejar cargar el celular un toque

[6:09 p. m.] **Vale 🌙:** Cielo  e podido descargar eso

[6:22 p. m.] **Tú:** Jajajsjs

[6:22 p. m.] **Tú:** Todavía no

[6:22 p. m.] **Tú:** O si

[6:22 p. m.] **Tú:** Estaba poniéndome al día

[6:22 p. m.] **Tú:** En todo lo que me envías amor

[6:23 p. m.] **Tú:** Pero el cargador no sube

[6:23 p. m.] **Tú:** Quien sabe porque

[6:23 p. m.] **Tú:** Lo voy a dejar quieto

[6:23 p. m.] **Tú:** Y ya te llamo

[6:27 p. m.] **Tú:** Gracias  por el visto amor

[6:27 p. m.] **Tú:** También te amo

[6:27 p. m.] **Tú:** [Sticker]

[6:27 p. m.] **Tú:** [Sticker]

[6:27 p. m.] **Tú:** [Sticker]

[6:29 p. m.] **Vale 🌙:** [Mensaje de voz]

[6:29 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Clarroo

[6:29 p. m.] **Tú:** De la mano con quien

[6:29 p. m.] **Tú:** [Sticker]

[6:30 p. m.] **Vale 🌙:** [Video]

[6:30 p. m.] **Vale 🌙:** [Mensaje de voz]

[6:30 p. m.] **Tú:**
> _Vale 🌙: Video_
Dioss

[6:30 p. m.] **Tú:** Tas bien rica

[6:30 p. m.] **Tú:** Mami

[6:30 p. m.] **Tú:** Eyy y porque aca no salias

[6:30 p. m.] **Tú:** Así jajaajs

[6:30 p. m.] **Tú:** Ya salias solo con la pijama tuya

[6:30 p. m.] **Tú:** La que tengo aca

[6:30 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Ta bien

[6:31 p. m.] **Tú:** Eso espero

[6:31 p. m.] **Tú:** Me avisas cuando llwgirs

[6:31 p. m.] **Tú:** Lleguez

[6:31 p. m.] **Tú:** Saludos  a la suegra

[6:31 p. m.] **Tú:** Que le quedo muy rica su hija

[6:31 p. m.] **Tú:** Y a la peque

[7:05 p. m.] **Vale 🌙:** [Mensaje de voz]

[7:06 p. m.] **Tú:** Ahhhh

[7:06 p. m.] **Tú:** Jakaka

[7:07 p. m.] **Tú:** Y cuanto te dio

[7:07 p. m.] **Tú:** Tu mamk

[7:07 p. m.] **Tú:** Pa ver

[7:07 p. m.] **Tú:** Y no te compraste una lencería  para mi

[7:07 p. m.] **Vale 🌙:** [Mensaje de voz]

[7:08 p. m.] **Vale 🌙:** [Mensaje de voz]

[7:08 p. m.] **Tú:** Por eso

[7:08 p. m.] **Tú:** Cuanto te dio para comprar eso

[7:08 p. m.] **Tú:** Jakak

[7:08 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Grosera

[7:08 p. m.] **Tú:** Najaak

[7:08 p. m.] **Tú:** Como vas

[7:08 p. m.] **Tú:** Andan de chopin

[7:08 p. m.] **Vale 🌙:**
> _Tú: Por eso_
28 y un brillito

[7:09 p. m.] **Tú:** No estuvo cara

[7:10 p. m.] **Tú:** Y ya vas para la casa

[7:11 p. m.] **Tú:** [Imagen]

[7:14 p. m.] **Tú:** O mi foto v

[7:21 p. m.] **Vale 🌙:**
> _Tú: Imagen_
Y eso de que es

[7:21 p. m.] **Vale 🌙:** Ahora que llegue

[7:21 p. m.] **Tú:** No dijiste que valió 30

[7:21 p. m.] **Tú:** Ahi tan amor

[7:21 p. m.] **Tú:** Y como te había dicho que te iba a dar 1

[7:22 p. m.] **Tú:** Pues aja no buscamos pero te ayudo con lo que vslio

[7:22 p. m.] **Tú:** Y tampoco quiero que te endeudes

[7:22 p. m.] **Tú:** Besos en esa crics

[7:22 p. m.] **Tú:** Y que dijo la suegrita

[7:23 p. m.] **Vale 🌙:** [Mensaje de voz]

[7:24 p. m.] **Vale 🌙:** [Mensaje de voz]

[7:24 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Que grosera

[7:24 p. m.] **Tú:** No se dio cuenta de lo bonita que la mandw

[7:24 p. m.] **Tú:** Alegre sin casi ojeras

[7:24 p. m.] **Tú:** Más gordita

[7:24 p. m.] **Tú:** Con maleta nueva

[7:24 p. m.] **Tú:** Jajaja

[7:24 p. m.] **Tú:** Bueno eso fue mi mama

[7:24 p. m.] **Vale 🌙:** [Mensaje de voz]

[7:24 p. m.] **Tú:** Que me dijo que nada que le hablas

[7:24 p. m.] **Vale 🌙:** [Mensaje de voz]

[7:25 p. m.] **Tú:** Y solo preguntaba por ti

[7:25 p. m.] **Tú:** [Sticker]

[7:25 p. m.] **Tú:** Ya no la quiere

[7:25 p. m.] **Tú:** O es que nos cambi o

[7:25 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Gente de plata

[7:25 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Pero no me dijo a mi

[7:25 p. m.] **Tú:** Jajaja

[7:25 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Con mi marido

[7:25 p. m.] **Tú:** Le dices

[7:26 p. m.] **Vale 🌙:** [Mensaje de voz]

[7:26 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Más le vale

[7:30 p. m.] **Vale 🌙:** [Mensaje de voz]

[7:37 p. m.] **Vale 🌙:** [Video]

[7:40 p. m.] **Vale 🌙:** [Imagen]

[7:47 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Jajajaja

[7:47 p. m.] **Tú:** Esa cuca me tiene enviciao

[7:47 p. m.] **Tú:**
> _Vale 🌙: Video_
Esta bien bonito

[7:48 p. m.] **Tú:** Y no salio ti tan caro

[7:48 p. m.] **Tú:** Y como le fue

[7:48 p. m.] **Tú:** Si compraron todo

[7:48 p. m.] **Vale 🌙:** Bien amor sii

[7:48 p. m.] **Tú:**
> _Vale 🌙: Imagen_
Tas bien rica mami

[7:48 p. m.] **Tú:** Vente que te quiero comer a besos

[7:49 p. m.] **Vale 🌙:** El otro lunes tenemos que ir al centro pero a Bancolombia para meter una plata en la cuenta para no tenerla guardada en la casa y comparable un vestido y unas sandalias ami hermana para un 15

[7:59 p. m.] **Tú:**
> _Vale 🌙: El otro lunes tenemos que ir al centro pero a Bancolombia para meter una plata en la cuenta para no tenerla guardada en la casa y comparable un vestido y unas sandalias ami hermana para un 15_
Jajajajja

[7:59 p. m.] **Tú:** Pa unos quince

[8:00 p. m.] **Tú:** Que se vaya normalita

[8:00 p. m.] **Tú:** Jajaj tiris

[8:00 p. m.] **Tú:** Pero ya tienen cuenta

[8:00 p. m.] **Tú:** En la de ahorrosc

[8:00 p. m.] **Tú:** Para que le haga más plata

[8:00 p. m.] **Tú:** Pero bueno y tu

[8:00 p. m.] **Tú:** Que piensas

[8:00 p. m.] **Vale 🌙:** Mi mamá no tiene

[8:00 p. m.] **Tú:** Entras mañana

[8:00 p. m.] **Tú:** Ya tiene horario y toso

[8:00 p. m.] **Tú:** Tdo

[8:00 p. m.] **Tú:** Es una empresa  o que

[8:01 p. m.] **Vale 🌙:** De 9 a 6

[8:01 p. m.] **Vale 🌙:** Sip pues no me an dicho cosas muy buenas que digamos de esa empresa pero pues toca intentarlo

[8:02 p. m.] **Vale 🌙:** Igual mi amiga me dijo que si no me gusta me meta al d1 con ella

[8:06 p. m.] **Tú:** No se

[8:06 p. m.] **Tú:** Yo como consejo

[8:06 p. m.] **Tú:** Te digo aguanta te guste o no

[8:07 p. m.] **Tú:** Salir del d1

[8:07 p. m.] **Vale 🌙:** Pues igual voy a ir por lo menos un mes a ver  que

[8:08 p. m.] **Tú:** Es muy complicado los horarios son más pesados, de lo que se ve tienes que atender gente hacer inventario, y es complicado que estudies porque no te puedes quedar solo con el estudio que tienes si quieres  hacer algo más estudiar un poco  no se que tengas tu pero sacar una ingeniería

[8:08 p. m.] **Tú:**
> _Vale 🌙: Pues igual voy a ir por lo menos un mes a ver  que_
Es que un mes no es nasa

[8:08 p. m.] **Tú:** Nada por lo menos y meses 1 año

[8:08 p. m.] **Tú:** Para que la hoja de vida coja fuerza

[8:09 p. m.] **Vale 🌙:** Bueno si es verdad amor

[8:09 p. m.] **Tú:** Con un mes solo te van a contratar en locales

[8:09 p. m.] **Tú:** Y ahí no te certifican experiencia

[8:09 p. m.] **Tú:** Mira yo que tengo certificados  de  una universidad  laboral  y no

[8:09 p. m.] **Vale 🌙:** Pues si es verdad amor

[8:10 p. m.] **Vale 🌙:**
> _Tú: Mira yo que tengo certificados  de  una universidad  laboral  y no_
Me consta yo también tengo casi un año de la empresa anterior y es difícil

[8:10 p. m.] **Tú:** Solo porque fueron 6 mese de practica, procura un año bb y no es por llevarle la contaría a tu amiga, pero si tienes una mejor oportunidad  y la vas a dejar ir por comodidad o solo porque tienes amigos más abajo te vas a matar tu,

[8:11 p. m.] **Tú:**
> _Vale 🌙: Me consta yo también tengo casi un año de la empresa anterior y es difícil_
Por eso

[8:11 p. m.] **Tú:** Y eso que te están ayudando a buscar

[8:11 p. m.] **Tú:** Un año

[8:11 p. m.] **Tú:** Piensa en eso mira como puedes fortalecer, tus estudios procura  los certificados

[8:11 p. m.] **Tú:** La experiencia  Laboral

[8:12 p. m.] **Tú:** Pule la forma de escribir, gramática hablar fluido, tranquila, que demuestre que sabes lo que haces así no te la montan haz tu trabajo  no el de alguien más por lo general abusan de la confianza,

[8:13 p. m.] **Vale 🌙:** Vale mi amor

[8:13 p. m.] **Tú:** Y si eso reduce tus salidas fiestas etc pues un alma por otra alma

[8:13 p. m.] **Tú:** Y ya eso recae en tu

[8:13 p. m.] **Vale 🌙:**
> _Tú: Y si eso reduce tus salidas fiestas etc pues un alma por otra alma_
A no es que igual me toca ahorita me toca ahorrar y ayudar en la casa

[8:15 p. m.] **Tú:** Si eres capaz, y no digo  esclavitud, solo que tomate tu tiempo  para salir acomodar tu tiempo, tu tu vida tu espacio, ya después de eso se te va hacer más fácil salir disfrutar, viajar, etc

[8:15 p. m.] **Tú:** Y cuando pueda voy y te visito

[8:16 p. m.] **Tú:** O  viceversa

[8:16 p. m.] **Tú:** Tampoco te voy a dejar sola

[8:16 p. m.] **Vale 🌙:**
> _Tú: Tampoco te voy a dejar sola_
Gracias mi amor lindo te amoo

[8:16 p. m.] **Tú:** Me tendrás mi nido de amor alla

[8:16 p. m.] **Vale 🌙:**
> _Tú: Si eres capaz, y no digo  esclavitud, solo que tomate tu tiempo  para salir acomodar tu tiempo, tu tu vida tu espacio, ya después de eso se te va hacer más fácil salir disfrutar, viajar, etc_
Si amor te voy hacer caso

[8:16 p. m.] **Tú:** 😏

[8:17 p. m.] **Vale 🌙:**
> _Tú: Me tendrás mi nido de amor alla_
Obio que si mi amor

[8:17 p. m.] **Tú:**
> _Vale 🌙: Si amor te voy hacer caso_
Aja igual trata de disfrutar

[8:17 p. m.] **Tú:** Que haces

[8:17 p. m.] **Tú:** Estoy esperando que cargue el cel

[8:18 p. m.] **Vale 🌙:** [Imagen]

[8:18 p. m.] **Tú:** Parchadita

[8:18 p. m.] **Tú:** Jajajaja

[8:18 p. m.] **Tú:** Te dejo que hechen  chisme

[8:19 p. m.] **Tú:** [Sticker]

[8:35 p. m.] **Tú:**
> _Vale 🌙: Video_
😍

[8:35 p. m.] **Tú:**
> _Vale 🌙: Video_
😍

[8:35 p. m.] **Tú:**
> _Vale 🌙: Video_
😍

[8:35 p. m.] **Tú:**
> _Vale 🌙: Video_
😍

[8:35 p. m.] **Tú:**
> _Vale 🌙: Video_
😍

[8:35 p. m.] **Tú:**
> _Vale 🌙: Video_
😍

[8:35 p. m.] **Tú:** Que rica mami

[8:36 p. m.] **Tú:** Como es pa los picos

[8:36 p. m.] **Vale 🌙:**
> _Tú: Como es pa los picos_
Cuando quiera papacito

[9:03 p. m.] **Vale 🌙:** [Imagen] Mira  por donde le quedó

[9:03 p. m.] **Tú:** Uf uf fj

[9:03 p. m.] **Tú:** Jajajaja

[9:03 p. m.] **Tú:** Quedo mal visto

[9:03 p. m.] **Tú:** Bajajaa

[9:03 p. m.] **Tú:**
> _Vale 🌙: Imagen: Mira  por donde le quedó_
Ahh el peluche

[9:03 p. m.] **Tú:** Yo buscando quejajanaan

[9:03 p. m.] **Tú:** Eso es grande

[9:03 p. m.] **Tú:** Yo necesito  uno para quitar la calentura

[9:03 p. m.] **Tú:** Uno frio

[9:04 p. m.] **Tú:** Me avisas para jugar amor

[9:04 p. m.] **Vale 🌙:** Amor estamos sin internet

[9:04 p. m.] **Tú:** Y esa vaina tan rara

[9:04 p. m.] **Tú:** Y porque

[9:04 p. m.] **Tú:** Y tu sin datos

[9:04 p. m.] **Vale 🌙:** Me toca llamar a que organicen el internet mañana

[9:04 p. m.] **Tú:**
> _Vale 🌙: Me toca llamar a que organicen el internet mañana_
Pero eso me llevas diciendo desde hace rato

[9:04 p. m.] **Vale 🌙:**
> _Tú: Y tu sin datos_
Si tengo sino no como te escribo pero solo WhatsApp

[9:05 p. m.] **Tú:** [Sticker]

[9:05 p. m.] **Tú:**
> _Vale 🌙: Si tengo sino no como te escribo pero solo WhatsApp_
Ahs

[9:05 p. m.] **Tú:** Y entonces

[9:05 p. m.] **Vale 🌙:** No a venido servicio técnico

[9:05 p. m.] **Tú:** Como es para la noche de frefrayer

[9:05 p. m.] **Tú:**
> _Vale 🌙: No a venido servicio técnico_
Noo

[9:05 p. m.] **Tú:** Acosa porque y entonces

[9:05 p. m.] **Tú:** Sin datos todo el tiempo

[9:05 p. m.] **Tú:** Y ti mami no usa plan

[9:05 p. m.] **Tú:** Asi les comparte

[9:05 p. m.] **Tú:** Jajaja

[9:05 p. m.] **Vale 🌙:** Si pero tambien lo paga mañana

[9:06 p. m.] **Tú:** Como ssi

[9:06 p. m.] **Tú:** Osea ella tampoco tiene datos

[9:06 p. m.] **Tú:** Verga

[9:06 p. m.] **Tú:** Hasta allá no me llega el money

[9:06 p. m.] **Tú:** Pa después jajajaja

[9:06 p. m.] **Tú:** Es que los datos si son caros así por dias

[9:06 p. m.] **Tú:** Mañana  mejor jugamos

[9:06 p. m.] **Tú:** Más bien cuéntame

[9:06 p. m.] **Tú:** Que han hablado

[9:06 p. m.] **Tú:** Chismesitos

[9:06 p. m.] **Tú:** [Sticker]

[9:07 p. m.] **Tú:** Que te ha dicho tu mami

[9:14 p. m.] **Vale 🌙:** Pues nada emos estado ablando de lo del trabajo y eso

[9:14 p. m.] **Vale 🌙:** Ella quiere que nos mudémos a una casa con local por que quiere que pongamos una floristería propia

[9:18 p. m.] **Tú:** Y de mi no

[9:18 p. m.] **Tú:** Qie grosera

[9:18 p. m.] **Tú:** Y uno aca si habla de vos

[9:18 p. m.] **Tú:**
> _Vale 🌙: Ella quiere que nos mudémos a una casa con local por que quiere que pongamos una floristería propia_
Eso estaría super

[9:19 p. m.] **Tú:** Y ella lo manejaría no

[9:19 p. m.] **Tú:** Estaría perfecto

[9:19 p. m.] **Tú:** Porque tu la puedes enseñar, ella ya tendría algo fijo

[9:19 p. m.] **Tú:** Y tu estarías en la empresa

[9:19 p. m.] **Tú:** Estarás por ese lado todo super bien

[9:20 p. m.] **Vale 🌙:** Si amor

[9:24 p. m.] **Vale 🌙:**
> _Tú: Y uno aca si habla de vos_
Pues esque mi mamá mantiene en su cel

[9:24 p. m.] **Vale 🌙:** Como le fue hoy Ati mami

[9:38 p. m.] **Tú:**
> _Vale 🌙: Pues esque mi mamá mantiene en su cel_
No importa

[9:38 p. m.] **Tú:** Solo lo decía molestando

[9:38 p. m.] **Tú:** Y como vas

[9:38 p. m.] **Tú:** Ya organizaste toda la casa

[9:39 p. m.] **Tú:** Y lo de mudarse

[9:39 p. m.] **Tú:** Como lo están pensando

[9:39 p. m.] **Tú:** Cuando  tengas el trabajo

[9:39 p. m.] **Tú:** O están buscando ya

[9:39 p. m.] **Tú:** Eso estaría genial

[9:39 p. m.] **Tú:** La verdad

[9:39 p. m.] **Tú:**
> _Vale 🌙: Como le fue hoy Ati mami_
Pregubtaleeeee

[9:39 p. m.] **Tú:** Hoy estaba descansado

[9:55 p. m.] **Vale 🌙:**
> _Tú: Como lo están pensando_
Ya sacamos varias cosas

[9:55 p. m.] **Vale 🌙:** Esta semana mi mamá va mandar unos bultos para la costa

[9:55 p. m.] **Vale 🌙:** Estamos buscando desde ya

[10:02 p. m.] **Tú:** Play MONOPOLY GO! with me! Download it here: https://mply.io/WQSCD14fQOw

[10:03 p. m.] **Tú:**
> _Vale 🌙: Esta semana mi mamá va mandar unos bultos para la costa_
Que bueno

[10:03 p. m.] **Tú:** Y lleva que pura ropa

[10:03 p. m.] **Tú:** Y ella va a ir

[10:03 p. m.] **Tú:** O la va a mandar a alguien?

[10:03 p. m.] **Tú:**
> _Vale 🌙: Estamos buscando desde ya_
Y donde piensan

[10:03 p. m.] **Tú:** Ir se

[10:03 p. m.] **Tú:** Una parte comercial

[10:05 p. m.] **Vale 🌙:**
> _Tú: O la va a mandar a alguien?_
A mis tías

[10:06 p. m.] **Vale 🌙:**
> _Tú: Una parte comercial_
Sii

[10:12 p. m.] **Tú:** [Imagen] Como así que soltera

[10:12 p. m.] **Tú:** Y yo si en situación sentimental y que tan

[10:12 p. m.] **Tú:** Bre

[10:12 p. m.] **Tú:** Tiris

[10:12 p. m.] **Tú:** _Eliminaste este mensaje._

[10:13 p. m.] **Vale 🌙:** Jaja cómo así

[10:13 p. m.] **Vale 🌙:** Ya cambio eso nosé

[10:13 p. m.] **Tú:** No deja eso así

[10:13 p. m.] **Tú:** Jajaajja

[10:13 p. m.] **Tú:** Era jodiendo

[10:13 p. m.] **Vale 🌙:** Pues esa cosa está si desde que. Creo face

[10:13 p. m.] **Tú:** Yo sé

[10:13 p. m.] **Tú:** Yo nunca cambie eso

[10:13 p. m.] **Tú:** Lo fastidioso es que si uno coloca algo

[10:14 p. m.] **Tú:** Lo hace en una publicación y un poco de cosas

[10:14 p. m.] **Vale 🌙:** Hay que peresa

[10:15 p. m.] **Tú:**
> _Vale 🌙: Hay que peresa_
[Sticker]

[10:15 p. m.] **Tú:** Ahh ósea te da pereza tu relación

[10:15 p. m.] **Vale 🌙:** Pero si tu quieres lo cambiamos

[10:15 p. m.] **Tú:** Me partes el corazón

[10:15 p. m.] **Tú:** Jajaja nel

[10:15 p. m.] **Tú:** Deja así

[10:15 p. m.] **Tú:** Pásame tu fecha de nacimiento

[10:15 p. m.] **Vale 🌙:**
> _Tú: Pásame tu fecha de nacimiento_
Me vas hacer un amarre

[10:15 p. m.] **Tú:** Más la voy a colocar como el inicio de la relación

[10:15 p. m.] **Tú:** Jajaja

[10:15 p. m.] **Tú:**
> _Vale 🌙: Me vas hacer un amarre_
Pa eso tengo la picha

[10:15 p. m.] **Vale 🌙:** 22 de junio del 2006

[10:15 p. m.] **Tú:** Que hace más que eso

[10:16 p. m.] **Tú:** [Imagen]

[10:16 p. m.] **Tú:** Así no se me olvida tú cumple

[10:16 p. m.] **Tú:** Jajajajaajaia

[10:17 p. m.] **Tú:** Eso signica que estás casada con migo desde que naciste

[10:18 p. m.] **Tú:** [Sticker]

[10:18 p. m.] **Vale 🌙:**
> _Tú: Eso signica que estás casada con migo desde que naciste_
[Sticker]

[10:18 p. m.] **Vale 🌙:** Jsjsj apenas estaba naciendo cuando ya estaba casada

[10:20 p. m.] **Vale 🌙:**
> _Tú: Imagen_
Eso como se hace editando el perfil ?

[10:20 p. m.] **Tú:**
> _Vale 🌙: Eso como se hace editando el perfil ?_
Ajá

[10:20 p. m.] **Tú:** Ahí aparece un lápiz

[10:20 p. m.] **Tú:** Lo colocque todo en solo ver yo

[10:21 p. m.] **Tú:** Después lo publiqué y lo cambié a público y elimine la publicación que hace

[10:21 p. m.] **Tú:** Y ya

[10:21 p. m.] **Tú:** Jsjsjssj

[10:21 p. m.] **Vale 🌙:**
> _Tú: Ajá_
Ya voy

[10:26 p. m.] **Vale 🌙:** [Imagen] Desde que te conocí

[10:26 p. m.] **Tú:**
> _Vale 🌙: Imagen: Desde que te conocí_
Verga verdad

[10:26 p. m.] **Tú:** Jajaja

[10:26 p. m.] **Tú:** Pues yo desde que utd nacio

[10:26 p. m.] **Tú:** Presiosa

[10:26 p. m.] **Tú:**
> _Vale 🌙: Imagen: Desde que te conocí_
T amo

[10:26 p. m.] **Vale 🌙:**
> _Tú: T amo_
Te amo más

[10:28 p. m.] **Vale 🌙:** me acabo de dar cuenta Nosotros cumplimos 5 años de conocernos este año

[10:28 p. m.] **Tú:**
> _Vale 🌙: me acabo de dar cuenta Nosotros cumplimos 5 años de conocernos este año_
Encerio

[10:28 p. m.] **Tú:** Donde es la luna de miel

[10:28 p. m.] **Tú:** Toca que tú hagas los planes

[10:29 p. m.] **Tú:** Porque tú eres la que está lejos

[10:29 p. m.] **Tú:** Y no sabemos tus descansos

[10:30 p. m.] **Vale 🌙:** Pues yo descanso fines de semana

[10:31 p. m.] **Tú:** Todavía queda tiempo para octubre no. Te anticipes

[10:31 p. m.] **Tú:** Ahí miramos que hacemos

[10:31 p. m.] **Vale 🌙:** Tii 🥰

[11:11 p. m.] **Tú:** [Imagen]

[11:11 p. m.] **Tú:** [Mensaje de unknown]

[11:11 p. m.] **Vale 🌙:** Te amo cielo ya voy a dormir mañana trabajo descansa

---

## 25 de agosto de 2026

[5:58 a. m.] **Vale 🌙:** Buenos dias amor

[8:38 a. m.] **Tú:** Holii

[8:38 a. m.] **Tú:** Buenos días como estas mi reina

[9:57 a. m.] **Vale 🌙:** Voy en el metro si no te contesto es por que ando chambiando

[9:57 a. m.] **Vale 🌙:** Te amo

[10:05 a. m.] **Vale 🌙:** Bien amor mio

[6:40 p. m.] **Tú:** Hola mi amol

[6:40 p. m.] **Tú:** Como te fue

[6:41 p. m.] **Tú:** Hoy primer día de trabajo

[6:41 p. m.] **Tú:** Hasta ahorita  llegue a la casa

[6:41 p. m.] **Tú:** Como estas

[6:41 p. m.] **Tú:**
> _Vale 🌙: Voy en el metro si no te contesto es por que ando chambiando_
No mandaste góticos

[6:45 p. m.] **Vale 🌙:** Bien mamada asta la chimba

[6:45 p. m.] **Vale 🌙:** Salí y llegué a recojer a mi hermana

[6:45 p. m.] **Vale 🌙:** Ya vamos pa la casa

[6:45 p. m.] **Vale 🌙:**
> _Tú: No mandaste góticos_
[Imagen]

[6:45 p. m.] **Tú:**
> _Vale 🌙: Bien mamada asta la chimba_
Y esa vaina

[6:45 p. m.] **Tú:** Que te mamaron

[6:45 p. m.] **Tú:** Que sea todo menos utd mi amor utd es mia

[6:46 p. m.] **Tú:**
> _Vale 🌙: Salí y llegué a recojer a mi hermana_
Verga

[6:46 p. m.] **Tú:** A que horas sales de allá

[6:46 p. m.] **Tú:**
> _Vale 🌙: Ya vamos pa la casa_
Que bueno mi amor

[6:46 p. m.] **Tú:** Pero que como te pareció el trabajo

[6:46 p. m.] **Tú:** Donde queda

[6:46 p. m.] **Tú:** Observaciones

[6:46 p. m.] **Tú:** Si te gusto

[6:46 p. m.] **Tú:** Te quedarías

[6:46 p. m.] **Tú:**
> _Vale 🌙: Imagen_
Bien elegante la bb

[6:52 p. m.] **Vale 🌙:**
> _Tú: Donde queda_
Poblado

[6:53 p. m.] **Vale 🌙:** Ya para mañana no madrugo tanto

[6:53 p. m.] **Vale 🌙:**
> _Tú: Si te gusto_
No

[6:54 p. m.] **Vale 🌙:**
> _Tú: Te quedarías_
No la gente es una mierda es tipo calcenter me duele la cabeza de tanto grito argentinos de mierda

[6:56 p. m.] **Tú:**
> _Vale 🌙: Ya para mañana no madrugo tanto_
Pero bueno

[6:56 p. m.] **Tú:** Mientras tanto

[6:57 p. m.] **Tú:**
> _Vale 🌙: No la gente es una mierda es tipo calcenter me duele la cabeza de tanto grito argentinos de mierda_
Ahh es un callcenter

[6:57 p. m.] **Tú:** Eso es muy maluco

[6:57 p. m.] **Tú:** Pero te ibas a meter igual uno aca en bogota

[6:57 p. m.] **Tú:** Eso es una mierda todos los call center  son igual

[6:57 p. m.] **Tú:** Y que  has pensado

[6:57 p. m.] **Tú:** Si crees aguantar 6 meses alla

[6:57 p. m.] **Tú:** Eso de atención  al cliente te sirve resto

[6:58 p. m.] **Tú:** Como experiencia

[6:58 p. m.] **Tú:**
> _Vale 🌙: No la gente es una mierda es tipo calcenter me duele la cabeza de tanto grito argentinos de mierda_
Si amor

[6:58 p. m.] **Tú:** Eso es todo igual

[6:58 p. m.] **Tú:** Si no es el clientes son los jefes

[6:59 p. m.] **Vale 🌙:**
> _Tú: Pero te ibas a meter igual uno aca en bogota_
Pero en el de Bogotá pagaban un millón mensual

[6:59 p. m.] **Vale 🌙:**
> _Tú: Si crees aguantar 6 meses alla_
Sii

[7:00 p. m.] **Tú:**
> _Vale 🌙: Pero en el de Bogotá pagaban un millón mensual_
Apenas un millón

[7:00 p. m.] **Tú:** Luego como te van a pagar alla

[7:00 p. m.] **Tú:**
> _Vale 🌙: Sii_
Mejor mi vida

[7:01 p. m.] **Tú:** Trata lo más que puedas

[7:01 p. m.] **Vale 🌙:** Si más que acá apagan más

[7:01 p. m.] **Tú:** Es canson  pero toca

[7:01 p. m.] **Tú:**
> _Vale 🌙: Si más que acá apagan más_
Ahh si te pagan mejor

[7:01 p. m.] **Tú:** Bueno  ahí tienes un desquite

[7:01 p. m.] **Tú:** Asi sea monetario

[7:01 p. m.] **Tú:** Y donde van

[7:01 p. m.] **Tú:** Hoy vamos hacer algo

[7:02 p. m.] **Tú:** O no tienes ganas

[7:02 p. m.] **Vale 🌙:** No pues para no estresarme trato de no cojer ni celular ni nada desde que llegó con los audífonos hacer los archivos y enviarlos a los demás departamentos

[7:02 p. m.] **Tú:**
> _Vale 🌙: No pues para no estresarme trato de no cojer ni celular ni nada desde que llegó con los audífonos hacer los archivos y enviarlos a los demás departamentos_
Depende

[7:02 p. m.] **Tú:** Toca que mires  políticas

[7:03 p. m.] **Tú:** Si no te sacan y te quedas sin el pan y sin el queso

[7:03 p. m.] **Tú:** Con 1 solo o si te dan diadema

[7:03 p. m.] **Tú:** Con esa

[7:03 p. m.] **Vale 🌙:** Me estreso es cuando me toca ir a otros departamentos  esa gente gritando

[7:03 p. m.] **Tú:** Qie no se vea obvio

[7:03 p. m.] **Tú:**
> _Vale 🌙: Me estreso es cuando me toca ir a otros departamentos  esa gente gritando_
Y en la plaza no gritaban

[7:03 p. m.] **Tú:** Es lo mismo si no que más en cerrado

[7:03 p. m.] **Vale 🌙:** Donde yo estaba casi no

[7:03 p. m.] **Tú:** Yo creo mas bien que no le gustó el trabajo

[7:04 p. m.] **Vale 🌙:** Pues igual depronto es porque apenas entre ya luego me acostumbro

[7:04 p. m.] **Vale 🌙:**
> _Tú: Es lo mismo si no que más en cerrado_
Y con más calor

[7:04 p. m.] **Tú:** Yo como consejo solo te digo que si le coges  fastidio desde un inicio paila no le vas acoger una misera así sea para aguantarte algo

[7:05 p. m.] **Tú:** Cogela suave apenas estas iniciando y en un mes o dos ya te va a dar igual

[7:05 p. m.] **Vale 🌙:**
> _Tú: Cogela suave apenas estas iniciando y en un mes o dos ya te va a dar igual_
Sip eso pienso

[7:05 p. m.] **Tú:**
> _Vale 🌙: Pues igual depronto es porque apenas entre ya luego me acostumbro_
Aja exacto

[7:05 p. m.] **Tú:**
> _Vale 🌙: Y con más calor_
Obvio

[7:05 p. m.] **Tú:** Es un edificio

[7:05 p. m.] **Tú:** Me avisas cuando llegues

[7:05 p. m.] **Tú:** Voy a descansar  y mirar que me tomo para la garganta

[7:05 p. m.] **Tú:** Besos

[7:06 p. m.] **Tú:** Doña estresada

[7:06 p. m.] **Vale 🌙:** Vale cielo

[7:06 p. m.] **Tú:** [Sticker]

[7:08 p. m.] **Vale 🌙:**
> _Tú: Doña estresada_
Te amo

[7:09 p. m.] **Tú:** [Video]

[7:21 p. m.] **Tú:** [Imagen]

[7:21 p. m.] **Tú:** Ya llego

[7:21 p. m.] **Tú:** Rápido

[7:22 p. m.] **Vale 🌙:** No demoro casi

[7:22 p. m.] **Tú:** 1 semana

[7:22 p. m.] **Tú:** Apenas

[7:22 p. m.] **Tú:** Lo pedí un día después  que me decidiste abandonar

[7:23 p. m.] **Vale 🌙:** Hay no lo digas así que suena feo

[7:39 p. m.] **Tú:** Cuando decidiste dejarnos a mi a a mis hijos en la toalla

[7:39 p. m.] **Tú:** Votados

[7:39 p. m.] **Tú:** [Sticker]

[7:39 p. m.] **Tú:** Voy hacer la comida

[7:46 p. m.] **Vale 🌙:** Grosero

[7:49 p. m.] **Tú:** Tu grosera

[7:49 p. m.] **Tú:** Me dejo solo

[7:49 p. m.] **Tú:** Con el olor de tu cuerpo en mi almohada

[7:49 p. m.] **Tú:** Y no estas

[7:49 p. m.] **Tú:** Con el frio que hace y yo sin poderte arrunchar

[7:53 p. m.] **Vale 🌙:** Acá es al revés culé calor

[7:53 p. m.] **Vale 🌙:** Te estrañoo amor

[8:07 p. m.] **Tú:**
> _Vale 🌙: Acá es al revés culé calor_
El calor que me provocas cuando te veo

[8:07 p. m.] **Tú:** Mi amor

[8:07 p. m.] **Tú:**
> _Vale 🌙: Te estrañoo amor_
Cuando estarme mi camita

[8:07 p. m.] **Tú:** Le creo

[8:07 p. m.] **Tú:** Y vos a vos

[8:07 p. m.] **Tú:** Tengo ganas de meterle  una culeada, pa después  quedar arrunchaditos dormidos

[8:07 p. m.] **Tú:** [Sticker]

[8:17 p. m.] **Vale 🌙:**
> _Tú: Tengo ganas de meterle  una culeada, pa después  quedar arrunchaditos dormidos_
Hay mi cielo

[8:58 p. m.] **Tú:** Queee

[8:58 p. m.] **Tú:** Como vas

[8:58 p. m.] **Tú:** Ya llegaste

[9:11 p. m.] **Tú:** _Esperando el mensaje… Esto puede demorar un poco._

[9:13 p. m.] **Tú:** _Esperando el mensaje… Esto puede demorar un poco._

[9:47 p. m.] **Tú:** Descansa mi amor te amo

[9:47 p. m.] **Tú:** [Sticker]

---

## 26 de agosto de 2026

[10:00 a. m.] **Tú:** Buenos días

[10:00 a. m.] **Tú:** Mi reina como estas

[1:12 p. m.] **Vale 🌙:** Bien mi rey algo ocupadita

[1:13 p. m.] **Vale 🌙:** Hoy cuando llegue te llamo y juegamos

[5:26 p. m.] **Tú:** Va

[5:26 p. m.] **Tú:** Me avisas cuando llegues

[5:33 p. m.] **Vale 🌙:** Amor acabo de llegar me cambio y te escribo

[5:47 p. m.] **Tú:** Va  mi amor

[5:47 p. m.] **Tú:** Yo ando haciendo  trabajos

[5:47 p. m.] **Tú:** Llamas

[5:48 p. m.] **Vale 🌙:** [Imagen]

[5:48 p. m.] **Vale 🌙:** [Mensaje de unknown]

[5:48 p. m.] **Tú:**
> _Vale 🌙: Imagen_
Ojito

[5:49 p. m.] **Tú:** Que rica que esta mi mujer coño

[5:49 p. m.] **Tú:** Ya te cambiaste

[5:49 p. m.] **Tú:** Jajaja

[5:54 p. m.] **Vale 🌙:** Si

[5:59 p. m.] **Tú:** https://vt.tiktok.com/ZSVqbdKdK/

[6:01 p. m.] **Vale 🌙:** [Video]

[6:08 p. m.] **Tú:**
> _Vale 🌙: Video_
Bella

[6:08 p. m.] **Tú:** Me gustas toda bb

[6:08 p. m.] **Tú:** Voy a salir un momento

[6:09 p. m.] **Tú:** Mor no se que vayas a jugar pero si quieres buscate una semilla del juego así como la que buscate que días y mira que tenga un broma bonito y que tenga una aldea cerca para no tener que viajar jajajajs y ya te llamo va

[6:51 p. m.] **Tú:** Acabo de llegar

[6:52 p. m.] **Tú:** Me voy a bañar

[6:52 p. m.] **Tú:** Tengo una estornudadera

[6:52 p. m.] **Tú:** Hp

[6:52 p. m.] **Tú:** Voy a ver si se me baja

[6:52 p. m.] **Tú:** Que haces

[6:54 p. m.] **Vale 🌙:** Vale amor ahora miro

[6:54 p. m.] **Vale 🌙:** Voy a cargar el cel

[6:55 p. m.] **Vale 🌙:** Vender con mi mami

[7:08 p. m.] **Tú:** _Esperando el mensaje… Esto puede demorar un poco._

[7:08 p. m.] **Tú:** [Video]

[7:08 p. m.] **Tú:** Me iré a bañar

[7:08 p. m.] **Tú:** [Imagen]

[7:28 p. m.] **Tú:** [Imagen]

[7:28 p. m.] **Tú:** Sali peor ksksks

[7:28 p. m.] **Tú:** Estoy que me muero con esa rinitis

[7:36 p. m.] **Tú:** [Imagen]

[7:37 p. m.] **Tú:** Qué tal jajaja

[7:37 p. m.] **Tú:** jajajase me cerró ese

[7:37 p. m.] **Tú:** [Imagen]

[7:38 p. m.] **Tú:** [Imagen]

[7:39 p. m.] **Tú:**
> _Vale 🌙: Vender con mi mami_
Como así vender

[7:39 p. m.] **Tú:** Luego no estabas en la casa

[7:40 p. m.] **Vale 🌙:** En el trabajo de mi mamá

[7:41 p. m.] **Tú:**
> _Vale 🌙: En el trabajo de mi mamá_
Ahhh

[7:41 p. m.] **Tú:** Ya

[7:51 p. m.] **Tú:** [Imagen]

[7:51 p. m.] **Tú:** [Imagen]

[7:51 p. m.] **Tú:** [Imagen]

[7:54 p. m.] **Vale 🌙:**
> _Tú: Imagen_
Mi marido

[7:54 p. m.] **Vale 🌙:**
> _Tú: Estoy que me muero con esa rinitis_
Yo esa

[7:54 p. m.] **Vale 🌙:**
> _Tú: Imagen_
😍😍

[7:55 p. m.] **Vale 🌙:** Ya llegué amor

[7:55 p. m.] **Tú:**
> _Vale 🌙: Yo esa_
Jajaja

[7:55 p. m.] **Tú:** También

[7:55 p. m.] **Tú:** No tu no

[7:55 p. m.] **Tú:** Nunca he visto tus ataques de estornudos

[7:56 p. m.] **Tú:** A mi si me da a cada rato

[7:56 p. m.] **Tú:** Que fastidio

[7:56 p. m.] **Tú:** [Imagen]

[7:56 p. m.] **Tú:** Ando en clase

[7:56 p. m.] **Tú:** Si querés descnasa

[7:56 p. m.] **Tú:** Que mi cel no quiere cargar

[7:56 p. m.] **Vale 🌙:**
> _Tú: Nunca he visto tus ataques de estornudos_
Gracias a Dios ami mi mejor amigo me dice que estornudo como tiki

[7:56 p. m.] **Tú:** Como y jugamos

[7:56 p. m.] **Tú:** Que no eh almorzado

[7:56 p. m.] **Tú:**
> _Vale 🌙: Gracias a Dios ami mi mejor amigo me dice que estornudo como tiki_
Como tiki

[7:56 p. m.] **Tú:** Que eso eso

[7:56 p. m.] **Tú:** Jajsakak

[7:57 p. m.] **Tú:** El estornudo chiquito

[7:57 p. m.] **Tú:** [Sticker]

[7:57 p. m.] **Vale 🌙:**
> _Tú: Como tiki_
Es el miraculos de leydy boc

[7:58 p. m.] **Tú:** [Imagen]

[7:58 p. m.] **Tú:** No pasa de ahí

[7:58 p. m.] **Tú:** No se que le paso

[7:58 p. m.] **Tú:**
> _Vale 🌙: Es el miraculos de leydy boc_
Ahhv

[7:58 p. m.] **Tú:** La mariquita

[7:58 p. m.] **Tú:** Jum hace rato que no se de esa serie

[7:58 p. m.] **Tú:** Me acuerdo de Kat mua

[7:58 p. m.] **Tú:** De la zorra

[7:58 p. m.] **Tú:** El malo

[7:58 p. m.] **Tú:** La panadería

[8:04 p. m.] **Tú:** Ya se terminó la clase

[8:04 p. m.] **Tú:** Voy a comer y te llamo

[8:05 p. m.] **Vale 🌙:** Vale mira yo ando doblando ropa

[8:05 p. m.] **Vale 🌙:**
> _Tú: La mariquita_
Si

[8:34 p. m.] **Vale 🌙:** [Video]

[8:34 p. m.] **Vale 🌙:** Ando doblando ropa

[8:35 p. m.] **Tú:**
> _Vale 🌙: Video_
Ahh

[8:35 p. m.] **Tú:** Y es que le da pena que  su mamá me escuche cuando estamos en llamada

[8:35 p. m.] **Tú:** Ahh listo

[8:35 p. m.] **Tú:** [Sticker]

[8:36 p. m.] **Vale 🌙:** No puedo doblar con una sola mano

[8:50 p. m.] **Tú:** [Documento] Beyond Biomes Add-On (addon).mcaddon.zip

[8:51 p. m.] **Vale 🌙:**
> _Tú: Documento: Beyond Biomes Add-On (addon).mcaddon.zip_
Que ago con eso amor

[8:51 p. m.] **Tú:** [Documento] PrizmaVisuals 1.3.10.mcpack

[8:51 p. m.] **Tú:** [Documento] Realism Visuals [ v1.9 ].mcpack

[8:51 p. m.] **Vale 🌙:** Yo creo que tenemos que empacar media casa

[8:51 p. m.] **Tú:** _Eliminaste este mensaje._

[8:51 p. m.] **Tú:** _Eliminaste este mensaje._

[8:51 p. m.] **Tú:** Eso es para el juego

[8:51 p. m.] **Tú:**
> _Vale 🌙: Yo creo que tenemos que empacar media casa_
Y esa vaina

[8:51 p. m.] **Tú:** Pa donde van

[8:52 p. m.] **Vale 🌙:** Para mandar tía esa vaina pa la costa tenemos como 5 bultos

[8:55 p. m.] **Tú:** Ahhh hp

[8:55 p. m.] **Tú:** Eso no debería de estar listo ya

[8:55 p. m.] **Tú:** Para cuando lo envían

[8:58 p. m.] **Vale 🌙:** No mi mamá acumuló todo eso y la revolvió con la ropa de mi hermana y de ella y estamos escribiendo

[9:16 p. m.] **Tú:**
> _Vale 🌙: No mi mamá acumuló todo eso y la revolvió con la ropa de mi hermana y de ella y estamos escribiendo_
Verga

[9:16 p. m.] **Tú:** Están en apuros entonces

[9:16 p. m.] **Tú:** Y tu hermana encontró la vaina

[9:16 p. m.] **Tú:** Jajaja

[10:52 p. m.] **Vale 🌙:**
> _Tú: Y tu hermana encontró la vaina_
Sii

[10:53 p. m.] **Vale 🌙:** Tengo un mierdero en el piso pero ya organice la mayoría

[10:53 p. m.] **Vale 🌙:** Salieeon dos bultos del cuarto de mi hermana y falta el de mi mama

[11:43 p. m.] **Vale 🌙:** Te amo mi amor

[11:43 p. m.] **Vale 🌙:** Descansa mi cielo

[11:44 p. m.] **Tú:**
> _Vale 🌙: Te amo mi amor_
[Imagen]

[11:46 p. m.] **Vale 🌙:**
> _Tú: Imagen_
Como se llama el libro

[11:46 p. m.] **Tú:**
> _Vale 🌙: Te amo mi amor_
Igualmente mi amor

[11:46 p. m.] **Tú:**
> _Vale 🌙: Como se llama el libro_
[Imagen]

[11:46 p. m.] **Tú:** Descansa

[11:46 p. m.] **Vale 🌙:** Voy a buscarlo está como bueno por lo que ley en lo que mandaste

[11:47 p. m.] **Vale 🌙:** Mi hermana nosé que mosco le picó se le perdió algo se puso a llorar se durmió se levantó ahora tiro unas cosas se estreso se tapó con otra cobija y se  durmio de cabeza

---

## 27 de agosto de 2026

[10:41 a. m.] **Tú:**
> _Vale 🌙: Voy a buscarlo está como bueno por lo que ley en lo que mandaste_
Habla de todo un poco

[10:41 a. m.] **Tú:**
> _Vale 🌙: Mi hermana nosé que mosco le picó se le perdió algo se puso a llorar se durmió se levantó ahora tiro unas cosas se estreso se tapó con otra cobija y se  durmio de cabeza_
Verga jsjsjssj

[10:41 a. m.] **Tú:** Se parece a alguien cuando le da la loquera

[10:41 a. m.] **Vale 🌙:** Jajajajja

[12:25 p. m.] **Tú:** Cómo estás

[12:25 p. m.] **Tú:** Dónde andas

[12:33 p. m.] **Tú:** [Imagen]

[12:45 p. m.] **Vale 🌙:** Ya entregaste eso

[12:50 p. m.] **Vale 🌙:** [Mensaje de voz]

[1:20 p. m.] **Vale 🌙:** [Video] Este fue el aufit laboral de hoy obviamente con el pelo recogido

[3:24 p. m.] **Tú:** [Imagen]

[3:24 p. m.] **Tú:** Y el mio

[3:24 p. m.] **Tú:** Me voy pa la u

[3:24 p. m.] **Tú:** Utd anda toda rara últimamente

[3:25 p. m.] **Vale 🌙:**
> _Tú: Utd anda toda rara últimamente_
Rara en que sentido amor

[3:25 p. m.] **Vale 🌙:**
> _Tú: Imagen_
Cosita preciosa el Mario mio

[3:28 p. m.] **Vale 🌙:** [Mensaje de voz]

[3:40 p. m.] **Vale 🌙:** Pero pues aca serca me queda la EPS voy a ir

[3:41 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Como

[3:41 p. m.] **Tú:** Entendí que ya saliste

[3:41 p. m.] **Tú:** Porque no tenías mucho que hacer

[3:41 p. m.] **Tú:**
> _Vale 🌙: Pero pues aca serca me queda la EPS voy a ir_
Como así

[3:41 p. m.] **Tú:** Y eso que tienes

[3:42 p. m.] **Tú:**
> _Vale 🌙: Pero pues aca serca me queda la EPS voy a ir_
Me cuentas

[3:42 p. m.] **Tú:** Yo apenas voy a salir para la u

[4:15 p. m.] **Vale 🌙:**
> _Tú: Y eso que tienes_
Lo de la muela amor

[4:15 p. m.] **Vale 🌙:** Y tengo que volver al tratamiento de los quistes

[4:46 p. m.] **Tú:**
> _Vale 🌙: Lo de la muela amor_
Pero eso es en el odontólogo

[4:46 p. m.] **Tú:** Pero que te dijeron que te la tienen que quitar o que

[4:47 p. m.] **Tú:**
> _Vale 🌙: Y tengo que volver al tratamiento de los quistes_
Luego como seguiste con eso

[4:47 p. m.] **Tú:** Tienes dolor

[4:47 p. m.] **Vale 🌙:**
> _Tú: Tienes dolor_
Si amor

[5:16 p. m.] **Tú:** Llegué

[5:16 p. m.] **Tú:** Pero llegué muy tarde

[5:16 p. m.] **Tú:** Voy a ver si contestan si no me voy

[5:17 p. m.] **Tú:** No pensé que esa Caracas estuviera tan trancada

[5:21 p. m.] **Tú:** [Imagen]

[5:41 p. m.] **Vale 🌙:** [Mensaje de voz]

[6:06 p. m.] **Tú:** Ya voy para la casa

[6:06 p. m.] **Tú:** Tu como vas

[6:06 p. m.] **Tú:** Traslado de que

[6:07 p. m.] **Tú:** [Mensaje de voz]

[6:30 p. m.] **Vale 🌙:** A bueno mi vida

[6:33 p. m.] **Vale 🌙:** [Imagen] Ando en el local

[6:34 p. m.] **Tú:** [Video]

[6:34 p. m.] **Tú:** Acá más atrapado

[6:34 p. m.] **Tú:** No puedo ni sacar el celular

[6:41 p. m.] **Vale 🌙:** Uyy no me avisas cuando llegues

[7:33 p. m.] **Tú:** Acabo de llegar

[7:33 p. m.] **Tú:**
> _Vale 🌙: Imagen: Ando en el local_
Pa cuando mis flores

[7:34 p. m.] **Tú:** Y pique están chuzados los girasoles

[7:36 p. m.] **Vale 🌙:**
> _Tú: Y pique están chuzados los girasoles_
[Mensaje de voz]

[7:36 p. m.] **Vale 🌙:**
> _Tú: Pa cuando mis flores_
Apenas me paguen le mando uno

[7:37 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Ahh no

[7:37 p. m.] **Tú:** Porque no estudiaste agricultira

[7:37 p. m.] **Tú:** No te gusta

[7:37 p. m.] **Tú:**
> _Vale 🌙: Apenas me paguen le mando uno_
Porque no se manda utd por pa que te ría mejor

[7:46 p. m.] **Tú:**
> _Vale 🌙: Rara en que sentido amor_
Tiempo que tiene una actitud diferente

[7:46 p. m.] **Vale 🌙:**
> _Tú: Tiempo que tiene una actitud diferente_
Como así

[7:47 p. m.] **Vale 🌙:**
> _Tú: Porque no se manda utd por pa que te ría mejor_
Por que tengo que trabajar

[7:47 p. m.] **Vale 🌙:**
> _Tú: No te gusta_
Nopp

[7:57 p. m.] **Tú:**
> _Vale 🌙: Como así_
Sii

[7:57 p. m.] **Tú:** Pero nada cosa mía debe de ser

[7:57 p. m.] **Tú:**
> _Vale 🌙: Por que tengo que trabajar_
No no es por eso

[7:58 p. m.] **Tú:** Qué vas hacer al rato

[7:59 p. m.] **Vale 🌙:**
> _Tú: Pero nada cosa mía debe de ser_
[Mensaje de voz]

[7:59 p. m.] **Vale 🌙:**
> _Tú: Qué vas hacer al rato_
Que quieres que agamos

[8:03 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Puede ser por algo así no se

[8:04 p. m.] **Tú:** Creo que es porque ando bajo de ánimos

[8:04 p. m.] **Tú:** El ánimo está en Medellín

[8:04 p. m.] **Vale 🌙:** [Mensaje de voz]

[8:04 p. m.] **Vale 🌙:**
> _Tú: El ánimo está en Medellín_
[Mensaje de voz]

[8:04 p. m.] **Tú:**
> _Vale 🌙: Que quieres que agamos_
Jugamos un rato no se

[8:04 p. m.] **Tú:** Quiero como relajarme hacer algo

[8:05 p. m.] **Tú:** Pero no me quiero como esforzar

[8:05 p. m.] **Tú:** Ando es mi día

[8:05 p. m.] **Tú:** Jajaja

[8:05 p. m.] **Tú:** [Sticker]

[8:05 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Yo creo que es

[8:05 p. m.] **Tú:** Eso

[8:05 p. m.] **Tú:** Que me hace falta

[8:05 p. m.] **Tú:** No sabe la falta que hace

[8:05 p. m.] **Tú:** Escucharla roncar

[8:06 p. m.] **Tú:** Reírse o quejarse de que no sabe jugar

[8:06 p. m.] **Tú:** Si

[8:06 p. m.] **Tú:** Me hace falta

[8:06 p. m.] **Vale 🌙:** [Mensaje de voz]

[8:06 p. m.] **Vale 🌙:**
> _Tú: Escucharla roncar_
🤭🤭🤭

[8:11 p. m.] **Vale 🌙:** Me asé falta verte abrazarte que me mandes ala tienda verte jugar escuchar tus llamadas con tus amigos mientras duermo tu mami despertar con Tigo luchar en las mañanas para irme a trabajar por que quiero estar más tiempo con Tigo

[8:41 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Jajajaj

[8:41 p. m.] **Tú:** Dale ahora

[8:42 p. m.] **Tú:** Que ando haciéndole algo para cuando llegue mi mama

[8:42 p. m.] **Tú:** Y coma

[8:42 p. m.] **Tú:** Y te llamo

[8:42 p. m.] **Tú:** O jugamos minecraft no se

[8:42 p. m.] **Tú:** Ahorita miramos

[8:48 p. m.] **Tú:**
> _Vale 🌙: Me asé falta verte abrazarte que me mandes ala tienda verte jugar escuchar tus llamadas con tus amigos mientras duermo tu mami despertar con Tigo luchar en las mañanas para irme a trabajar por que quiero estar más tiempo con Tigo_
Que te mandé a la tienda

[8:48 p. m.] **Tú:** Jajaj

[8:48 p. m.] **Tú:** Suena mal

[8:48 p. m.] **Tú:** Sii también me haces  mucha falta mi bb hermosa

[8:48 p. m.] **Tú:** No se para que te fuiste en primer lugar

[8:48 p. m.] **Tú:** Ojalá ojalá

[8:48 p. m.] **Tú:** Y sea pronto

[8:48 p. m.] **Tú:** Ya se me hace frío tu lado de mi cama

[8:52 p. m.] **Vale 🌙:**
> _Tú: No se para que te fuiste en primer lugar_
Por que ya no me estaba dando para pagar arriendo

[8:56 p. m.] **Tú:**
> _Vale 🌙: Por que ya no me estaba dando para pagar arriendo_
Lo supuse

[8:56 p. m.] **Tú:** Pero ya saldrás adelante

[8:56 p. m.] **Tú:** Tendrás más de lo que quieres

[8:57 p. m.] **Tú:** Pero tienes que darle tiempo y darte el tiempo a ti para mejorar

[8:57 p. m.] **Tú:** Espero que llegue mi mamá y te llamo

[8:57 p. m.] **Tú:**
> _Tú: Pero tienes que darle tiempo y darte el tiempo a ti para mejorar_
Tú sabes que igual estaré para ti

[8:57 p. m.] **Vale 🌙:** Vale amor mío

[8:57 p. m.] **Tú:** O te preño alguna de las dos

[8:57 p. m.] **Tú:** [Sticker]

[9:03 p. m.] **Vale 🌙:**
> _Tú: O te preño alguna de las dos_
[Sticker]

[9:24 p. m.] **Vale 🌙:** [Imagen] Mira me compré este anillito

[9:29 p. m.] **Tú:**
> _Vale 🌙: Imagen: Mira me compré este anillito_
Ahí debería de ir el lío

[9:29 p. m.] **Tú:** Mío

[9:30 p. m.] **Tú:** Cámbiatelo de lugar

[9:30 p. m.] **Tú:** [Sticker]

[9:30 p. m.] **Tú:** Amor

[9:30 p. m.] **Tú:** Voy a dejar cargar el celular

[9:30 p. m.] **Tú:** Mi mamá nada que llega pero ya se va a morir

[9:31 p. m.] **Vale 🌙:**
> _Tú: Cámbiatelo de lugar_
Ya me lo cambié

[9:31 p. m.] **Vale 🌙:**
> _Tú: Mi mamá nada que llega pero ya se va a morir_
Vale mi rey

[9:31 p. m.] **Tú:** "Il n'y a pas si longtemps, nous nous connaissions même.

Nous étions simplement deux âmes qui marchaient sans nous voir.

Et puis, un jour, sans prévenir, nous nous sommes retrouvés sur le même chemin. Et parfois, on dit que certaines rencontres changent votre vie ; c'est l'une d'entre elles. C'est bizarre, je sais :

Plus je te connais, plus j'oublie comment était ma vie sans toi.

Tu fais de moi une meilleure personne, et je t'en suis reconnaissant.

Parce que si aimer est une erreur, que le monde me juge... et qu'il brûle pour toute l'éternité."

[9:31 p. m.] **Tú:** Va

[9:31 p. m.] **Tú:** Ya te llamo entonces

[9:31 p. m.] **Tú:** Que vamos a jugar

[9:31 p. m.] **Tú:** Hacemos esta vez la casa o que

[9:31 p. m.] **Tú:** Ya creo que está una semilla buena

[9:36 p. m.] **Vale 🌙:**
> _Tú: "Il n'y a pas si longtemps, nous nous connaissions même.

Nous étions simplement deux âmes qui marchaient sans nous voir.

Et puis, un jour, sans prévenir, nous nous sommes retrouvés sur le même chemin. Et parfois, on dit que certaines rencontres changent votre vie ; c'est l'une d'entre elles. C'est bizarre, je sais :

Plus je te connais, plus j'oublie comment était ma vie sans toi.

Tu fais de moi une meilleure personne, et je t'en suis reconnaissant.

Parce que si aimer est une erreur, que le monde me juge... et qu'il brûle pour toute l'éternité."_
🥹🥹 Je ne sais vraiment pas comment tant d'années ont passé ; j'ai l'impression que c'était hier le jour où je t'ai rencontré, et soudain, je ne peux plus imaginer ma vie sans toi. Tu me rends meilleur. Je t'aime, mon amour.

[9:36 p. m.] **Vale 🌙:** [Mensaje de voz]

[10:25 p. m.] **Tú:** Como tas

[10:25 p. m.] **Tú:** Ya me voy a cambiar

[10:25 p. m.] **Tú:** Y jugamos

[10:39 p. m.] **Tú:** Donde estas

[11:18 p. m.] **Vale 🌙:** [Imagen] Vamos en el carro

[11:19 p. m.] **Vale 🌙:** Ya en la casa me Marie mi mamá me CABA de dar un arroz con huevo

[11:21 p. m.] **Tú:**
> _Vale 🌙: Ya en la casa me Marie mi mamá me CABA de dar un arroz con huevo_
Veega

[11:21 p. m.] **Tú:** Eso significa  que nisiquiera has almorzado

[11:22 p. m.] **Tú:**
> _Vale 🌙: Imagen: Vamos en el carro_
Avisas

[11:31 p. m.] **Vale 🌙:**
> _Tú: Eso significa  que nisiquiera has almorzado_
Si almorcé

[11:31 p. m.] **Vale 🌙:** Solo que nosé aveses me pongo como zombi me dure resto la cabeza

---

## 28 de agosto de 2026

[12:09 a. m.] **Tú:**
> _Vale 🌙: 🥹🥹 Je ne sais vraiment pas comment tant d'années ont passé ; j'ai l'impression que c'était hier le jour où je t'ai rencontré, et soudain, je ne peux plus imaginer ma vie sans toi. Tu me rends meilleur. Je t'aime, mon amour._
Un jour, tu comprendras que je n'ai pas besoin de grand-chose. Tu comprendras aussi que tu n'as pas besoin de me dire ce que nous sommes ; à chaque baiser, nous sommes tout.

Je ne veux pas que tu me demandes comment je vais, mais je veux te demander où j'aimerais être. La réponse est simple : dans tes bras, tu le sais déjà.

Et quand tu me regarderas dans les yeux, tu comprendras que ce n'est pas moi qui ai un problème, c'est toujours toi. Et je n'ai rien d'autre à dire.

[12:09 a. m.] **Tú:**
> _Vale 🌙: Solo que nosé aveses me pongo como zombi me dure resto la cabeza_
Verga

[12:10 a. m.] **Tú:** Eso ya es anemia

[12:10 a. m.] **Tú:** Tienes que tener cuidado con eso

[12:10 a. m.] **Vale 🌙:**
> _Tú: Eso ya es anemia_
Lo sep

[12:10 a. m.] **Vale 🌙:** Por eso fui hacer lo de la eps

[12:10 a. m.] **Tú:** 我想把我的陰莖插進你的身體裡 🥺🥺🥺

[12:10 a. m.] **Tú:**
> _Vale 🌙: Por eso fui hacer lo de la eps_
Y que te recomendaron

[12:15 a. m.] **Vale 🌙:**
> _Tú: Y que te recomendaron_
Me toca llamar en la mañana por que cambiaron el punto de atención

[12:17 a. m.] **Vale 🌙:**
> _Tú: 我想把我的陰莖插進你的身體裡 🥺🥺🥺_
我想呼喚你的名字，想跟你一起走🥺🥺🥺

[12:18 a. m.] **Vale 🌙:**
> _Tú: Un jour, tu comprendras que je n'ai pas besoin de grand-chose. Tu comprendras aussi que tu n'as pas besoin de me dire ce que nous sommes ; à chaque baiser, nous sommes tout.

Je ne veux pas que tu me demandes comment je vais, mais je veux te demander où j'aimerais être. La réponse est simple : dans tes bras, tu le sais déjà.

Et quand tu me regarderas dans les yeux, tu comprendras que ce n'est pas moi qui ai un problème, c'est toujours toi. Et je n'ai rien d'autre à dire._
Prontito estaremos juntos amor

[12:35 a. m.] **Tú:**
> _Vale 🌙: Me toca llamar en la mañana por que cambiaron el punto de atención_
Bueno desde que te puedas mandar a revisar

[12:35 a. m.] **Tú:** Y si te recetan algo

[12:35 a. m.] **Tú:** Para que lo tomes con juicio

[12:35 a. m.] **Tú:** Me imagino que algo de vitamina

[12:35 a. m.] **Tú:**
> _Vale 🌙: 我想呼喚你的名字，想跟你一起走🥺🥺🥺_
T quiero

[12:36 a. m.] **Tú:**
> _Vale 🌙: Prontito estaremos juntos amor_
Ojala

[12:36 a. m.] **Tú:** Y sea así

[12:36 a. m.] **Tú:** Que Haces

[12:36 a. m.] **Tú:** Ya te pusiste la pijama

[12:40 a. m.] **Tú:** Faisons pipi au lit avec toi, avec moi, avec du miel, avec du vin.
Je n'ai plus de mots pour exprimer ce qui me rend fou de ton corps, alors lis les miens avec tes lèvres si tu veux le savoir.
Prends le parfum de ma peau sur tes mains et mon goût sur tes lèvres.

[12:41 a. m.] **Tú:**
> _Vale 🌙: 我想呼喚你的名字，想跟你一起走🥺🥺🥺_
Si seulement tu savais que, très souvent pendant ton sommeil, je choisis de penser à toi, c'est mon dernier souhait avant de m'endormir.

[12:43 a. m.] **Vale 🌙:**
> _Tú: Me imagino que algo de vitamina_
Sipi la otra semana me toca compra otra vez fruta y vitamina

[12:46 a. m.] **Vale 🌙:**
> _Tú: Si seulement tu savais que, très souvent pendant ton sommeil, je choisis de penser à toi, c'est mon dernier souhait avant de m'endormir._
Tal vez por eso simpre sueño con tigo

[12:46 a. m.] **Vale 🌙:**
> _Tú: Ya te pusiste la pijama_
Ti

[12:51 a. m.] **Vale 🌙:**
> _Tú: Faisons pipi au lit avec toi, avec moi, avec du miel, avec du vin.
Je n'ai plus de mots pour exprimer ce qui me rend fou de ton corps, alors lis les miens avec tes lèvres si tu veux le savoir.
Prends le parfum de ma peau sur tes mains et mon goût sur tes lèvres._
Ton parfum m'enivre, la sensation de ton corps contre le mien me rend folle, ton souffle et la façon dont tu me touches. Je suis entièrement à toi et à ta merci, amour de ma vie.

[12:53 a. m.] **Vale 🌙:** Voy a mimir te amo descansa sueña cositas lindas  hasta mañana amor

[12:55 a. m.] **Vale 🌙:** [Video]

[1:01 a. m.] **Tú:**
> _Vale 🌙: Sipi la otra semana me toca compra otra vez fruta y vitamina_
Claro bb

[1:01 a. m.] **Tú:** Que te toca

[1:01 a. m.] **Tú:** Banano me imagino fresas

[1:01 a. m.] **Tú:**
> _Vale 🌙: Tal vez por eso simpre sueño con tigo_
Sera

[1:01 a. m.] **Tú:** [Sticker]

[1:05 a. m.] **Tú:**
> _Vale 🌙: Ton parfum m'enivre, la sensation de ton corps contre le mien me rend folle, ton souffle et la façon dont tu me touches. Je suis entièrement à toi et à ta merci, amour de ma vie._
J'adore quand tu me parles comme ça. Je veux être en toi, te faire mienne à chaque instant, pour que lorsque le sommeil t'emporte, tu te laisses tomber dans mes bras et saches que tu es à moi, et que tu seras toujours protégée. Je t'aime.

[1:05 a. m.] **Tú:**
> _Vale 🌙: Voy a mimir te amo descansa sueña cositas lindas  hasta mañana amor_
Besos

[1:05 a. m.] **Tú:**
> _Vale 🌙: Video_
Mi mujer

[9:24 a. m.] **Vale 🌙:**
> _Tú: J'adore quand tu me parles comme ça. Je veux être en toi, te faire mienne à chaque instant, pour que lorsque le sommeil t'emporte, tu te laisses tomber dans mes bras et saches que tu es à moi, et que tu seras toujours protégée. Je t'aime._
Me encanta te amoo

[10:24 a. m.] **Tú:** Hola mi amor buenos  fisd

[10:24 a. m.] **Tú:** Dias

[10:24 a. m.] **Tú:** Como estas bb

[11:08 a. m.] **Vale 🌙:** Menos días bien amor mio

[1:02 p. m.] **Tú:** Que bueno mi bb

[1:02 p. m.] **Tú:** Hoy no trabajas o si

[1:02 p. m.] **Tú:** Me cuentas como te va

[1:02 p. m.] **Tú:** Andaba haciendo trabajos

[1:02 p. m.] **Tú:** Me voy a poner hacer oficio

[1:03 p. m.] **Tú:** Si te pudieron arreglar el Internet

[2:40 p. m.] **Vale 🌙:**
> _Tú: Si te pudieron arreglar el Internet_
Nada vida

[2:56 p. m.] **Tú:** [Video]

[2:56 p. m.] **Tú:** Voy a hacer oficio

[4:09 p. m.] **Vale 🌙:** [Mensaje de voz]

[4:10 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Mandas fotico

[4:10 p. m.] **Tú:** Se escucha rico

[4:10 p. m.] **Tú:** Yo apenas voy a comer

[4:10 p. m.] **Tú:** Jasjaj

[4:11 p. m.] **Tú:** Lave la ropa, ra barri todo la casa medio organice voy a trapear organizo  la cocina y mi cuarto

[4:11 p. m.] **Tú:** Y trabajos

[5:58 p. m.] **Tú:** Ya termine

[5:58 p. m.] **Tú:** Tu como vas

[6:06 p. m.] **Vale 🌙:** Buen amorcito

[6:07 p. m.] **Vale 🌙:**
> _Tú: Lave la ropa, ra barri todo la casa medio organice voy a trapear organizo  la cocina y mi cuarto_
Yo voy almorzar

[6:07 p. m.] **Vale 🌙:** Y a bañarme

[6:07 p. m.] **Tú:** Vale mi amor

[6:07 p. m.] **Tú:** Bello

[6:08 p. m.] **Tú:** Voy a descansar un rato

[6:08 p. m.] **Tú:** Mandas fotico

[6:08 p. m.] **Tú:** Hablamos al rato

[6:08 p. m.] **Vale 🌙:** Vale mi cielito te amo

[7:39 p. m.] **Tú:** [Mensaje de voz]

[8:05 p. m.] **Vale 🌙:** Ya me voy a bañar de nuevo por que estoy es sudada de tanta vaina que hice hoy

[8:05 p. m.] **Tú:**
> _Vale 🌙: Ya me voy a bañar de nuevo por que estoy es sudada de tanta vaina que hice hoy_
Que rico

[8:05 p. m.] **Tú:** Así sabe más saladito

[8:05 p. m.] **Tú:** [Sticker]

[8:06 p. m.] **Vale 🌙:** Hay amor

[8:06 p. m.] **Tú:** Báñate bien esa tota miamol

[8:07 p. m.] **Tú:** Que eso es de los dos

[8:07 p. m.] **Tú:** Oíste

[8:07 p. m.] **Vale 🌙:** Meno mi amor

[8:07 p. m.] **Tú:** Besos

[8:09 p. m.] **Vale 🌙:** [Video] Ese fue el aufit está mañana para recojer las notas de la mocosa hoy  antes de seguir trabajando

[8:09 p. m.] **Vale 🌙:** [Video]

[8:09 p. m.] **Tú:**
> _Vale 🌙: Video: Ese fue el aufit está mañana para recojer las notas de la mocosa hoy  antes de seguir trabajando_
Modo mamá

[8:09 p. m.] **Tú:** Pero mamasota

[8:09 p. m.] **Tú:** Rica

[8:09 p. m.] **Vale 🌙:** [Video] Hay ya avía terminado de trabar. En las llamadas y me vine para la casa a reglar

[8:09 p. m.] **Tú:** Utd va a notas o a levantar pelado

[8:10 p. m.] **Tú:** Tas bien bella mami

[8:10 p. m.] **Tú:**
> _Vale 🌙: Video_
Ella quien es

[8:10 p. m.] **Vale 🌙:** [GIF]

[8:10 p. m.] **Tú:**
> _Vale 🌙: Video: Hay ya avía terminado de trabar. En las llamadas y me vine para la casa a reglar_
Tas bien linda mi amor

[8:10 p. m.] **Tú:** Cuando para irnos a vivir juntos

[8:11 p. m.] **Tú:**
> _Vale 🌙: Video: Hay ya avía terminado de trabar. En las llamadas y me vine para la casa a reglar_
Lo malo es que esas actualizaciones no me llegan a mi

[8:11 p. m.] **Vale 🌙:**
> _Tú: Ella quien es_
La niña de la jefa de mi mamá cómo aya hay señal trabaje todo el día aya

[8:11 p. m.] **Tú:** Toca que me las mandases más seguido creo que el celular no está reconociendo bien tu rostro creo que ángeles no los toma todavía

[8:11 p. m.] **Tú:**
> _Vale 🌙: Video_
Tas bien buena mami

[8:11 p. m.] **Vale 🌙:**
> _Tú: Lo malo es que esas actualizaciones no me llegan a mi_
Como apenas llegué me puse hacer oficio y puse modo desechable se me olvidó mostrarte

[8:12 p. m.] **Tú:**
> _Vale 🌙: La niña de la jefa de mi mamá cómo aya hay señal trabaje todo el día aya_
Ahhh

[8:12 p. m.] **Vale 🌙:**
> _Tú: Toca que me las mandases más seguido creo que el celular no está reconociendo bien tu rostro creo que ángeles no los toma todavía_
[Sticker]

[8:12 p. m.] **Tú:** Pero tú no vives lejos de donde trabajas o si

[8:12 p. m.] **Tú:** Como yo no conozco

[8:12 p. m.] **Tú:** Y la niña anda tan pedida que ni tour le hace a uno

[8:12 p. m.] **Tú:**
> _Vale 🌙: Como apenas llegué me puse hacer oficio y puse modo desechable se me olvidó mostrarte_
Mi amor

[8:12 p. m.] **Tú:** Tú con lo que sea

[8:12 p. m.] **Tú:** Te vez hermosa

[8:13 p. m.] **Tú:** Y más si no llevas más na

[8:13 p. m.] **Vale 🌙:**
> _Tú: Pero tú no vives lejos de donde trabajas o si_
Alguito pero en el metro es rápido

[8:13 p. m.] **Vale 🌙:** Mi mamá si trabaja relativamente serca de la casa

[8:13 p. m.] **Tú:**
> _Vale 🌙: Alguito pero en el metro es rápido_
Cómo se llama donde trabajas

[8:13 p. m.] **Tú:**
> _Vale 🌙: Mi mamá si trabaja relativamente serca de la casa_
Ahhh

[8:13 p. m.] **Vale 🌙:**
> _Tú: Cómo se llama donde trabajas_
Es un wework

[8:13 p. m.] **Tú:** Como tú ubi solo se mueve como 5 cuadras

[8:13 p. m.] **Tú:** Cuando miro jajaja

[8:14 p. m.] **Tú:**
> _Vale 🌙: Es un wework_
No mi vida me mataste

[8:14 p. m.] **Tú:** Yo mandé la hoja de vida

[8:14 p. m.] **Tú:** A un panteón

[8:14 p. m.] **Tú:** Voy a ver si me sale

[8:14 p. m.] **Tú:** Jajaja

[8:14 p. m.] **Vale 🌙:**
> _Tú: Como tú ubi solo se mueve como 5 cuadras_
Jsjsjs apenas salgo de bello me quedo sin señal ese hp celular lo voy es a cambiar

[8:14 p. m.] **Tú:** Pa que vayas y me revivas el muerto

[8:14 p. m.] **Vale 🌙:**
> _Tú: Pa que vayas y me revivas el muerto_
Jsjsjsjs

[8:14 p. m.] **Tú:**
> _Vale 🌙: Jsjsjs apenas salgo de bello me quedo sin señal ese hp celular lo voy es a cambiar_
Como así

[8:15 p. m.] **Tú:** Jajaja

[8:15 p. m.] **Tú:** Luego queda fuera de allá

[8:15 p. m.] **Tú:** No entiendo

[8:15 p. m.] **Tú:** Cuando tengas tiempo

[8:15 p. m.] **Tú:** Me explicas

[8:15 p. m.] **Tú:** Bien

[8:15 p. m.] **Tú:** O cuando volvamos hacer llamada

[8:15 p. m.] **Vale 🌙:**
> _Tú: Luego queda fuera de allá_
Sii

[8:15 p. m.] **Tú:** Pero que organizaste tu

[8:15 p. m.] **Tú:** Tu cuarto

[8:16 p. m.] **Tú:** Ya sacaron todo el desorden o todavía les faltan cositas para enviara

[8:16 p. m.] **Tú:** Avers

[8:16 p. m.] **Tú:** Mandas foticos

[8:16 p. m.] **Vale 🌙:**
> _Tú: Ya sacaron todo el desorden o todavía les faltan cositas para enviara_
Todavía faltan cosas

[8:16 p. m.] **Tú:** O videos

[8:16 p. m.] **Tú:** Pa  verte

[8:16 p. m.] **Tú:** Y la casa también

[8:16 p. m.] **Vale 🌙:** Toy comiendo

[8:16 p. m.] **Tú:**
> _Vale 🌙: Toy comiendo_
Acá te he visto roncando

[8:16 p. m.] **Tú:** Y de todo

[8:16 p. m.] **Tú:** Ya te eh visto

[8:17 p. m.] **Tú:** Manda eso es lo demenos

[8:17 p. m.] **Tú:** Tu comiéndotela te ves hermosa

[8:17 p. m.] **Tú:** Como dice Puerto Rico

[8:17 p. m.] **Tú:** [Sticker]

[8:18 p. m.] **Vale 🌙:** [Mensaje de video]

[8:18 p. m.] **Tú:** _Esperando el mensaje… Esto puede demorar un poco._

[8:18 p. m.] **Vale 🌙:**
> _Tú: Como dice Puerto Rico_
[Sticker]

[8:19 p. m.] **Vale 🌙:**
> _Tú: Imagen_
Amorrr jsjsjs noo

[8:19 p. m.] **Tú:** _Esperando el mensaje… Esto puede demorar un poco._

[8:19 p. m.] **Tú:** _Esperando el mensaje… Esto puede demorar un poco._

[8:20 p. m.] **Tú:** _Esperando el mensaje… Esto puede demorar un poco._

[8:20 p. m.] **Tú:** _Esperando el mensaje… Esto puede demorar un poco._

[8:21 p. m.] **Tú:**
> _Vale 🌙: Mensaje de video_
El mío como que se perdió

[8:21 p. m.] **Tú:** Dígame si no le gustó

[8:21 p. m.] **Tú:**
> _Vale 🌙: Mensaje de video_
Se ve más espacio

[8:21 p. m.] **Tú:** Ey eso se ve rico

[8:21 p. m.] **Tú:** Aguanta comerte

[8:21 p. m.] **Tú:**
> _Vale 🌙: Amorrr jsjsjs noo_
Con esas fotos

[8:21 p. m.] **Tú:** Me toca tirar paja todos los días para tenerte presente

[9:02 p. m.] **Tú:** Yo no sé cómo le vas hacer

[9:02 p. m.] **Tú:** Pero hoy yo quiero mis buenas noches

[9:02 p. m.] **Tú:** [Sticker]

[9:03 p. m.] **Vale 🌙:**
> _Tú: Imagen_
Esa si me gustó

[9:03 p. m.] **Vale 🌙:**
> _Tú: Imagen_
Jsjjsjs

[9:06 p. m.] **Vale 🌙:** [Imagen]

[9:08 p. m.] **Vale 🌙:**
> _Tú: Dígame si no le gustó_
Amor si te digo no me odias realmente Snoopy es mi favorito pero la hermana de mi mejor amigo se lo robo  no lo encontré antes de venirme pero apenas me paguen yo me compro uno se que te costó mucho dármelo  y la verdad  amo todo lo que me das  😭

[10:00 p. m.] **Tú:**
> _Vale 🌙: Esa si me gustó_
No recuerdo cual era

[10:01 p. m.] **Tú:**
> _Vale 🌙: Imagen_
Ta bella mi bb

[10:01 p. m.] **Tú:**
> _Vale 🌙: Amor si te digo no me odias realmente Snoopy es mi favorito pero la hermana de mi mejor amigo se lo robo  no lo encontré antes de venirme pero apenas me paguen yo me compro uno se que te costó mucho dármelo  y la verdad  amo todo lo que me das  😭_
Jum

[10:01 p. m.] **Tú:** Raro no se me hizo

[10:01 p. m.] **Tú:** Desde que fui  a la casa y no estaba

[10:02 p. m.] **Vale 🌙:** [Mensaje de voz]

[10:04 p. m.] **Vale 🌙:**
> _Tú: Desde que fui  a la casa y no estaba_
Ya lo averigue en míniso mi mamá dijo que si algo ella me ayudaba a comprarlo por que sabe lo importante que es para mí

[10:07 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Mmmm ma raro

[10:07 p. m.] **Tú:** Pero bueno

[10:07 p. m.] **Tú:** Vaya empelotandose  que esas me las cobro

[10:08 p. m.] **Tú:**
> _Vale 🌙: Ya lo averigue en míniso mi mamá dijo que si algo ella me ayudaba a comprarlo por que sabe lo importante que es para mí_
Deberías más bien de decirle a tu amigo

[10:08 p. m.] **Tú:** Y yo lo aguardo aca

[10:08 p. m.] **Tú:** Para que comprar otro si esta todavía el peluche

[10:08 p. m.] **Tú:** Ahi si como quien dice que se ponga serio

[10:08 p. m.] **Tú:** Primero eso no se hace

[10:09 p. m.] **Tú:** Digo yo no se

[10:10 p. m.] **Tú:** Y yo paso por el cuando lo tenga

[10:11 p. m.] **Tú:** Ya tu me dirás

[10:11 p. m.] **Tú:** Que haces

[10:11 p. m.] **Tú:** Ya comiste

[10:11 p. m.] **Tú:** Y segundo porque no me dijiste antes

[10:22 p. m.] **Vale 🌙:**
> _Tú: Y yo paso por el cuando lo tenga_
Le voy a decir que le diga ala hermana entonces

[10:23 p. m.] **Tú:**
> _Vale 🌙: Le voy a decir que le diga ala hermana entonces_
Pues si tu querés

[10:23 p. m.] **Tú:** Igual no se como haya sonado pero es lo más razonable

[10:23 p. m.] **Tú:** Porque no es de ella

[10:24 p. m.] **Vale 🌙:**
> _Tú: Y segundo porque no me dijiste antes_
Por que pensé que estaba aya por que el día anterior que yo estaba asiendo haceo deje algunas cosas en el cuarto de Sandra por que ella me estába ayudando a organizar cuando llegó del trabajo y ella me dijo si está acá yo se lo mando y ahora resulta que lo tiene Dana

[10:24 p. m.] **Tú:** Y no te dijeron  como si se lo podías dar o algo así desconozco  también

[10:24 p. m.] **Tú:**
> _Vale 🌙: Por que pensé que estaba aya por que el día anterior que yo estaba asiendo haceo deje algunas cosas en el cuarto de Sandra por que ella me estába ayudando a organizar cuando llegó del trabajo y ella me dijo si está acá yo se lo mando y ahora resulta que lo tiene Dana_
Verga

[10:24 p. m.] **Tú:** Entiendo

[10:24 p. m.] **Tú:** Igual  relax

[10:25 p. m.] **Tú:** Pa la próxima  dime

[10:25 p. m.] **Vale 🌙:** Bueno amor

[10:25 p. m.] **Tú:** Lo máximo que haré será meterle  los  dedos y la lengua

[10:25 p. m.] **Tú:** Me avisas que te dicen de eso

[10:25 p. m.] **Tú:** Igual  yo quiero me desquite

[10:26 p. m.] **Tú:** Que andas haciendo

[10:26 p. m.] **Tú:** Nada que ponen el Internet

[10:26 p. m.] **Tú:** O también  andas con más mentiras

[10:26 p. m.] **Tú:** [Sticker]

[10:27 p. m.] **Vale 🌙:**
> _Tú: O también  andas con más mentiras_
No amor se suponía que tenían que venir a arreglar eso hoy pero no llegaron

[10:27 p. m.] **Tú:**
> _Vale 🌙: No amor se suponía que tenían que venir a arreglar eso hoy pero no llegaron_
Sera que mañana  sábado si

[10:27 p. m.] **Tú:** Igual estos días no eh jugado

[10:27 p. m.] **Tú:** Por ti

[10:27 p. m.] **Tú:** Esperando

[10:27 p. m.] **Tú:** Y el server  quedo re bonito

[10:27 p. m.] **Tú:** Pues toca hacer todo otra vez

[10:27 p. m.] **Vale 🌙:**
> _Tú: Y el server  quedo re bonito_
Hay ya lo quiero ver

[10:28 p. m.] **Tú:** Pero ya sabes como iniciar

[10:28 p. m.] **Tú:**
> _Vale 🌙: Hay ya lo quiero ver_
Osea el lugar donde quedamos

[10:28 p. m.] **Tú:** Me gusto

[10:28 p. m.] **Tú:** Me refiero a eso

[10:28 p. m.] **Tú:** Ya te mando fotos

[10:28 p. m.] **Tú:** [Sticker]

[10:28 p. m.] **Tú:** Y del server también

[10:28 p. m.] **Tú:** 🤭

[10:29 p. m.] **Vale 🌙:** Hayy

[10:33 p. m.] **Tú:**
> _Vale 🌙: Hayy_
[Sticker]

[10:33 p. m.] **Tú:** Ese que me robe

[10:33 p. m.] **Tú:** Jajajs

[10:34 p. m.] **Vale 🌙:** Sjjsjsjs

[10:34 p. m.] **Vale 🌙:** Esta épico

[10:48 p. m.] **Tú:** Ya me robe unos stickers

[10:48 p. m.] **Tú:** Jakak

[10:48 p. m.] **Tú:** Que haces

[10:48 p. m.] **Tú:** [Sticker]

[10:48 p. m.] **Tú:** [Sticker]

[10:48 p. m.] **Tú:** [Sticker]

[10:48 p. m.] **Tú:** [Sticker]

[10:48 p. m.] **Tú:** [Sticker]

[10:48 p. m.] **Tú:** [Sticker]

[10:48 p. m.] **Tú:** [Sticker]

[10:48 p. m.] **Tú:** [Sticker]

[10:48 p. m.] **Tú:** [Sticker]

[10:48 p. m.] **Tú:** [Sticker]

[10:48 p. m.] **Tú:** [Sticker]

[10:49 p. m.] **Tú:** [Mensaje de album]

[10:49 p. m.] **Tú:** [Imagen]

[10:49 p. m.] **Tú:** [Imagen]

[10:49 p. m.] **Tú:** [Imagen]

[10:49 p. m.] **Tú:** [Imagen]

[10:49 p. m.] **Tú:** [Mensaje de unknown]

[10:49 p. m.] **Vale 🌙:**
> _Tú: [album]_
Me encanta

[10:50 p. m.] **Vale 🌙:**
> _Tú: Imagen_
Jsjs te amoo

[10:50 p. m.] **Vale 🌙:**
> _Tú: Ya me robe unos stickers_
Robarme los que tú me mandas

[10:50 p. m.] **Tú:**
> _Vale 🌙: Robarme los que tú me mandas_
Venga y me roba a mi mas bien

[10:50 p. m.] **Tú:** [Sticker]

[10:50 p. m.] **Tú:** [Sticker]

[10:51 p. m.] **Vale 🌙:** [Sticker]

[10:51 p. m.] **Vale 🌙:** [Sticker]

[10:52 p. m.] **Tú:** [Sticker]

[10:53 p. m.] **Tú:** [Sticker]

[10:53 p. m.] **Tú:** [Sticker]

[10:53 p. m.] **Tú:** [Sticker]

[10:58 p. m.] **Vale 🌙:** Te amito

[11:10 p. m.] **Vale 🌙:** _Esperando el mensaje… Esto puede demorar un poco._

[11:11 p. m.] **Tú:**
> _Vale 🌙: Imagen_
Mi amor bell9

[11:11 p. m.] **Tú:** La pregunta va

[11:11 p. m.] **Tú:** En porque para ver una vez

[11:11 p. m.] **Tú:** Tas muy buena y todo

[11:11 p. m.] **Tú:** Pero dioooos  amor

[11:11 p. m.] **Tú:**
> _Vale 🌙: Imagen_
[Sticker]

[11:12 p. m.] **Tú:** [Sticker]

[11:12 p. m.] **Vale 🌙:** Mañana ya voy a mimir

[11:12 p. m.] **Vale 🌙:** Era que me estaba bañando antes de acostarme

[11:13 p. m.] **Vale 🌙:** Ya mi hermana me regaño que me duerma

[11:13 p. m.] **Vale 🌙:** Hasta mañana mi rey duerme bien

[11:16 p. m.] **Tú:**
> _Vale 🌙: Mañana ya voy a mimir_
Va

[11:16 p. m.] **Tú:** Mi amor descansa

[11:16 p. m.] **Tú:**
> _Vale 🌙: Ya mi hermana me regaño que me duerma_
Jajajajaja

[11:16 p. m.] **Tú:** Así es que es

[11:16 p. m.] **Tú:** Bien por tu hermana ahí

[11:16 p. m.] **Tú:**
> _Vale 🌙: Hasta mañana mi rey duerme bien_
Sueña bonito

[11:17 p. m.] **Tú:** Les meilleurs "bonne nuit"
Ils ferment les yeux
Et sentir que vous êtes de l'autre côté du lit.

---

## 29 de agosto de 2026

[8:13 a. m.] **Vale 🌙:** [Imagen] Te vez todo tierno me encanta

[12:20 p. m.] **Tú:**
> _Vale 🌙: Imagen: Te vez todo tierno me encanta_
Y eso

[12:20 p. m.] **Tú:** De donde lo sacaste jakaskaksks

[12:20 p. m.] **Vale 🌙:** De mi compu

[12:47 p. m.] **Vale 🌙:** [Mensaje de album]

[12:47 p. m.] **Vale 🌙:** [Imagen]

[12:47 p. m.] **Vale 🌙:** [Imagen]

[2:27 p. m.] **Tú:** Cabalgata

[2:28 p. m.] **Tú:** Está bonitos esos caballos

[2:28 p. m.] **Tú:** Como vas mi vida bella

[2:28 p. m.] **Tú:** Yo llevo como 4 horas peleando con este proyecto

[2:36 p. m.] **Vale 🌙:** [Mensaje de voz]

[2:36 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
El del sena

[2:36 p. m.] **Tú:** La página esa que viste la última vez

[2:38 p. m.] **Vale 🌙:** [Mensaje de voz]

[2:38 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Es que no es solo hacerlo visual

[2:38 p. m.] **Tú:** Tiene que funcionar todo a la perfección

[2:38 p. m.] **Tú:** Entradas con Google que te mande correos

[2:38 p. m.] **Vale 🌙:** [Mensaje de voz]

[2:38 p. m.] **Tú:** Autentificación

[2:39 p. m.] **Tú:** Métodos de pago

[2:39 p. m.] **Tú:** Tiene que tener seguridad porque se maneja plata

[2:39 p. m.] **Vale 🌙:** [Mensaje de voz]

[2:39 p. m.] **Tú:** Usuarios la base de datos tiene que estar incriptada

[2:39 p. m.] **Tú:** Bueno etc yo ando haciendo lo de Google

[2:39 p. m.] **Tú:** Qué es la autenticidad

[2:39 p. m.] **Tú:** De la persona

[2:40 p. m.] **Vale 🌙:** [Mensaje de voz]

[2:40 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Exacto

[2:40 p. m.] **Tú:** Jajajaajs

[2:40 p. m.] **Tú:** No es difícil yo solo lo estoy haciendo con ia porque esos pelados lo hicieron solos

[2:41 p. m.] **Tú:** Pero ajá igual me toca mirar que todo esté bien

[2:41 p. m.] **Tú:** Que nada falle y no haya conflicto con el resto del código

[2:41 p. m.] **Vale 🌙:**
> _Tú: No es difícil yo solo lo estoy haciendo con ia porque esos pelados lo hicieron solos_
Jsjsjd procede a dejarle el trabajo a chati

[2:55 p. m.] **Tú:** Quién es chati

[2:55 p. m.] **Tú:** Jajaja

[2:55 p. m.] **Tú:** Que pasó con lo del internet

[2:55 p. m.] **Tú:** Si te pusieron

[2:55 p. m.] **Vale 🌙:**
> _Tú: Quién es chati_
Chatgpt

[2:58 p. m.] **Tú:** [Mensaje de voz]

[3:01 p. m.] **Vale 🌙:** [Mensaje de voz]

[3:02 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Va

[3:02 p. m.] **Tú:** Mandas foticos

[5:11 p. m.] **Vale 🌙:** [Imagen]

[5:12 p. m.] **Tú:**
> _Vale 🌙: Imagen_
Ojito

[5:12 p. m.] **Tú:** Donde andas

[5:12 p. m.] **Tú:** El vale te esta mirando feo jakak

[5:22 p. m.] **Vale 🌙:** Sii

[5:22 p. m.] **Vale 🌙:** [Mensaje de voz]

[5:23 p. m.] **Vale 🌙:** [Video]

[5:23 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Jajaajja

[5:23 p. m.] **Tú:** Tan chevere

[5:23 p. m.] **Tú:** Y ya terminaron compras

[5:24 p. m.] **Tú:**
> _Vale 🌙: Video_
Se ve bien interesante

[5:24 p. m.] **Tú:** Es de arte moderno

[5:24 p. m.] **Tú:** O tiene de todo

[5:24 p. m.] **Vale 🌙:** [Video]

[5:24 p. m.] **Vale 🌙:**
> _Tú: O tiene de todo_
De todo solo que no entre luego ago la visita bien

[5:26 p. m.] **Tú:**
> _Vale 🌙: Video_
Es re lindo por dentro

[5:27 p. m.] **Tú:** Parece una iglesia

[5:27 p. m.] **Tú:** De esas renacentista

[5:27 p. m.] **Tú:**
> _Vale 🌙: De todo solo que no entre luego ago la visita bien_
Me vas mandado

[5:27 p. m.] **Tú:** Y que compraron

[5:27 p. m.] **Tú:** Aparte de eso

[5:33 p. m.] **Vale 🌙:** Ropa pa mi hermana

[5:33 p. m.] **Vale 🌙:** Por que ahora todo le queda chiquito

[5:34 p. m.] **Vale 🌙:** Yo voy es a comprarme algo de tomar que el calor me tiene desidratada

[5:36 p. m.] **Tú:**
> _Vale 🌙: Yo voy es a comprarme algo de tomar que el calor me tiene desidratada_
Vale cuidate con eso

[5:36 p. m.] **Tú:** Me cuentas cuando estén en casa

[5:36 p. m.] **Tú:**
> _Vale 🌙: Por que ahora todo le queda chiquito_
Verga

[5:36 p. m.] **Tú:** Ya toca que le empieces a donar ropa

[5:40 p. m.] **Vale 🌙:** Ahora que llegue

[5:40 p. m.] **Vale 🌙:** Tengo el cel en 1

[8:10 p. m.] **Tú:**
> _Vale 🌙: Imagen_
Ey ese piso de abajo tiene puras flores no le tomaste fotos

[8:17 p. m.] **Vale 🌙:** [Imagen] Mila

[8:17 p. m.] **Tú:**
> _Vale 🌙: Imagen: Mila_
Es para ti

[8:17 p. m.] **Tú:** O de tu hermana

[8:22 p. m.] **Vale 🌙:**
> _Tú: Es para ti_
Para mi

[8:22 p. m.] **Tú:**
> _Vale 🌙: Para mi_
A ver póntelo

[8:22 p. m.] **Tú:** Quiero ver

[8:22 p. m.] **Vale 🌙:** [Imagen] Para mi hermana

[8:23 p. m.] **Tú:**
> _Vale 🌙: Imagen: Para mi hermana_
Está bonito

[8:23 p. m.] **Tú:** Siempre fue basten

[8:23 p. m.] **Tú:** Ahí no se ve todo

[8:54 p. m.] **Vale 🌙:** [Mensaje de album]

[8:54 p. m.] **Vale 🌙:** [Video] Nop

[8:54 p. m.] **Vale 🌙:** [Video]

[10:22 p. m.] **Tú:**
> _Vale 🌙: [album]_
Estaba bien bonito

[10:22 p. m.] **Tú:** Ya te mediste  lo que compraste

[10:22 p. m.] **Vale 🌙:** [Mensaje de voz]

[10:22 p. m.] **Tú:** Que andan haciendo

[10:22 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Va

[10:23 p. m.] **Vale 🌙:** [Mensaje de voz]

[10:23 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Ese gallo

[10:23 p. m.] **Tú:** Luego mañana

[10:23 p. m.] **Tú:** De piscina

[10:23 p. m.] **Tú:** O rio

[10:23 p. m.] **Vale 🌙:**
> _Tú: De piscina_
Tiii

[10:23 p. m.] **Vale 🌙:** Piscina

[10:23 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
El bulto donde esta el peluche

[10:23 p. m.] **Tú:** [Sticker]

[10:23 p. m.] **Tú:**
> _Vale 🌙: Piscina_
A que parte van

[10:24 p. m.] **Vale 🌙:**
> _Tú: A que parte van_
Jum nose vamos con la jefa de mi mami

[10:24 p. m.] **Vale 🌙:**
> _Tú: El bulto donde esta el peluche_
😭

[10:24 p. m.] **Vale 🌙:** Ya averigue donde comprarlo mañana cuando llegue de piscina voy por el

[10:25 p. m.] **Tú:**
> _Vale 🌙: Jum nose vamos con la jefa de mi mami_
Van con todo el combo

[10:25 p. m.] **Tú:** Van a pasar todo el día

[10:25 p. m.] **Vale 🌙:**
> _Tú: Van con todo el combo_
Sipi

[10:25 p. m.] **Vale 🌙:**
> _Tú: Van a pasar todo el día_
Sip

[10:25 p. m.] **Tú:**
> _Vale 🌙: Ya averigue donde comprarlo mañana cuando llegue de piscina voy por el_
Y que paso con el otro

[10:25 p. m.] **Tú:** Para que vas a gastar en eso

[10:26 p. m.] **Tú:** Ya pierde  la gracia

[10:26 p. m.] **Tú:** Digo yo no se

[10:26 p. m.] **Tú:** Más bien gaste eso en otra cosa que le pueda servir

[10:27 p. m.] **Vale 🌙:**
> _Tú: Y que paso con el otro_
Mi mejor amigo dice que la hermana no a ido por la casa y tampoco le contesta el celular

[10:36 p. m.] **Tú:**
> _Vale 🌙: Mi mejor amigo dice que la hermana no a ido por la casa y tampoco le contesta el celular_
Eso es un yaper

[10:37 p. m.] **Tú:** Igual no es tu culpa

[10:37 p. m.] **Tú:** El peluche puede esperar

[10:37 p. m.] **Tú:** Pero para mi la verdad

[10:37 p. m.] **Tú:** Reemplazar algo por otro igual ya pierde la gracia

[10:37 p. m.] **Tú:** Por más que sea igual

[10:37 p. m.] **Tú:** En otro momento  compraremos otro

[10:38 p. m.] **Tú:** Guarda  ese dinero para otra cosa

[10:38 p. m.] **Tú:** Me cuentas como te va mañana

[10:38 p. m.] **Tú:** Descansa

[10:48 p. m.] **Vale 🌙:** Esta bien amor 🥹

[10:48 p. m.] **Vale 🌙:**
> _Tú: Me cuentas como te va mañana_
Su mi cielo

[10:48 p. m.] **Vale 🌙:** Acá está lloviendo a cántaros

[10:48 p. m.] **Vale 🌙:** Mi gata ahorita tenía miedo asta se quedó dormida

[10:54 p. m.] **Tú:**
> _Vale 🌙: Esta bien amor 🥹_
Si ya no le meta más cabeza a eso

[10:54 p. m.] **Tú:** Y deje sus mentiras

[10:55 p. m.] **Tú:** El que busca encuentra

[10:55 p. m.] **Tú:**
> _Vale 🌙: Acá está lloviendo a cántaros_
Y eso

[10:55 p. m.] **Tú:** Aca esta lloviendo pero por tiempos

[10:55 p. m.] **Tú:** Osea una hora

[10:55 p. m.] **Tú:** O media

[10:55 p. m.] **Tú:** Y así

[10:55 p. m.] **Vale 🌙:** Acá se quiere caer el cielo

[10:55 p. m.] **Tú:** Pero esta haciendo cule frio

[10:55 p. m.] **Tú:**
> _Vale 🌙: Mi gata ahorita tenía miedo asta se quedó dormida_
Verdad tu gótica

[10:55 p. m.] **Tú:** Gatica  blanca

[10:56 p. m.] **Vale 🌙:**
> _Tú: Pero esta haciendo cule frio_
Acá solo en las noches en el día es calor ni el hp

[10:56 p. m.] **Tú:** Como esta

[10:56 p. m.] **Tú:**
> _Vale 🌙: Mi gata ahorita tenía miedo asta se quedó dormida_
Me imagino que se relajo

[10:56 p. m.] **Tú:** Dormira en el día

[10:56 p. m.] **Vale 🌙:**
> _Tú: Como esta_
Buen se escondió al lado de mi hermana y se quedó dormida

[10:56 p. m.] **Tú:** O no se jajaj

[10:56 p. m.] **Tú:** Yo estaba arreglando mis luces Led pero me aburri

[10:56 p. m.] **Tú:** Y me quede  un rato con mi mama

[10:56 p. m.] **Tú:** Y estaba probando lo que pedí

[10:56 p. m.] **Vale 🌙:**
> _Tú: Dormira en el día_
Duerme todo el tiempo más floja pero tiene a quien salir jsjs

[10:57 p. m.] **Tú:**
> _Vale 🌙: Acá solo en las noches en el día es calor ni el hp_
Verga

[10:57 p. m.] **Vale 🌙:** Ya hoy le compramos comida y arena

[10:57 p. m.] **Tú:** Pero ese clima a  mi se me hace rico osea si hace calor que en la noche haga friito para el desquite

[10:58 p. m.] **Tú:** En Cartagena llovía y era lo más de rico

[10:58 p. m.] **Tú:**
> _Vale 🌙: Buen se escondió al lado de mi hermana y se quedó dormida_
Porque la tratas  asi

[10:58 p. m.] **Tú:** Yo se que aveces los hermanos  son fastidiosos pero tampoco

[10:58 p. m.] **Vale 🌙:** Pues si como que enla tarde se compensa

[10:58 p. m.] **Tú:** Esta pela todavía

[10:58 p. m.] **Tú:** Puede  cambiar

[10:59 p. m.] **Tú:**
> _Vale 🌙: Duerme todo el tiempo más floja pero tiene a quien salir jsjs_
Jajajaaj

[10:59 p. m.] **Tú:**
> _Vale 🌙: Ya hoy le compramos comida y arena_
Ta bien

[10:59 p. m.] **Tú:** Eso ya olía a mierda

[10:59 p. m.] **Tú:** Y como le hacen el arenero

[10:59 p. m.] **Tú:** En el balcón

[10:59 p. m.] **Tú:** porque eso si debe de ser feo

[10:59 p. m.] **Tú:** Y más que tienen muchas cosas

[10:59 p. m.] **Tú:** El olor se impregnado

[10:59 p. m.] **Tú:**
> _Vale 🌙: Pues si como que enla tarde se compensa_
Kakaja

[10:59 p. m.] **Tú:** Pero rico

[11:00 p. m.] **Tú:** Y con café

[11:00 p. m.] **Tú:** Chocolate

[11:00 p. m.] **Tú:** Y cobija y sale

[11:00 p. m.] **Vale 🌙:** Pues se lo cambiamos semal y si lo tiebe en el balcón pero gracias a Dios como la arena es de maíz adsorve más y nosé pega y como tiene olor en no hiuele mal tu es fácil de la limpiar

[11:01 p. m.] **Vale 🌙:**
> _Tú: Y cobija y sale_
Sipi pero me haces falta  te necesito para calentarme bien

[11:12 p. m.] **Tú:**
> _Vale 🌙: Pues se lo cambiamos semal y si lo tiebe en el balcón pero gracias a Dios como la arena es de maíz adsorve más y nosé pega y como tiene olor en no hiuele mal tu es fácil de la limpiar_
De maíz

[11:12 p. m.] **Tú:** Como así jajajaaj

[11:12 p. m.] **Tú:** Yo al mio le metía aserrín

[11:12 p. m.] **Tú:** Una bolsa cuesta como 2 mil

[11:12 p. m.] **Tú:** Pues cuando antes donde vivía tenia un patio chiquito

[11:12 p. m.] **Tú:** No afectaba

[11:12 p. m.] **Tú:** Y eso duraba

[11:12 p. m.] **Tú:** Como 1 mes

[11:12 p. m.] **Tú:** Era una bolsa de basura

[11:13 p. m.] **Tú:** Pero pues aja

[11:13 p. m.] **Tú:** Pero la idea es que funcione

[11:13 p. m.] **Tú:** Nunca había escuchado de esa

[11:13 p. m.] **Tú:**
> _Vale 🌙: Sipi pero me haces falta  te necesito para calentarme bien_
Tu me calientas siempre

[11:13 p. m.] **Tú:** Ya haces falta

[11:13 p. m.] **Tú:** Cuando sales a vacaciones

[11:29 p. m.] **Vale 🌙:**
> _Tú: Cuando sales a vacaciones_
No tengo vacaciones asta cumplir un año en la empresa

---

## 30 de agosto de 2026

[8:53 a. m.] **Tú:**
> _Vale 🌙: No tengo vacaciones asta cumplir un año en la empresa_
Complicado

[8:53 a. m.] **Tú:** Tocaría un festivo o algo así

[8:53 a. m.] **Vale 🌙:** Si amor

[11:05 a. m.] **Tú:** Ta bien

[11:05 a. m.] **Tú:** Ya salieron

[11:06 a. m.] **Tú:** Si desayunaste

[11:18 a. m.] **Vale 🌙:**
> _Tú: Si desayunaste_
Tiu

[1:51 p. m.] **Tú:**
> _Vale 🌙: Video_
Y a uno si no le manda nada

[1:54 p. m.] **Tú:**
> _Vale 🌙: Video_
[Sticker]

[1:54 p. m.] **Tú:**
> _Vale 🌙: Video_
[Sticker]

[2:15 p. m.] **Vale 🌙:** [Video]

[3:39 p. m.] **Tú:**
> _Vale 🌙: Imagen_
Yo también las amo

[3:39 p. m.] **Tú:**
> _Vale 🌙: Video_
Uy

[3:39 p. m.] **Tú:** Pico sabroso

[4:36 p. m.] **Vale 🌙:**
> _Tú: Pico sabroso_
Te amo mi cielo

[6:34 p. m.] **Tú:** Ven yo quería

[6:34 p. m.] **Tú:** Decirte algo

[6:34 p. m.] **Tú:** Pero mejor pa otro día

[7:27 p. m.] **Vale 🌙:** Dime amor

[8:11 p. m.] **Tú:** Nombe deja así más bien

[8:11 p. m.] **Tú:** Mejor para otro momento

[8:12 p. m.] **Tú:** Descansa

[8:12 p. m.] **Tú:** Hablamos después

[8:12 p. m.] **Tú:** [Sticker]

[8:19 p. m.] **Tú:** De la manera más egoísta posible, no quiero que nadie más sepa como suenan los latidos de tu corazón al acostarse sobre tu pecho.

[8:43 p. m.] **Vale 🌙:**
> _Tú: De la manera más egoísta posible, no quiero que nadie más sepa como suenan los latidos de tu corazón al acostarse sobre tu pecho._
Jamás mi amor hermoso el único que se puede recostar sobre mi pecho y hacerme gemir eres tú

[10:07 p. m.] **Tú:**
> _Vale 🌙: Jamás mi amor hermoso el único que se puede recostar sobre mi pecho y hacerme gemir eres tú_
Cuando me dices eso estando tan lejos, siento que es difícil  confiar en ti

[10:07 p. m.] **Tú:**
> _Vale 🌙: Jamás mi amor hermoso el único que se puede recostar sobre mi pecho y hacerme gemir eres tú_
En encantas, mucho y lo sabes

[10:08 p. m.] **Tú:** Y te amo por eso

[10:08 p. m.] **Tú:** Cada palabra  que sale de tu boca es la lujurioso cuando entra por mis oídos

[10:09 p. m.] **Tú:** Y me corrompes  los pensamientos

[11:19 p. m.] **Tú:** Descansa

[11:20 p. m.] **Tú:** Me voy a poner a jugar con estos vales

[11:20 p. m.] **Tú:** Y me imagino que tú andas tomando

---

## 31 de agosto de 2026

[11:41 a. m.] **Vale 🌙:**
> _Tú: Y me imagino que tú andas tomando_
Tenía el cel descargado y mientras lo puse a cargar me quedé dormida por lo que tenía que madrugar para hoy

[3:06 p. m.] **Tú:**
> _Vale 🌙: Tenía el cel descargado y mientras lo puse a cargar me quedé dormida por lo que tenía que madrugar para hoy_
Mmmm

[3:06 p. m.] **Tú:** Ya veo

[3:06 p. m.] **Tú:** Ahorita estás en el trabajo

[3:06 p. m.] **Tú:** _Eliminaste este mensaje._

[3:56 p. m.] **Vale 🌙:** Que eliminaste

[3:57 p. m.] **Vale 🌙:** Ya  llegué ala casa

[3:57 p. m.] **Vale 🌙:** Como te fue hoy cielo

[3:58 p. m.] **Vale 🌙:** Me pagaron estos días

[3:58 p. m.] **Vale 🌙:** Y pues le di a mi mamá para el mercado y compre cosas personales que necesitaba metí una recarga de 10 días

[6:22 p. m.] **Tú:** Pero no entendí fuiste a trabajar hoy?

[6:23 p. m.] **Vale 🌙:**
> _Tú: Pero no entendí fuiste a trabajar hoy?_
Si

[6:23 p. m.] **Tú:**
> _Vale 🌙: Ya  llegué ala casa_
Y como les fue ayer, que hicieron en la tarde noche

[6:24 p. m.] **Tú:**
> _Vale 🌙: Si_
Mmmmm

[6:24 p. m.] **Tú:**
> _Vale 🌙: Y pues le di a mi mamá para el mercado y compre cosas personales que necesitaba metí una recarga de 10 días_
Y como van con el tema de la casa ya consiguieron algo nuevo

[6:24 p. m.] **Tú:** O siguen en el mismo sitio

[6:24 p. m.] **Vale 🌙:**
> _Tú: Y como les fue ayer, que hicieron en la tarde noche_
No pues nos quedamos en pisina simore como asta las 7 y de hay estuvimos en la casa de Stefi   luego se me apagó el cel  y mi mamá se puso a hablar con stefi y las pelas y me dormí con mi hermana

[6:25 p. m.] **Tú:** Es que no recuerdo el nombre del barrio donde vives

[6:25 p. m.] **Vale 🌙:**
> _Tú: Y como van con el tema de la casa ya consiguieron algo nuevo_
Mi mamá está mirando una cerca de donde trabaja

[6:25 p. m.] **Vale 🌙:**
> _Tú: Es que no recuerdo el nombre del barrio donde vives_
Maruchenga

[6:25 p. m.] **Tú:**
> _Vale 🌙: No pues nos quedamos en pisina simore como asta las 7 y de hay estuvimos en la casa de Stefi   luego se me apagó el cel  y mi mamá se puso a hablar con stefi y las pelas y me dormí con mi hermana_
No she quien es

[6:25 p. m.] **Tú:** Ósea no llegaste a la casa ayer

[6:25 p. m.] **Tú:** Explicas raro

[6:26 p. m.] **Vale 🌙:**
> _Tú: Ósea no llegaste a la casa ayer_
No nos quedamos donde Stefi  esta mañana  nos venimos temprano por que pues Andrea tenía que estudiar y yo trabajar nos cambiamos y salimos

[6:27 p. m.] **Tú:**
> _Vale 🌙: No pues nos quedamos en pisina simore como asta las 7 y de hay estuvimos en la casa de Stefi   luego se me apagó el cel  y mi mamá se puso a hablar con stefi y las pelas y me dormí con mi hermana_
Dormida ??

[6:28 p. m.] **Tú:**
> _Vale 🌙: No pues nos quedamos en pisina simore como asta las 7 y de hay estuvimos en la casa de Stefi   luego se me apagó el cel  y mi mamá se puso a hablar con stefi y las pelas y me dormí con mi hermana_
Pero bueno se la pasaron fuera de casa ayer todo el día

[6:28 p. m.] **Vale 🌙:**
> _Tú: Pero bueno se la pasaron fuera de casa ayer todo el día_
Sip

[6:29 p. m.] **Tú:**
> _Vale 🌙: Mi mamá está mirando una cerca de donde trabaja_
Ósea por maruchenga

[6:29 p. m.] **Tú:** Si

[6:29 p. m.] **Vale 🌙:**
> _Tú: Ósea por maruchenga_
No mi mamá trabaja por Florencia

[6:29 p. m.] **Tú:** Es que donde trabajas tú y ella me da vuelva

[6:29 p. m.] **Tú:**
> _Vale 🌙: No nos quedamos donde Stefi  esta mañana  nos venimos temprano por que pues Andrea tenía que estudiar y yo trabajar nos cambiamos y salimos_
Mmmm vea pues

[6:30 p. m.] **Tú:** Tú trabajas por donde cedritos

[6:30 p. m.] **Vale 🌙:**
> _Vale 🌙: No mi mamá trabaja por Florencia_
Aunque hoy trabajo en otro barrio que no me acuerdo  ala suegra de la jefa

[6:30 p. m.] **Tú:** No

[6:30 p. m.] **Tú:** Jajajaja

[6:30 p. m.] **Vale 🌙:**
> _Tú: No_
Si básicamente queda cerca

[6:30 p. m.] **Tú:** El nombre es raro ya me habías dicho

[6:31 p. m.] **Tú:**
> _Vale 🌙: Aunque hoy trabajo en otro barrio que no me acuerdo  ala suegra de la jefa_
Tu mami trabajo por otro lado

[6:31 p. m.] **Tú:** Pero y eso

[6:31 p. m.] **Tú:** Porque tu mami tiene varios trabajos

[6:31 p. m.] **Tú:** La veo en flores

[6:31 p. m.] **Tú:** Casa

[6:31 p. m.] **Tú:** Vendiendo

[6:31 p. m.] **Vale 🌙:** Por que hace haceo en casa de familia entonces cuando descansa  trabaja en otros lados donde trabajaba antes

[6:31 p. m.] **Tú:** Todera en el tema del trabajo

[6:32 p. m.] **Vale 🌙:** Mi mamá es Barbi ella trabaja en de todo

[6:32 p. m.] **Tú:**
> _Vale 🌙: Por que hace haceo en casa de familia entonces cuando descansa  trabaja en otros lados donde trabajaba antes_
Pero como le va con eso me imagino

[6:32 p. m.] **Tú:** Que Duro

[6:32 p. m.] **Tú:** Un día me gustaría conocer a tu mami

[6:32 p. m.] **Tú:** Se ve que se puede sacar varios temas de conversación con ella

[6:32 p. m.] **Tú:**
> _Vale 🌙: Si básicamente queda cerca_
Se llamada así

[6:32 p. m.] **Tú:** Noo

[6:32 p. m.] **Tú:** No recuerdo

[6:33 p. m.] **Vale 🌙:** Pues ahora por lo que yo llego antecitos del trabajo cuando ella viene ya todo está organizado y por lo general  hay comida

[6:33 p. m.] **Tú:** Tu mami trabaja normal en

[6:33 p. m.] **Tú:** Cerca de la casa

[6:33 p. m.] **Vale 🌙:**
> _Tú: No recuerdo_
Wework  es el sitio de las oficinas

[6:33 p. m.] **Tú:**
> _Vale 🌙: Sip_
Y eso donde estaban que

[6:33 p. m.] **Tú:** Eso se veía re lejos

[6:34 p. m.] **Tú:**
> _Vale 🌙: Wework  es el sitio de las oficinas_
Así se llama el barrio ola empresa

[6:34 p. m.] **Vale 🌙:**
> _Tú: Eso se veía re lejos_
Si eso es a media hora de acá solo que más asia Riva

[6:34 p. m.] **Vale 🌙:**
> _Tú: Así se llama el barrio ola empresa_
La empresa

[6:34 p. m.] **Tú:**
> _Vale 🌙: Wework  es el sitio de las oficinas_
Ahh si

[6:34 p. m.] **Tú:** Me dijiste que en el poblado no

[6:35 p. m.] **Tú:** Allá es como maluca la señal o que

[6:35 p. m.] **Vale 🌙:**
> _Tú: Me dijiste que en el poblado no_
Sip cerca del metro

[6:35 p. m.] **Vale 🌙:**
> _Tú: Allá es como maluca la señal o que_
Horrible esa hp

[6:35 p. m.] **Tú:**
> _Vale 🌙: Si eso es a media hora de acá solo que más asia Riva_
Ósea

[6:35 p. m.] **Tú:** Guíame con el mapa

[6:35 p. m.] **Tú:** Jajaja

[6:35 p. m.] **Tú:** [Imagen]

[6:36 p. m.] **Vale 🌙:** Flaco yo pa eso soy mala pero como es en pura lo mamá que más aya de Kenedy

[6:36 p. m.] **Tú:** Aver

[6:36 p. m.] **Tú:** Muéstrame

[6:36 p. m.] **Tú:**
> _Vale 🌙: Flaco yo pa eso soy mala pero como es en pura lo mamá que más aya de Kenedy_
Eso no es en Bogotá

[6:36 p. m.] **Tú:** Jajaja

[6:36 p. m.] **Tú:** Allá también hay un kenedy

[6:36 p. m.] **Vale 🌙:** [Imagen]

[6:37 p. m.] **Vale 🌙:** Lo amarillo es por donde queda la finca lo verde por donde vivo lo morado donde trabajo

[6:37 p. m.] **Vale 🌙:**
> _Tú: Allá también hay un kenedy_
Sii

[6:37 p. m.] **Tú:**
> _Vale 🌙: Imagen_
Finca ??

[6:38 p. m.] **Vale 🌙:**
> _Tú: Finca ??_
Pues el lugar de la piscina se llama finca la paola

[6:38 p. m.] **Tú:** Ahhh ya ya

[6:38 p. m.] **Tú:** Jajaja

[6:38 p. m.] **Tú:** Perate analizó

[6:40 p. m.] **Tú:**
> _Vale 🌙: Imagen_
Ósea tú vives en todo bello

[6:40 p. m.] **Tú:** Nanana

[6:40 p. m.] **Vale 🌙:**
> _Tú: Ósea tú vives en todo bello_
En un bario de bello

[6:41 p. m.] **Tú:**
> _Vale 🌙: En un bario de bello_
Ahh que es

[6:41 p. m.] **Tú:** El que me dijiste

[6:41 p. m.] **Vale 🌙:**
> _Tú: El que me dijiste_
Sii

[6:41 p. m.] **Tú:** Y tu mami

[6:41 p. m.] **Tú:** Pa donde trabaja

[6:41 p. m.] **Vale 🌙:** Acá mismo en bello pero en otro barrio

[6:43 p. m.] **Tú:** [Imagen] Por hay

[6:43 p. m.] **Tú:** Creo que eso no es todo bello

[6:43 p. m.] **Tú:** Jajaj

[6:44 p. m.] **Tú:** Es que no dice nada ese mapa

[6:44 p. m.] **Tú:** Creo que bello es ahí

[6:44 p. m.] **Tú:** [Imagen]

[6:45 p. m.] **Vale 🌙:** Ni  idea no me sé ubicar en mapas

[6:45 p. m.] **Tú:** Tiremos el monito

[6:45 p. m.] **Tú:** A ver que muestra

[6:46 p. m.] **Tú:** Así también me confundo

[6:46 p. m.] **Tú:** [Imagen]

[6:46 p. m.] **Vale 🌙:**
> _Tú: Imagen_
Hay vive stefa

[6:47 p. m.] **Tú:**
> _Vale 🌙: Hay vive stefa_
Tons eso no es bello

[6:47 p. m.] **Tú:** Bello queda para arriba

[6:47 p. m.] **Vale 🌙:**
> _Tú: Tons eso no es bello_
Noo

[6:47 p. m.] **Vale 🌙:** Eso es Kenedy pues el barrio

[6:47 p. m.] **Vale 🌙:** Unque creo que si asé parte de bello

[6:48 p. m.] **Tú:** [Imagen]

[6:48 p. m.] **Tú:**
> _Vale 🌙: Eso es Kenedy pues el barrio_
Así se llama

[6:48 p. m.] **Vale 🌙:**
> _Tú: Imagen_
Por hay trabaja mi mamá osea Florencia y si es acá en bello

[6:49 p. m.] **Tú:**
> _Vale 🌙: Eso es Kenedy pues el barrio_
[Imagen]

[6:49 p. m.] **Tú:** Ta lejos

[6:49 p. m.] **Tú:** Si se llama así

[6:50 p. m.] **Tú:** Conociendo Medellín desde Google maps

[6:50 p. m.] **Tú:** Jsjsj

[6:50 p. m.] **Tú:**
> _Vale 🌙: Por hay trabaja mi mamá osea Florencia y si es acá en bello_
Acá trabaja tu mami

[6:50 p. m.] **Tú:** Y eso por donde

[6:50 p. m.] **Tú:** Pa llegarle

[6:50 p. m.] **Tú:** Con un regalo

[6:50 p. m.] **Tú:** Pa cuando vaya

[6:50 p. m.] **Vale 🌙:** Es de mi casa pa abajo

[6:51 p. m.] **Vale 🌙:**
> _Tú: Y eso por donde_
La estación más cercana es madera

[6:51 p. m.] **Tú:**
> _Vale 🌙: Es de mi casa pa abajo_
Ósea la foto que te mande

[6:51 p. m.] **Tú:** Es cerca de donde vives

[6:51 p. m.] **Tú:** Y donde trabaja tu mami

[6:51 p. m.] **Tú:** No entendí

[6:52 p. m.] **Vale 🌙:** Relativamente si

[6:54 p. m.] **Tú:** [Imagen]

[6:54 p. m.] **Tú:** Me perdi

[6:55 p. m.] **Tú:** Sé que por ahí

[6:55 p. m.] **Tú:** Pero no vi la floristería

[6:55 p. m.] **Tú:** Pero es bonito por allá

[6:55 p. m.] **Tú:** Y cuanto pagan de arriendo

[6:55 p. m.] **Vale 🌙:** [Imagen] Queda por aca

[6:58 p. m.] **Tú:** [Imagen]

[6:59 p. m.] **Tú:** No paila

[6:59 p. m.] **Tú:** No vi nanda

[6:59 p. m.] **Tú:** Y tu pa que lado vives

[6:59 p. m.] **Tú:** [Imagen]

[6:59 p. m.] **Tú:** En punto es donde tu mami

[6:59 p. m.] **Tú:** Y tu

[7:00 p. m.] **Tú:** Bueno utds donde viven

[7:00 p. m.] **Vale 🌙:** [Imagen] Acá trabaja mi mama

[7:11 p. m.] **Tú:**
> _Vale 🌙: Imagen: Acá trabaja mi mama_
Ahh a lado de la cigarreria

[7:11 p. m.] **Tú:** Deporto es por la fecha

[7:11 p. m.] **Tú:** Pero creo que estoy mal

[7:11 p. m.] **Tú:** Ahí trabaja tu mami

[7:11 p. m.] **Tú:** Pero con la señora

[7:11 p. m.] **Vale 🌙:**
> _Tú: Ahí trabaja tu mami_
Si

[7:11 p. m.] **Tú:** No la floristería

[7:12 p. m.] **Vale 🌙:** En la floristería

[7:12 p. m.] **Tú:** Khe

[7:12 p. m.] **Tú:** [Sticker]

[7:12 p. m.] **Vale 🌙:** La cigarrera es de la señora de la floristería

[7:13 p. m.] **Tú:** Verga

[7:13 p. m.] **Tú:** Pero ya ya

[7:13 p. m.] **Tú:** Y tu pa donde vives

[7:13 p. m.] **Tú:** Pa ver a donde llegó mañana

[7:13 p. m.] **Vale 🌙:** Para arriba eso es asia bajo

[7:13 p. m.] **Tú:** Me das posada

[7:14 p. m.] **Vale 🌙:**
> _Tú: Me das posada_
Vienes

[7:14 p. m.] **Vale 🌙:** Si obio

[7:14 p. m.] **Tú:**
> _Vale 🌙: Vienes_
Ya compré todo

[7:14 p. m.] **Tú:** Per no voy con bulto

[7:14 p. m.] **Vale 🌙:**
> _Tú: Per no voy con bulto_
Jsjsj menos mal acá hay como mil

[7:14 p. m.] **Tú:** No me llega la plata

[7:14 p. m.] **Tú:** Pero ya está el tickete

[7:14 p. m.] **Tú:** Dile a tu mamá

[7:15 p. m.] **Tú:** Que me mande un audio diciendo que si me quiere allá

[7:15 p. m.] **Tú:** Si no para hacer la devolución

[7:16 p. m.] **Tú:** Me voy por boliviana

[7:16 p. m.] **Tú:** Creo que se llama la buseta

[7:16 p. m.] **Vale 🌙:** Ya le digo que te lo mandé

[7:17 p. m.] **Tú:** [Imagen]

[7:17 p. m.] **Tú:** Y me devuelve a pie yo creo

[7:17 p. m.] **Tú:** Lo que uno hace por amor

[7:17 p. m.] **Vale 🌙:**
> _Tú: Y me devuelve a pie yo creo_
Llegaron tres días Avilés a Bogotá

[7:17 p. m.] **Vale 🌙:**
> _Tú: Lo que uno hace por amor_
Te adoro mi niño precioso

[7:18 p. m.] **Tú:** Pero pasa

[7:18 p. m.] **Tú:** Dirección

[7:18 p. m.] **Tú:** O muéstrame en el mapa

[7:18 p. m.] **Tú:** Que no veo

[7:18 p. m.] **Vale 🌙:** Carrera 62 #21 a 47

[7:18 p. m.] **Vale 🌙:** D1 maruchenga

[7:19 p. m.] **Tú:** [Imagen] Porque se me hace raro que lleves todo el día ahí en ese sitio, y por más que se actualice sigues ahí está como raro no crees

[7:20 p. m.] **Tú:** [Imagen]

[7:20 p. m.] **Vale 🌙:** Que es eso

[7:20 p. m.] **Vale 🌙:** Por que sale así

[7:20 p. m.] **Vale 🌙:**
> _Tú: Imagen: Porque se me hace raro que lleves todo el día ahí en ese sitio, y por más que se actualice sigues ahí está como raro no crees_
Te aparezco serca de mi trabajo

[7:21 p. m.] **Tú:**
> _Vale 🌙: Te aparezco serca de mi ex trabajo_
Raro

[7:21 p. m.] **Tú:** Apareces que llevas desde la tarde

[7:21 p. m.] **Vale 🌙:**
> _Tú: Apareces que llevas desde la tarde_
Eche

[7:21 p. m.] **Tú:** Hasta que me empezaste a escribir

[7:21 p. m.] **Tú:** Ahí

[7:21 p. m.] **Tú:** Quieta

[7:21 p. m.] **Vale 🌙:** Tan raro

[7:21 p. m.] **Tú:** Jum

[7:22 p. m.] **Vale 🌙:** Toca que vengas y arregles mi cel entonces

[7:22 p. m.] **Tú:** Entra a insta

[7:22 p. m.] **Tú:** Pero hace rato entraste

[7:23 p. m.] **Tú:** Y me apareces todavía allá

[7:23 p. m.] **Vale 🌙:**
> _Tú: Entra a insta_
Ya entre

[7:23 p. m.] **Tú:** Nop

[7:23 p. m.] **Tú:** Sigues allá

[7:24 p. m.] **Tú:** 😐

[7:24 p. m.] **Vale 🌙:** [Imagen] Me aparece así

[7:24 p. m.] **Tú:**
> _Vale 🌙: Imagen: Me aparece así_
Dale a la tuerquita

[7:24 p. m.] **Tú:** Mira a ver qué te pide

[7:24 p. m.] **Tú:** Y eso por allá que queda o que

[7:25 p. m.] **Tú:** Aparecen puros moteles

[7:25 p. m.] **Tú:** [Sticker]

[7:25 p. m.] **Vale 🌙:** [Mensaje de video]

[7:25 p. m.] **Vale 🌙:**
> _Tú: Y eso por allá que queda o que_
Ni yo sé no estás viendo que no sale nada

[7:26 p. m.] **Vale 🌙:**
> _Tú: Aparecen puros moteles_
Eche ?

[7:26 p. m.] **Tú:**
> _Vale 🌙: Ni yo sé no estás viendo que no sale nada_
Ombe

[7:26 p. m.] **Tú:** Eso está raro

[7:26 p. m.] **Tú:** Porque debería de coger normal

[7:26 p. m.] **Tú:** Entres o no entres

[7:26 p. m.] **Tú:** Aparece siempre activo

[7:26 p. m.] **Tú:** Pero allá

[7:26 p. m.] **Tú:** Ósea tú estás allá

[7:26 p. m.] **Tú:** Según eso

[7:27 p. m.] **Tú:** [Imagen]

[7:27 p. m.] **Tú:** Tocó ese amor

[7:27 p. m.] **Tú:** Porque ni idea

[7:27 p. m.] **Tú:** Te volviste administradora de un motel

[7:27 p. m.] **Tú:** Ombe

[7:27 p. m.] **Tú:** Hubieras dicho

[7:28 p. m.] **Tú:** No te de pena mostrarme tu trabajo

[7:28 p. m.] **Tú:** Con razón no mandabas nada

[7:28 p. m.] **Tú:** No sale gratis

[7:28 p. m.] **Tú:** Por ser tu

[7:28 p. m.] **Tú:** Cómo será trabajar en eso

[7:28 p. m.] **Tú:** Todo el día con un cliente nuevo

[7:28 p. m.] **Tú:** Chisme nuevo

[7:28 p. m.] **Vale 🌙:** [Imagen] Ni yo sé dónde monda apareco  porque vivo por lo verde y trabajo por lo azul

[7:28 p. m.] **Tú:** Te imaginas

[7:29 p. m.] **Tú:** No que mira que volvió esta pelaa

[7:29 p. m.] **Tú:** Con un pelao nuevo

[7:29 p. m.] **Tú:** Uffff

[7:29 p. m.] **Vale 🌙:** Hay no gass

[7:30 p. m.] **Vale 🌙:**
> _Tú: Imagen_
Ya la instalo

[7:31 p. m.] **Tú:** Join my Circle in Life360! Invite code: BNX-34O. Tap the link to join. https://i.lf360.co/soCpRon735b

[7:31 p. m.] **Tú:** Si tiene un novio tóxico

[7:32 p. m.] **Tú:** Demalas

[7:32 p. m.] **Tú:** Jsjsjsjs

[7:32 p. m.] **Vale 🌙:** Me encanta

[7:32 p. m.] **Tú:** Todo el día

[7:32 p. m.] **Tú:** En la mañana en la noche allá metida en unos conjuros

[7:32 p. m.] **Tú:** Conjuntos

[7:32 p. m.] **Tú:** Ya se me hacía raro

[7:32 p. m.] **Tú:** [Sticker]

[7:32 p. m.] **Vale 🌙:** Amor no tengo megas para instalarlo

[7:32 p. m.] **Tú:**
> _Vale 🌙: Amor no tengo megas para instalarlo_
[Sticker]

[7:32 p. m.] **Tú:** No s

[7:33 p. m.] **Tú:** Consígase

[7:33 p. m.] **Vale 🌙:** Y eso que recargue el hp celular hoy

[7:33 p. m.] **Tú:** No que recargo 10 dias

[7:33 p. m.] **Vale 🌙:**
> _Tú: No que recargo 10 dias_
Siu

[7:33 p. m.] **Tú:** ????

[7:33 p. m.] **Tú:** Tonces

[7:33 p. m.] **Tú:** Dile a tu  mami que te de datos mientras

[7:33 p. m.] **Vale 🌙:** Como le compartí datos a mi hermana y se puso aver esas cosas chinas que ve no si se las gasto o que

[7:33 p. m.] **Tú:** Porque ese wifi está demorado

[7:34 p. m.] **Tú:**
> _Vale 🌙: Como le compartí datos a mi hermana y se puso aver esas cosas chinas que ve no si se las gasto o que_
Colócale ahorro de datos

[7:34 p. m.] **Tú:** Vos verás

[7:34 p. m.] **Vale 🌙:** Ya lo desconecte y sigue igual

[7:34 p. m.] **Tú:** Porque me la chamba donde me mostraste nunca te he visto

[7:34 p. m.] **Tú:** 🧐

[7:34 p. m.] **Tú:**
> _Vale 🌙: Ya lo desconecte y sigue igual_
Revisa

[7:34 p. m.] **Tú:** Cancela la descarga

[7:34 p. m.] **Tú:** Y ponla de nuevo

[7:35 p. m.] **Tú:** Pa ver

[7:35 p. m.] **Tú:** Las descripciones

[7:35 p. m.] **Tú:** No dan con los hecho

[7:35 p. m.] **Tú:** [Sticker]

[7:35 p. m.] **Vale 🌙:** Pera ver si le digo al novio de mi amam que me preste datos

[7:36 p. m.] **Tú:**
> _Vale 🌙: Pera ver si le digo al novio de mi amam que me preste datos_
Bueno hasta no ver eso

[7:36 p. m.] **Tú:** No la dejo en paz.

[7:36 p. m.] **Tú:** Y acepta todo

[7:36 p. m.] **Tú:** Y eso de andar desconectando los datos

[7:36 p. m.] **Tú:** Ayyyy Valentina

[7:37 p. m.] **Vale 🌙:**
> _Tú: Y eso de andar desconectando los datos_
Se los  desconecte ami hermana por que le estaba compartiendo

[7:37 p. m.] **Tú:** Ósea cuando estés por fuera

[7:37 p. m.] **Tú:** De la casa

[7:37 p. m.] **Tú:** Eso de que la ubicación todo el día en una casa y me dijo que salió temprano

[7:37 p. m.] **Tú:** No me da

[7:37 p. m.] **Vale 🌙:** Yo nunca los desconecto

[7:38 p. m.] **Vale 🌙:** Solo que nosé que monda está pasando con la ubicación

[7:38 p. m.] **Tú:** Bueno cuando instales eso le aceptas todo

[7:38 p. m.] **Vale 🌙:** Si amor

[7:38 p. m.] **Tú:** [Sticker]

[7:38 p. m.] **Tú:**
> _Vale 🌙: Si amor_
Es Sii mi amor

[7:38 p. m.] **Tú:** Hermoso

[7:38 p. m.] **Tú:** Ya está como rara últimamente

[7:38 p. m.] **Vale 🌙:** Como tú digas mi rey tóxico hermoso bello hombre de mi vida

[7:39 p. m.] **Tú:**
> _Vale 🌙: Como tú digas mi rey tóxico hermoso bello hombre de mi vida_
Aja

[7:39 p. m.] **Tú:** Foto cuca

[7:39 p. m.] **Tú:** Ahorita antes de acostarme

[7:39 p. m.] **Tú:** Quiero ver cómo está esto

[7:39 p. m.] **Tú:** A ver si sigue igual como lo dejé

[7:39 p. m.] **Vale 🌙:**
> _Tú: Ahorita antes de acostarme_
Bueno amor

[7:39 p. m.] **Tú:** [Sticker]

[7:40 p. m.] **Vale 🌙:** Jsjs esta bien estás loco pero así te amo

[7:40 p. m.] **Tú:** Y el internet para cuando lo piensas arreglar

[7:40 p. m.] **Tú:** Eso de que conectada todo el día en Messenger y no que no puede jugar

[7:40 p. m.] **Vale 🌙:** Esa gente de Tigo me tiene cansada todos los días dicen que van a mandar al técnico y no viene na

[7:40 p. m.] **Tú:** Que porque no le dan los datos para el juego pero si para chatear

[7:41 p. m.] **Vale 🌙:** Por que solo tengo WhatsApp y Facebook. Cuando se acaban las megas

[7:42 p. m.] **Vale 🌙:** Cielo como hoy me pagaron lo de los días y no voy a trabajar más hay  tengo como 20 lukas por hay namas después de darle eso amo mamá  pero ya tengo una entrevista el miércoles si te quedas me acompañas

[7:43 p. m.] **Tú:**
> _Vale 🌙: Como tú digas mi rey tóxico hermoso bello hombre de mi vida_
Aja como no me llamo Carlos eso de bb amor mi vida mi hombre ya no me convence

[7:43 p. m.] **Tú:**
> _Vale 🌙: Jsjs esta bien estás loco pero así te amo_
Cuál loco

[7:44 p. m.] **Tú:** Es darme mi lugar así como yo sé lo estoy dando a utd, que lamentable no estés aquí a mi lado no significa que no La Haya presentado a una pequeña parte de mi familia más cercana

[7:45 p. m.] **Vale 🌙:**
> _Tú: Es darme mi lugar así como yo sé lo estoy dando a utd, que lamentable no estés aquí a mi lado no significa que no La Haya presentado a una pequeña parte de mi familia más cercana_
Si amor es verdad  ya pronto vas a conocer a mi mamá y mi hermana etc

[7:45 p. m.] **Tú:**
> _Vale 🌙: Cielo como hoy me pagaron lo de los días y no voy a trabajar más hay  tengo como 20 lukas por hay namas después de darle eso amo mamá  pero ya tengo una entrevista el miércoles si te quedas me acompañas_
No vas  a trabajar mas

[7:45 p. m.] **Tú:** Y eso

[7:46 p. m.] **Vale 🌙:**
> _Tú: No vas  a trabajar mas_
No ese hp trabajo me la pela esa vaina no me cuadro prefiero volver a ser mesera o florista

[7:47 p. m.] **Vale 🌙:** Esque también y desde un principio no me gustó  y hoy Madrie a un cliente aproveche mi pago y renuncie

[7:48 p. m.] **Tú:**
> _Tú: Aja como no me llamo Carlos eso de bb amor mi vida mi hombre ya no me convence_
…

[7:48 p. m.] **Tú:**
> _Vale 🌙: No ese hp trabajo me la pela esa vaina no me cuadro prefiero volver a ser mesera o florista_
Que mal

[7:48 p. m.] **Tú:** Bueno desde que no te dejen una reseña mala es lo de menos

[7:48 p. m.] **Tú:** Trabajos ahí

[7:49 p. m.] **Tú:** Desde que no te desanime todo bien

[7:49 p. m.] **Vale 🌙:**
> _Tú: …_
Por que andas tan enojado mi cielo que te paso

[7:49 p. m.] **Tú:** Y qué has buscado

[7:49 p. m.] **Tú:** Yo me voy a ver si me meto a la cun

[7:50 p. m.] **Tú:** [Imagen]

[7:50 p. m.] **Tú:**
> _Vale 🌙: Esque también y desde un principio no me gustó  y hoy Madrie a un cliente aproveche mi pago y renuncie_
Verga y que le dijiste

[7:50 p. m.] **Tú:** Pero cuenta bien el chisme

[7:50 p. m.] **Tú:** Antes de estar juntos me contabas todo

[7:50 p. m.] **Vale 🌙:**
> _Tú: Imagen_
A super mi amor

[7:51 p. m.] **Tú:** Como donde con o sin condon posiciónes que decían

[7:51 p. m.] **Tú:** Porque terminaron que si el uno le decía al otro que la familia que la ex los cachos

[7:51 p. m.] **Tú:** Utd cambio resto

[7:51 p. m.] **Tú:** Ajá pero cuenta

[7:52 p. m.] **Tú:** Si te instalo eso

[7:52 p. m.] **Tú:**
> _Vale 🌙: A super mi amor_
Esperar

[7:52 p. m.] **Tú:** También es un call center

[7:52 p. m.] **Vale 🌙:**
> _Tú: Antes de estar juntos me contabas todo_
Esque un perro hp español tenía un proceso que otro compañero no ISO bien me echo la culpa dijo que los colombianos no seríbiamos etc etc. Y yo al principio era como señor eso no hace parte de mi área pasaré el reporte y eso asta que me alsonya la voz y eso  yo también le dije que si tanto le molestaban los procesos en colombia para que mierda trabajaba con uno que que a meterse su proyecto a su país etc

[7:53 p. m.] **Tú:** También pasé a cementerios

[7:53 p. m.] **Tú:** Panteones

[7:53 p. m.] **Tú:** Iglesias

[7:53 p. m.] **Tú:** Jajajaajaj

[7:53 p. m.] **Tú:** Severos traba jo S

[7:53 p. m.] **Vale 🌙:** Y que pensabas hacer en un cementerio

[7:54 p. m.] **Tú:**
> _Vale 🌙: Esque un perro hp español tenía un proceso que otro compañero no ISO bien me echo la culpa dijo que los colombianos no seríbiamos etc etc. Y yo al principio era como señor eso no hace parte de mi área pasaré el reporte y eso asta que me alsonya la voz y eso  yo también le dije que si tanto le molestaban los procesos en colombia para que mierda trabajaba con uno que que a meterse su proyecto a su país etc_
Jajajajajaj

[7:54 p. m.] **Tú:** No fue tan explícito

[7:54 p. m.] **Tú:** Pero bueno

[7:54 p. m.] **Tú:** Jakakakask

[7:54 p. m.] **Tú:** Y que le dijiste a tu jefe entonces

[7:54 p. m.] **Tú:** Es que eso. Nunca me llamó la atención eso para una persona con paciencia

[7:54 p. m.] **Tú:** Y caracter

[7:54 p. m.] **Tú:** Y no

[7:56 p. m.] **Vale 🌙:** Me dijo como no mira yo entiendo que hay clientes difícil pero es una etapa etc pero si es tu desición está bien acá simpre estarán las puertas abiertas  y yo le dije no si muchas gracias pero la verdad siento que en el momento tal vez esto no es lo estoy buscando y ya

[7:57 p. m.] **Vale 🌙:** Aunque obiamente está más emputada que 20 eso fue ya cuando me calme

[8:03 p. m.] **Vale 🌙:** El novio de mi mamá dice que para meterme de siso que el me ayuda con el curso que toca hacer

[8:05 p. m.] **Vale 🌙:**
> _Vale 🌙: El novio de mi mamá dice que para meterme de siso que el me ayuda con el curso que toca hacer_
Y meterme en la empresa del jefe  de él

[8:07 p. m.] **Tú:**
> _Vale 🌙: Por que andas tan enojado mi cielo que te paso_
No es enojo solo me gusta recalcar, mi lugar como te digo así, como a ti no te gusta que te diga gotda porque así le digo a todo mundo me parece perfecto, es tu lugar como mi pareja así mismo, yo sé que tú le dices a varias personas x o algunos en particular comentarios que dicen otra cosa sobre ti, en esta caso donde quedo yo, y lo que vas a decir y ya me lo has dicho varias veces no pides ser tu novia, pero si así estando juntos lo haces porque debería de Aver cambio después de pedirlo, es como decir no yo tengo una mejor amiga y le digo uf que hp cuerpo tan rico mami estás linda mi mujer bb eres la más linda, que seamos pareja y sigas igual, eso no es una relación común ya estarías buscar algo abierto, donde tanto tú como yo pueda hacer lo que quiera con ciertos límites y ya volver uno al otro no se es lo que me muestras, ocultar no significa que no pase…

[8:07 p. m.] **Tú:**
> _Vale 🌙: Y que pensabas hacer en un cementerio_
La pregunta ofende

[8:07 p. m.] **Tú:** Antes de que se enfríen obvio

[8:07 p. m.] **Tú:** Robarles todo

[8:07 p. m.] **Tú:** Jakssks

[8:08 p. m.] **Tú:** Vendemos eso y compramos una casita en Cartagena cerca a la playa

[8:08 p. m.] **Tú:** A punta de muertos

[8:08 p. m.] **Tú:**
> _Vale 🌙: Me dijo como no mira yo entiendo que hay clientes difícil pero es una etapa etc pero si es tu desición está bien acá simpre estarán las puertas abiertas  y yo le dije no si muchas gracias pero la verdad siento que en el momento tal vez esto no es lo estoy buscando y ya_
Mmmmm

[8:08 p. m.] **Tú:** Estuvo bien la verdad

[8:08 p. m.] **Vale 🌙:**
> _Tú: No es enojo solo me gusta recalcar, mi lugar como te digo así, como a ti no te gusta que te diga gotda porque así le digo a todo mundo me parece perfecto, es tu lugar como mi pareja así mismo, yo sé que tú le dices a varias personas x o algunos en particular comentarios que dicen otra cosa sobre ti, en esta caso donde quedo yo, y lo que vas a decir y ya me lo has dicho varias veces no pides ser tu novia, pero si así estando juntos lo haces porque debería de Aver cambio después de pedirlo, es como decir no yo tengo una mejor amiga y le digo uf que hp cuerpo tan rico mami estás linda mi mujer bb eres la más linda, que seamos pareja y sigas igual, eso no es una relación común ya estarías buscar algo abierto, donde tanto tú como yo pueda hacer lo que quiera con ciertos límites y ya volver uno al otro no se es lo que me muestras, ocultar no significa que no pase…_
Esta bien entiendo cielo

[8:09 p. m.] **Tú:** Pero esa forma de irse es relativa igual en la necesidad siempre va a estar el trabajo

[8:09 p. m.] **Tú:** Igual evitar ese tipo de trabajos pero si toca toca

[8:09 p. m.] **Tú:**
> _Vale 🌙: Aunque obiamente está más emputada que 20 eso fue ya cuando me calme_
No pues me imagino

[8:10 p. m.] **Tú:** Y la niña que no se enloqiece cuando le da rabia

[8:10 p. m.] **Vale 🌙:** Si amor tienes razón pero yo soy muy impulsiva entonces prefiero dejar así  antes de que sea peor

[8:10 p. m.] **Tú:**
> _Vale 🌙: El novio de mi mamá dice que para meterme de siso que el me ayuda con el curso que toca hacer_
Qué es sido

[8:10 p. m.] **Tú:** Siso

[8:11 p. m.] **Tú:**
> _Vale 🌙: El novio de mi mamá dice que para meterme de siso que el me ayuda con el curso que toca hacer_
Curso

[8:11 p. m.] **Tú:** Luego de que trata

[8:11 p. m.] **Tú:** Y si te da para eso

[8:11 p. m.] **Tú:** Explicate

[8:11 p. m.] **Tú:**
> _Vale 🌙: Y meterme en la empresa del jefe  de él_
Pero bueno ya tienes una palanca

[8:11 p. m.] **Tú:** Yo tengo varias opciones

[8:11 p. m.] **Tú:** Esperar si me sale algo acá en bogota

[8:11 p. m.] **Tú:** Si de acá a la cita media que tengo  no me sale nada

[8:11 p. m.] **Tú:** Al pueblo ahorro

[8:12 p. m.] **Vale 🌙:** Es básicamente la persona que se encarga de ver que todos estén cumpliendo sus labores y las normas de seguridad   y eso no es tan difícil es básicamente lo que ya ago pero en una obra

[8:12 p. m.] **Tú:** Y me habló con mi mami costeña que me de trabajo allá igual ganaría mejor porque ya entraría directamente con contrato y siendo uno de los mejores técnicos

[8:13 p. m.] **Tú:** Esatablecerme allá terminar estudios y mirar si vuelvo a Bogotá o me quedo

[8:13 p. m.] **Vale 🌙:**
> _Tú: Y me habló con mi mami costeña que me de trabajo allá igual ganaría mejor porque ya entraría directamente con contrato y siendo uno de los mejores técnicos_
Pues amor lo  que sea mejor para tu futuro

[8:13 p. m.] **Tú:** Pero lo de Cartagena ya sería si no consigo nada porque no me puedo quedar quieto

[8:13 p. m.] **Tú:** Otro año más

[8:13 p. m.] **Vale 🌙:** Te entiendo mi vida

[8:13 p. m.] **Tú:** Ósea la plata y todo eso es porque me eh podido mover por temporadas

[8:13 p. m.] **Tú:** Pero eso no sirve de nada

[8:14 p. m.] **Tú:** Y si me sale acá lo mismo meterle así sea una mierda aguantar lo más que pueda

[8:14 p. m.] **Tú:** Y ya después conseguir algo mejor

[8:14 p. m.] **Tú:**
> _Vale 🌙: Esta bien entiendo cielo_
No pues me dejarte sin palabras

[8:14 p. m.] **Tú:** Con ese punto de vista

[8:14 p. m.] **Tú:** Gracias mi amor

[8:14 p. m.] **Tú:**
> _Vale 🌙: Si amor tienes razón pero yo soy muy impulsiva entonces prefiero dejar así  antes de que sea peor_
Onve

[8:15 p. m.] **Tú:** Que si que

[8:15 p. m.] **Tú:** Jajajaj

[8:15 p. m.] **Vale 🌙:** Pues lo bueno de estas fechas  esque uno puede conseguir trabajo de temporada y aveses asta quedar fijo

[8:15 p. m.] **Tú:** Y eso que solo lo eh visto como 2 veces

[8:15 p. m.] **Tú:** Porque yo solo sé hago feliz bb

[8:15 p. m.] **Tú:** 4 años y solo dos emputadas

[8:16 p. m.] **Tú:** Join my Circle in Life360! Invite code: BNX-34O. Tap the link to join. https://i.lf360.co/10ZJYnya45b

[8:16 p. m.] **Vale 🌙:**
> _Tú: Gracias mi amor_
Pues es verdad ose tal cual tu lo dices  se que necesitas que yo sea un poco más espresiva en cuando públicamente se trata y moderar la forma en la que actuó para no generarte ni la más mínima duda

[8:18 p. m.] **Vale 🌙:**
> _Tú: 4 años y solo dos emputadas_
Pues esque me tocó aprender a tener paciencia y modular mi carácter  alas malas  entonces no exploto tan fácil o por lo menos en cuanto a las personas cercanas se trata

[8:26 p. m.] **Tú:**
> _Vale 🌙: Es básicamente la persona que se encarga de ver que todos estén cumpliendo sus labores y las normas de seguridad   y eso no es tan difícil es básicamente lo que ya ago pero en una obra_
Una supervisora

[8:26 p. m.] **Tú:** Es como seguridad en el trabajo algo así

[8:26 p. m.] **Tú:** Si te llega a salir estaría súper genial

[8:26 p. m.] **Tú:** La verdad

[8:26 p. m.] **Tú:** Es un buen puestos

[8:27 p. m.] **Tú:** Creo que no es tan esclavista

[8:27 p. m.] **Tú:** Y puedes coger experiencia

[8:27 p. m.] **Tú:** Ufff

[8:27 p. m.] **Tú:** Ojalá si te llegas hacer eso

[8:27 p. m.] **Tú:** O si te dan el visto bueno

[8:27 p. m.] **Tú:** Dale

[8:27 p. m.] **Tú:** Sin mente

[8:39 p. m.] **Vale 🌙:** Si amor mío

[8:42 p. m.] **Tú:** 🫤

[8:42 p. m.] **Tú:**
> _Vale 🌙: Pues amor lo  que sea mejor para tu futuro_
Igual lo de cambiar de ciudad

[8:42 p. m.] **Tú:** Es lo último

[8:42 p. m.] **Tú:** Por más que Cartagena sea muy lindo

[8:42 p. m.] **Tú:** No creo que sea capaz de iniciar de ceros

[8:42 p. m.] **Tú:** Solo

[8:43 p. m.] **Tú:** Ósea se me hace muy complicado irme de lo que ya tengo obvio en algún momento me tocará pero sé que para ese entonces

[8:43 p. m.] **Tú:** Voy a estar más estable

[8:43 p. m.] **Tú:** O acompañado

[8:43 p. m.] **Tú:**
> _Vale 🌙: Te entiendo mi vida_
Imagínate tú

[8:43 p. m.] **Tú:** Haciendo eso

[8:43 p. m.] **Tú:** La verdad no sé cómo le hiciste pero

[8:43 p. m.] **Tú:** Mis respetos eso si es algo que me hace falta

[8:44 p. m.] **Tú:** Pero nada es imposible

[8:44 p. m.] **Tú:** Y yo sé que si me voy allá

[8:44 p. m.] **Tú:** No voy a estar solo pero es duro

[8:44 p. m.] **Tú:** Igual

[8:44 p. m.] **Tú:**
> _Vale 🌙: Pues lo bueno de estas fechas  esque uno puede conseguir trabajo de temporada y aveses asta quedar fijo_
Yo quiero algo fijo

[8:44 p. m.] **Tú:** Temporada no sirve

[8:44 p. m.] **Tú:** Porque no te dan contrato

[8:44 p. m.] **Tú:** Y para entrar si quiera a una empresa desente

[8:44 p. m.] **Tú:** Tienes que tener estudios y experiencia

[8:45 p. m.] **Tú:** Y si no tiene nada es mejor empezar desde abajo o tener muy buen currículum y una buena oportunidad presente

[8:45 p. m.] **Tú:**
> _Vale 🌙: Pues es verdad ose tal cual tu lo dices  se que necesitas que yo sea un poco más espresiva en cuando públicamente se trata y moderar la forma en la que actuó para no generarte ni la más mínima duda_
No cielo

[8:45 p. m.] **Tú:** Estás totalmente equivocada

[8:45 p. m.] **Tú:** No sé si no me hice entender

[8:47 p. m.] **Tú:** O que a lo que me refiero no es que me hables bonito así ni más expresiva

[8:47 p. m.] **Tú:** No quiero que cambies

[8:49 p. m.] **Vale 🌙:**
> _Tú: Voy a estar más estable_
Así será con el favor de dios

[8:50 p. m.] **Vale 🌙:**
> _Tú: No voy a estar solo pero es duro_
Empezar de 0 simpre es duro y más cuando ya tienes una vida construida en otro lugar  por más que  estén otras personas

[8:50 p. m.] **Vale 🌙:**
> _Tú: Porque no te dan contrato_
Si dan pues en lo trabajos que yo e tenido por temporada lo hacen

[8:54 p. m.] **Vale 🌙:**
> _Tú: Y si no tiene nada es mejor empezar desde abajo o tener muy buen currículum y una buena oportunidad presente_
En eso tienes mucha razón amor la experiencia es algo super necesario laboral mente

[9:08 p. m.] **Tú:** Yo quiero sinceridad en un relación que tenga el descaro o los pantalones de decirme yo hice eso con tal persona o hable con tal persona así y así, y terminamos así, en casos extremos, pero hablar con la verdad como le digo no es ocultar el que busca encuentra no importa cuánto tiempo pase el tiempo dice la verdad, a lo que yo quiero llegar es que sé cómo eres llevo 4 años conociéndote no solo es culiar y ya yo sé cómo son tus comportamientos, sé cuando algo guarda, si dice la verdad o no, cuando quieres hacer algo cuando intentas evadir un tema es lo más obvio yo no digo las cosas por joder todo el tiempo cuando te pedía el celular así fuera para mirar tiktok, se te notaba el miedo, de que podía encontrar y ya sabes que si me da por buscar encuentro, yo con eso espero estés presente, mirar solo por mirar no me gusta, es tu privacidad, pero también es tu responsabilidad mirar que tienes ahí yo no soy pan de Dios ya sabes que tengo con quién hablo como hablo, a quien sigo a quien jodo etc pero te digo la verdad porque a pesar de todo prefiero decir mira hice eso con tal persona, hable esto si te gusta o no ya es algo dentro de la relación pero sé que no tengo que borrar ocultar mandar mensajes esperar lo que quiero y borrar si te das cuenta casi ni respondo y es porque no quiero dolores de cabeza puedes revisar sabes que hay y que no hay pero no le tengo miedo a lo que encuentres, pero tú eres otro plan aparte yo sé que toda mujer le van a caer manes eso es obvio no importa asi la mujer diga que es fea lo que sea le van a caer sea por el tema que sea, si no es sexo, tener su grupo de fans, o noviazgo un hombre no quiere más, mistad muy poca. Como te dije cuando empezamos esto si tú le vas a dar la entrada a otros hombres y tú le vas a estar siguiendo el tema los juego ocultándolos bajo solo hablo nunca lo eh visto es un amigo no nos vemos hace tiempo y salí con él y me quedé por x razón es mejor no hacer perder el tiempo de la otra persona si lo único que quieres es algo temporal o casual. 
Aclaro no digo que bloque que me de expiaciones de nada solo que cuando se canse o piense que esto no da dígalo no se haga mal de comentarios para después que un problema acumulado es peor.
Yo con utd me di la oportunidad de volver a pensar en tener algo bonito, algo estable, que si la distancia está listo habrán momentos para vernos, pero que esté presente que yo sienta que de verdad vale la pena hacer ese esfuerzo, yo creo que utd no estaría con una persona que la haga insegura, que esté constantemente, pensando en si hará o no con quien, si le gusta todavía si es verdad lo que dice, yo quiero que eso no pase que yo pueda confiar en utd y yo diga listo mi mujer está acá puede que solo te exija lo de la ubicación, está acá y sé que no va a ver problema, si sales un amor ya voy de salida mira y ya que Mor qué tal cosa y ya no le voy a decir mándeme todo el tiempo ni nada igual eso ya es que le nazca a la otra persona hacerlo, yo lo veo así como lo básico del algo que no está presente, no es todo pero creo que ya me hice entender no quiero perder el tiempo ni quiero estarme dando dolores de cabeza con algo que solo esté sintiendo yo, por eso dije a lo último, que quiere utd conmigo que opiniones tiene sobre lo que llevamos hasta el momento, que no le gusta que le gusta, no es solo yo la relación es de 2 ya es tu décision si quieres estar a mi lado o no yo creo que por eso me exigías a mí que estuviéramos en una relación…
Dime hasta donde quieres llegar y yo llego contigo
No se todo de ti pero se lo necesario para hacerte feliz.

[9:09 p. m.] **Tú:** Siii

[9:10 p. m.] **Tú:**
> _Vale 🌙: Así será con el favor de dios_
Siii

[9:11 p. m.] **Tú:** Esperar si  me da estar acá y esperar a que todo esto mejore

[9:11 p. m.] **Tú:** Vuelvas y podamos estar más estables mientras sacamos algo

[9:11 p. m.] **Tú:** Igual todavía tenemos tiempo para tomar decisiones

[9:11 p. m.] **Tú:**
> _Vale 🌙: Empezar de 0 simpre es duro y más cuando ya tienes una vida construida en otro lugar  por más que  estén otras personas_
Sii

[9:12 p. m.] **Tú:** Pues así me tocó cuando llegué allá la primera vez

[9:12 p. m.] **Tú:** Porque sabía que donde estaba nada era mío

[9:12 p. m.] **Tú:**
> _Vale 🌙: Si dan pues en lo trabajos que yo e tenido por temporada lo hacen_
Esperar

[9:12 p. m.] **Tú:** Igual tu también espero te salga todo

[9:12 p. m.] **Tú:** Eso significa que mañana no vas de chamba

[9:12 p. m.] **Tú:** Llama pa ver lo del wifi

[9:13 p. m.] **Tú:** Ombe

[9:13 p. m.] **Tú:** Eso dos días y me acostumbre a tu risa

[9:13 p. m.] **Tú:** De no sé qué hacer

[9:13 p. m.] **Tú:** Pero ya sabes basten

[9:13 p. m.] **Tú:** Lo básico ya con eso despegamos

[9:31 p. m.] **Vale 🌙:**
> _Tú: Yo quiero sinceridad en un relación que tenga el descaro o los pantalones de decirme yo hice eso con tal persona o hable con tal persona así y así, y terminamos así, en casos extremos, pero hablar con la verdad como le digo no es ocultar el que busca encuentra no importa cuánto tiempo pase el tiempo dice la verdad, a lo que yo quiero llegar es que sé cómo eres llevo 4 años conociéndote no solo es culiar y ya yo sé cómo son tus comportamientos, sé cuando algo guarda, si dice la verdad o no, cuando quieres hacer algo cuando intentas evadir un tema es lo más obvio yo no digo las cosas por joder todo el tiempo cuando te pedía el celular así fuera para mirar tiktok, se te notaba el miedo, de que podía encontrar y ya sabes que si me da por buscar encuentro, yo con eso espero estés presente, mirar solo por mirar no me gusta, es tu privacidad, pero también es tu responsabilidad mirar que tienes ahí yo no soy pan de Dios ya sabes que tengo con quién hablo como hablo, a quien sigo a quien jodo etc pero te digo la verdad porque a pesar de todo prefiero decir mira hice eso con tal persona, hable esto si te gusta o no ya es algo dentro de la relación pero sé que no tengo que borrar ocultar mandar mensajes esperar lo que quiero y borrar si te das cuenta casi ni respondo y es porque no quiero dolores de cabeza puedes revisar sabes que hay y que no hay pero no le tengo miedo a lo que encuentres, pero tú eres otro plan aparte yo sé que toda mujer le van a caer manes eso es obvio no importa asi la mujer diga que es fea lo que sea le van a caer sea por el tema que sea, si no es sexo, tener su grupo de fans, o noviazgo un hombre no quiere más, mistad muy poca. Como te dije cuando empezamos esto si tú le vas a dar la entrada a otros hombres y tú le vas a estar siguiendo el tema los juego ocultándolos bajo solo hablo nunca lo eh visto es un amigo no nos vemos hace tiempo y salí con él y me quedé por x razón es mejor no hacer perder el tiempo de la otra persona si lo único que quieres es algo temporal o casual. 
Aclaro no digo que bloque que me de expiaciones de nada solo que cuando se canse o piense que esto no da dígalo no se haga mal de comentarios para después que un problema acumulado es peor.
Yo con utd me di la oportunidad de volver a pensar en tener algo bonito, algo estable, que si la distancia está listo habrán momentos para vernos, pero que esté presente que yo sienta que de verdad vale la pena hacer ese esfuerzo, yo creo que utd no estaría con una persona que la haga insegura, que esté constantemente, pensando en si hará o no con quien, si le gusta todavía si es verdad lo que dice, yo quiero que eso no pase que yo pueda confiar en utd y yo diga listo mi mujer está acá puede que solo te exija lo de la ubicación, está acá y sé que no va a ver problema, si sales un amor ya voy de salida mira y ya que Mor qué tal cosa y ya no le voy a decir mándeme todo el tiempo ni nada igual eso ya es que le nazca a la otra persona hacerlo, yo lo veo así como lo básico del algo que no está presente, no es todo pero creo que ya me hice entender no quiero perder el tiempo ni quiero estarme dando dolores de cabeza con algo que solo esté sintiendo yo, por eso dije a lo último, que quiere utd conmigo que opiniones tiene sobre lo que llevamos hasta el momento, que no le gusta que le gusta, no es solo yo la relación es de 2 ya es tu décision si quieres estar a mi lado o no yo creo que por eso me exigías a mí que estuviéramos en una relación…
Dime hasta donde quieres llegar y yo llego contigo
No se todo de ti pero se lo necesario para hacerte feliz._
Soy consiente de que falle muchas veses en mi pasado se que as visto cosas que son lo que ocasionó que no confiaras del todo en mi y está bien se que lleva tiempo volver a creer en alguien esta vez quiero ya no ocultó nada a diferencia de antes ahora quiero que todos sepan que estoy con Tigo  también soy mucho más emocional está vez quiero hacer las cosas bien quiero dejar todas esas cosas malas a atrás y corregir mi pasado aunque me cueste  créeme que áre lo que esté en mis manos para que esto funcione mientras ambos lo queramos así  y si por cosas de la vida siento que no funciona  o algo pasa te lo diré por que mereces lo mejor de mi eres un chico increíble  en todos los sentidos por que con el tiempo entendí que tú eres mi elección eres el hombre que quiero en mi vida por que que de ti simpre recibiré la verdad mal o bien eres quien más me a conocido y a aceptado cada parte de mi hoy estoy segura de desir te amo  realmente lo ago no soy muy buena en estas cosas como ya lo sabes por qué antes pensaba que simpre terminaría igual  y me auto saboteo  cuando tengo miedo  pero está vez no quiero hacerlo gracias por estar hay siempre por demostrarme que puedo confiar en ti por mostrarte esa parte de ti que nunca pensé ver por darme otra oportunidad

[9:53 p. m.] **Vale 🌙:** Ya te mormiste?

[9:53 p. m.] **Vale 🌙:** Descansa mi amor lindo

[9:54 p. m.] **Tú:** Ando leyendo

[9:54 p. m.] **Tú:** Estaban poniendo una bellota en agua

[9:54 p. m.] **Tú:** Jajajajaj

[9:54 p. m.] **Tú:** So ver si sale un árbol

[9:56 p. m.] **Tú:**
> _Vale 🌙: Soy consiente de que falle muchas veses en mi pasado se que as visto cosas que son lo que ocasionó que no confiaras del todo en mi y está bien se que lleva tiempo volver a creer en alguien esta vez quiero ya no ocultó nada a diferencia de antes ahora quiero que todos sepan que estoy con Tigo  también soy mucho más emocional está vez quiero hacer las cosas bien quiero dejar todas esas cosas malas a atrás y corregir mi pasado aunque me cueste  créeme que áre lo que esté en mis manos para que esto funcione mientras ambos lo queramos así  y si por cosas de la vida siento que no funciona  o algo pasa te lo diré por que mereces lo mejor de mi eres un chico increíble  en todos los sentidos por que con el tiempo entendí que tú eres mi elección eres el hombre que quiero en mi vida por que que de ti simpre recibiré la verdad mal o bien eres quien más me a conocido y a aceptado cada parte de mi hoy estoy segura de desir te amo  realmente lo ago no soy muy buena en estas cosas como ya lo sabes por qué antes pensaba que simpre terminaría igual  y me auto saboteo  cuando tengo miedo  pero está vez no quiero hacerlo gracias por estar hay siempre por demostrarme que puedo confiar en ti por mostrarte esa parte de ti que nunca pensé ver por darme otra oportunidad_
Aww Encerio amor

[9:56 p. m.] **Tú:** Yo también haré todo para que esto siga y hasta donde nos dé para estar juntos siempre

[9:56 p. m.] **Tú:** Estaré a tu lado

[9:57 p. m.] **Tú:** En pocas palabras estés mi perrita sentimental, bueno

[9:57 p. m.] **Tú:** La ubicación

[9:57 p. m.] **Tú:** No se haga

[9:58 p. m.] **Vale 🌙:** Amor toca esperara a mañana en mi casa todos estamos con WhatsApp y Facebook

[9:58 p. m.] **Tú:** Ta bien

[9:59 p. m.] **Tú:** Qué vas hacer mañana entonces

[9:59 p. m.] **Tú:** Descansar

[9:59 p. m.] **Tú:** O qie

[9:59 p. m.] **Tú:** Mi mamá me preguntó por ti hoy

[9:59 p. m.] **Tú:** Y jum

[9:59 p. m.] **Tú:** Esa pela está como desparecida

[9:59 p. m.] **Tú:** Y mi foto cuca

[9:59 p. m.] **Tú:** Yo cerd

[9:59 p. m.] **Tú:** Veré

[9:59 p. m.] **Tú:** [Sticker]

[9:59 p. m.] **Tú:**
> _Vale 🌙: Amor toca esperara a mañana en mi casa todos estamos con WhatsApp y Facebook_
Perdonada

[10:02 p. m.] **Vale 🌙:** Nada amor volver a organizar la casa por que mi hermana ISO un desastre y de la rabia que tenía cuando llegue del trabajo nk sé dónde dejé mi bolso y hay está mi cédula mis gafas todo

[10:02 p. m.] **Tú:**
> _Vale 🌙: Video: Conocerlo a sido de las mejores experiencias de mi vida lo amo ✨🌙_
[Sticker]

[10:03 p. m.] **Vale 🌙:**
> _Tú: Sticker_
Tan grosero

[10:04 p. m.] **Tú:** Nananana

[10:04 p. m.] **Tú:** Esa foto

[10:04 p. m.] **Tú:** Nakajakaja

[10:04 p. m.] **Tú:** Voy a subir una pichando puedo

[10:04 p. m.] **Vale 🌙:**
> _Tú: Voy a subir una pichando puedo_
Jsjsjs noo

[10:04 p. m.] **Tú:** Porque no rico

[10:04 p. m.] **Tú:**
> _Vale 🌙: Nada amor volver a organizar la casa por que mi hermana ISO un desastre y de la rabia que tenía cuando llegue del trabajo nk sé dónde dejé mi bolso y hay está mi cédula mis gafas todo_
Verga

[10:04 p. m.] **Tú:** Jajajajaja

[10:04 p. m.] **Vale 🌙:**
> _Tú: Imagen: 🌙_
Jsjsjjs amoo

[10:04 p. m.] **Tú:** Mañana el desquite con la casa

[10:04 p. m.] **Tú:** Y nosotros dos pa cuando

[10:05 p. m.] **Vale 🌙:**
> _Vale 🌙: Jsjsjjs amoo_
Pásamela yo no tengo esa foto

[10:05 p. m.] **Tú:** De cuales

[10:05 p. m.] **Vale 🌙:**
> _Tú: Y nosotros dos pa cuando_
Cuando temos juntitos

[10:05 p. m.] **Tú:** En cuera

[10:05 p. m.] **Tú:** Las tienes en el pc

[10:05 p. m.] **Vale 🌙:**
> _Tú: Las tienes en el pc_
Si me di cuenta asta vídeos

[10:05 p. m.] **Tú:**
> _Vale 🌙: Cuando temos juntitos_
[Mensaje de album]

[10:06 p. m.] **Tú:** [Mensaje de unknown]

[10:06 p. m.] **Tú:** [Mensaje de unknown]

[10:06 p. m.] **Tú:** [Mensaje de unknown]

[10:06 p. m.] **Tú:** [Mensaje de unknown]

[10:06 p. m.] **Tú:** [Mensaje de unknown]

[10:06 p. m.] **Tú:** [Mensaje de unknown]

[10:06 p. m.] **Tú:** [Mensaje de unknown]

[10:06 p. m.] **Tú:** [Mensaje de unknown]

[10:06 p. m.] **Tú:** [Mensaje de unknown]

[10:06 p. m.] **Tú:** [Mensaje de unknown]

[10:06 p. m.] **Tú:** En las últimas alguien me quería desvestir

[10:06 p. m.] **Tú:** [Mensaje de unknown]

[10:06 p. m.] **Tú:** [Mensaje de unknown]

[10:06 p. m.] **Tú:** El día que se iba a ir

[10:06 p. m.] **Tú:** Esos dos últimos días alguien no se quería separar del señor sachicha en el baño cuando estábamos hablando. Lo de tu hermana

[10:06 p. m.] **Tú:** Vi esas intenciones

[10:06 p. m.] **Tú:** [Sticker]

[10:06 p. m.] **Vale 🌙:**
> _Tú: Imagen_
Jsjsjs

[10:07 p. m.] **Vale 🌙:**
> _Tú: Imagen_
Porque tienes eso

[10:07 p. m.] **Vale 🌙:**
> _Tú: Imagen_
Jsjsjs horrible

[10:08 p. m.] **Vale 🌙:**
> _Tú: Vi esas intenciones_
Jsjsjjs 🤭

[10:10 p. m.] **Vale 🌙:**
> _Tú: En las últimas alguien me quería desvestir_
Si soyy

[10:14 p. m.] **Vale 🌙:**
> _Tú: Imagen_
Todos lindos

[10:20 p. m.] **Tú:**
> _Vale 🌙: Jsjsjs_
Queeejajaaj

[10:20 p. m.] **Tú:** Estaba haciendo la racha del duo

[10:20 p. m.] **Tú:**
> _Vale 🌙: Porque tienes eso_
Porque si

[10:20 p. m.] **Tú:** Utd tiene fotos mías más feas

[10:20 p. m.] **Tú:**
> _Vale 🌙: Jsjsjs horrible_
Que va

[10:20 p. m.] **Vale 🌙:** Noo

[10:20 p. m.] **Tú:** Pa mi

[10:20 p. m.] **Tú:**
> _Vale 🌙: Jsjsjjs 🤭_
Que rico

[10:20 p. m.] **Tú:** Cuando te pones así

[10:21 p. m.] **Tú:** Sin decir nada

[10:21 p. m.] **Tú:** Me enciera

[10:21 p. m.] **Tú:** Encuera

[10:21 p. m.] **Tú:** Mi fantasía cada vez que te veo

[10:21 p. m.] **Tú:**
> _Vale 🌙: Todos lindos_
Pa que vea

[10:21 p. m.] **Tú:** Estaba más sudado

[10:21 p. m.] **Tú:** Y me toca peliquearme

[10:21 p. m.] **Vale 🌙:** Jsjsjs y eso mucho sol

[10:21 p. m.] **Tú:** Y mirar a ver de donde me meto pelo pa la cabeza jsjsjssj

[10:22 p. m.] **Tú:**
> _Vale 🌙: Jsjsjs y eso mucho sol_
Sii salimos a un mirador que mi mamá quería salir

[10:22 p. m.] **Vale 🌙:**
> _Tú: Sii salimos a un mirador que mi mamá quería salir_
A que chevere

[10:22 p. m.] **Tú:** Siiii

[10:22 p. m.] **Tú:** Y tu que andas haciendo

[10:23 p. m.] **Vale 🌙:** Nada amor ya me voy a dormir

[10:23 p. m.] **Vale 🌙:** El celular está en uno y no tengo cargador

[10:23 p. m.] **Tú:**
> _Vale 🌙: Nada amor ya me voy a dormir_
Ahh bueno mi vida

[10:23 p. m.] **Tú:** Des casa entonces

[10:23 p. m.] **Vale 🌙:** Por que esta en mi bolso

[10:23 p. m.] **Tú:** Dulces  sueños

[10:23 p. m.] **Tú:**
> _Vale 🌙: Por que esta en mi bolso_
Jajajajaja

[10:23 p. m.] **Tú:** Ma raro ese celular descargado

[10:24 p. m.] **Vale 🌙:**
> _Tú: Dulces  sueños_
Descansa mi amor hermoso

[10:24 p. m.] **Vale 🌙:** Sueña con cosas bonitas

[10:24 p. m.] **Tú:**
> _Vale 🌙: Sueña con cosas bonitas_
Bonitas

[10:24 p. m.] **Vale 🌙:** [Sticker]

[10:24 p. m.] **Tú:** Ahorita voy a pensar en cómo la desvisto

[10:24 p. m.] **Tú:** [Sticker]

[10:29 p. m.] **Tú:** Sabes que si eh pensado que te hagas así no se siento que te quedaría rico

[10:29 p. m.] **Tú:** Los piercing de los pezones

---

## 1 de septiembre de 2026

[7:45 a. m.] **Vale 🌙:** Buenos días amor

[7:46 a. m.] **Vale 🌙:**
> _Tú: Los piercing de los pezones_
Eso tiene que doler horrible

[11:26 a. m.] **Vale 🌙:** Amor quien es Maira

[11:27 a. m.] **Tú:** Maira

[11:27 a. m.] **Tú:** Maira que

[11:29 a. m.] **Vale 🌙:** Maira Yurani Rodríguez

[11:29 a. m.] **Tú:** Una compañera del colegio

[11:29 a. m.] **Tú:** Luego

[11:29 a. m.] **Vale 🌙:** No nada

[11:30 a. m.] **Tú:** La conoces o qué

[11:30 a. m.] **Vale 🌙:** No es conocida  de alguien que conozco

[11:57 a. m.] **Vale 🌙:** Que haces amor

[11:58 a. m.] **Tú:** Entrevista

[11:58 a. m.] **Vale 🌙:** A bueno mi cielo que te valla super bien

[11:59 a. m.] **Vale 🌙:** Ubicación en tiempo real: 6.311769, -75.5727856 — https://maps.google.com/?q=6.311769,-75.5727856

[11:59 a. m.] **Vale 🌙:** Voy a ir a recojer a mi hermana

[3:39 p. m.] **Tú:**
> _Vale 🌙: A bueno mi cielo que te valla super bien_
Esperar que me dicen

[3:39 p. m.] **Tú:** Pero que para eso del call center

[3:39 p. m.] **Tú:** Me va bien voy hacer más postulaciones

[3:40 p. m.] **Tú:** Yo apenas llegué salí con mi mamá

[3:40 p. m.] **Tú:** Hacer unas cosas. Comprar algo

[3:40 p. m.] **Tú:** Y acabamos de llegar

[3:40 p. m.] **Tú:** Cómo te fue

[3:40 p. m.] **Tú:**
> _Vale 🌙: No es conocida  de alguien que conozco_
Como asi

[3:40 p. m.] **Tú:** Como lo dices así como a lo mal

[3:40 p. m.] **Tú:** Luego que pasó con la pela

[3:40 p. m.] **Tú:** Dijo algo o que

[3:41 p. m.] **Vale 🌙:** Nada solo que sale de tu casa a eso de 7 8 de la mañana  pero pues normal

[3:41 p. m.] **Vale 🌙:**
> _Tú: Cómo te fue_
Bien amor

[3:41 p. m.] **Vale 🌙:**
> _Tú: Yo apenas llegué salí con mi mamá_
A que bien amor y que compraron

[3:41 p. m.] **Vale 🌙:** Saludes a tu mami

[3:41 p. m.] **Tú:**
> _Vale 🌙: Nada solo que sale de tu casa a eso de 7 8 de la mañana  pero pues normal_
Sale de mi casa

[3:42 p. m.] **Tú:** Como así que de mi casa

[3:42 p. m.] **Tú:**
> _Vale 🌙: A que bien amor y que compraron_
Unas cosas para el oficio

[3:42 p. m.] **Tú:**
> _Vale 🌙: Saludes a tu mami_
Ahorita

[3:42 p. m.] **Tú:** Que almorcemos

[3:42 p. m.] **Vale 🌙:**
> _Tú: Como así que de mi casa_
Y yo ve tan raro   pero pues nosé depronto tiene amigos por hay serca o algo

[3:43 p. m.] **Tú:**
> _Vale 🌙: Y yo ve tan raro   pero pues nosé depronto tiene amigos por hay serca o algo_
No entendí

[3:43 p. m.] **Tú:** Explica bien

[3:43 p. m.] **Tú:** De donde salió todo eso

[3:43 p. m.] **Tú:** Ósea la pela si me suena

[3:44 p. m.] **Tú:** Según yo es una chiquita

[3:44 p. m.] **Tú:** Pelo largo

[3:44 p. m.] **Tú:** Creo que tengo una foto

[3:44 p. m.] **Tú:** Pero ajá explica bien eso

[3:44 p. m.] **Tú:** Y como que sale de mi casa

[3:44 p. m.] **Vale 🌙:** [Mensaje de voz]

[3:45 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Cuál pelada

[3:45 p. m.] **Tú:** Pero manda foto

[3:45 p. m.] **Tú:** Porque no se acá salen varias personas

[3:45 p. m.] **Tú:** Pero ella en concreto no

[3:45 p. m.] **Vale 🌙:** [Mensaje de voz]

[3:46 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Pero yo con ella no hablo hace años

[3:46 p. m.] **Tú:** Porque ella se salió del colegio

[3:46 p. m.] **Tú:** Sé que vive por acá porque la eh visto más no hablo con ella

[3:46 p. m.] **Tú:** Por eso te digo de foto

[3:46 p. m.] **Tú:** Pa ver si es o no es la que yo conozco

[3:46 p. m.] **Vale 🌙:** [Mensaje de voz]

[3:47 p. m.] **Vale 🌙:** [Mensaje de voz]

[3:48 p. m.] **Tú:** [Mensaje de album]

[3:48 p. m.] **Tú:** [Imagen]

[3:48 p. m.] **Tú:** [Imagen]

[3:48 p. m.] **Tú:** [Imagen]

[3:48 p. m.] **Tú:** Ella es la que yo conozco

[3:48 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Pregúntele a ver

[3:49 p. m.] **Tú:** Pero no pase fotos primero

[3:49 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Pelao esta es como raro con yo

[3:49 p. m.] **Tú:** Jajaja Tiris

[3:50 p. m.] **Tú:** Porque yo con las peladas con las que él hablaba yo me la pasaba y me mira como un culo ese pelao

[3:50 p. m.] **Tú:** Tons no se

[3:50 p. m.] **Tú:** Por eso tampoco me gusta publicar nada

[3:50 p. m.] **Tú:** Cada quien a lo suyo

[3:50 p. m.] **Vale 🌙:** [Reenviado] Pero es que él se ve con esa muchacha desde hace rato 

Yo a ella siempre me la encontraba en las mañanas saliendo del barrio 

Ahí en la esquina de la plaza

[3:51 p. m.] **Vale 🌙:**
> _Vale 🌙: Pero es que él se ve con esa muchacha desde hace rato 

Yo a ella siempre me la encontraba en las mañanas saliendo del barrio 

Ahí en la esquina de la plaza_
[Mensaje de voz]

[3:51 p. m.] **Vale 🌙:**
> _Tú: Porque yo con las peladas con las que él hablaba yo me la pasaba y me mira como un culo ese pelao_
David mira feo asta la mamá

[3:51 p. m.] **Tú:**
> _Vale 🌙: Pero es que él se ve con esa muchacha desde hace rato 

Yo a ella siempre me la encontraba en las mañanas saliendo del barrio 

Ahí en la esquina de la plaza_
Ve

[3:52 p. m.] **Tú:** Ni yo sabía eso

[3:52 p. m.] **Tú:** Que tome fotos pa la próxima

[3:52 p. m.] **Tú:** Sisas dile eso como ve como así

[3:52 p. m.] **Tú:** Si llegas a ver eso tómale una foto

[3:52 p. m.] **Vale 🌙:** [Mensaje de voz]

[3:52 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Ósea yo en ella no hable

[3:52 p. m.] **Tú:** Que eso está re mal

[3:53 p. m.] **Tú:** Ósea yo con ella no hablo ufff

[3:53 p. m.] **Tú:** Sé que vive por acá

[3:53 p. m.] **Tú:** No sé si donde vivía cuando hablábamos

[3:53 p. m.] **Tú:** Pero ajá nada que ver

[3:53 p. m.] **Tú:** Si dice algo que le mando saludes a la pela esa

[3:53 p. m.] **Tú:** Que hace rato no la veo jakaakak

[3:54 p. m.] **Vale 🌙:** Jsjsj dale

[3:54 p. m.] **Tú:**
> _Vale 🌙: David mira feo asta la mamá_
No yo sé que es mirar feo

[3:54 p. m.] **Tú:** Y el no me miraba así

[3:54 p. m.] **Tú:** El mira feo con ganad

[3:54 p. m.] **Tú:** No porque la cara sea así

[3:54 p. m.] **Tú:** Dile que si de casualidad no me hablo con una tal Saray

[3:54 p. m.] **Vale 🌙:** [Mensaje de voz]

[3:54 p. m.] **Tú:** Si dice que si

[3:54 p. m.] **Tú:** Más mentira que 10

[3:54 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Ella

[3:55 p. m.] **Tú:** Que va

[3:55 p. m.] **Tú:** Serio

[3:55 p. m.] **Tú:** Peor hoy

[3:55 p. m.] **Tú:** O cuando

[3:55 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Jajajajaakkaaka

[3:55 p. m.] **Tú:** Manda foto

[3:55 p. m.] **Tú:** Jajaj

[3:56 p. m.] **Tú:** Yo por eso pregunto porque mi ex mejor amiga con la que hablo aveces se llama Maura

[3:56 p. m.] **Tú:** Maira

[3:56 p. m.] **Tú:** Tons como que ajá que pasó

[3:56 p. m.] **Tú:** Qué es la estudia que tengo en la galería

[3:56 p. m.] **Vale 🌙:** [Mensaje de voz]

[3:56 p. m.] **Tú:** [Imagen]

[3:56 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Así aparece

[3:56 p. m.] **Tú:** Tal cual

[3:56 p. m.] **Tú:** Nooo

[3:57 p. m.] **Tú:** O el que yo tengo agregado no es así

[3:57 p. m.] **Tú:** Y ella no tiene ni una publicación

[3:57 p. m.] **Tú:** La hermana la hace menos

[3:57 p. m.] **Tú:** Eso está raro

[3:57 p. m.] **Vale 🌙:** [Mensaje de voz]

[3:58 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
A la persona que te dije

[3:58 p. m.] **Tú:** Si fue él el que dijo eso

[3:58 p. m.] **Tú:** Dile que tú sabes algo de una tal saray

[3:58 p. m.] **Tú:** Ósea no hables como si habláramos

[3:58 p. m.] **Tú:** Si no que ella también es del colegio

[3:58 p. m.] **Tú:** Si no después me gano a la otra tonta

[3:59 p. m.] **Vale 🌙:** Bueno  amor

[3:59 p. m.] **Tú:** Que ando hablando de ella y no sé qué

[3:59 p. m.] **Tú:** Que solo éramos compañeros

[4:00 p. m.] **Tú:** Mmmm que le puedes decir que la diferencias porque nos íbamos juntos al colegio

[4:00 p. m.] **Tú:** Así

[4:00 p. m.] **Tú:** Y si sale con algo mas

[4:00 p. m.] **Tú:** X es mentiría

[4:00 p. m.] **Tú:** [Imagen]

[4:00 p. m.] **Tú:** Ella

[4:01 p. m.] **Tú:** Y que le mande saludes a la pela

[4:01 p. m.] **Vale 🌙:** [Mensaje de voz]

[4:01 p. m.] **Tú:** Que tengo chismes pa contarle ahh

[4:01 p. m.] **Tú:** Jajaja

[4:01 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Ahí ya cambia la historia

[4:02 p. m.] **Tú:** Vio

[4:02 p. m.] **Tú:** Que salió de por ahí

[4:02 p. m.] **Tú:** No de mi casa

[4:02 p. m.] **Vale 🌙:** [Mensaje de voz]

[4:03 p. m.] **Vale 🌙:** [Mensaje de voz]

[4:03 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Ja ojala

[4:03 p. m.] **Tú:** Esa piroa me odia pero me habla cuando necesita chillar

[4:03 p. m.] **Tú:** Aparte mi bfa

[4:04 p. m.] **Tú:** Vive en usme

[4:04 p. m.] **Tú:** Y las otras estúpidas en el pueblo

[4:04 p. m.] **Tú:** Que aleja

[4:04 p. m.] **Tú:** Y laura

[4:04 p. m.] **Tú:** Bueno más aleja

[4:04 p. m.] **Tú:** Qué es con la que más peleo

[4:04 p. m.] **Vale 🌙:** [Mensaje de voz]

[4:04 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Yo quería chisme Melo

[4:04 p. m.] **Tú:** Agg

[4:04 p. m.] **Tú:** Me dañó el almuerzo

[4:05 p. m.] **Tú:** Ahorita hablamos voy a comer

[4:05 p. m.] **Vale 🌙:**
> _Tú: Ahorita hablamos voy a comer_
Dale mi vida

[4:05 p. m.] **Vale 🌙:** Yo tambien ya le voy a dar almuerzo a mi hermana

[6:55 p. m.] **Tú:** Holii

[6:55 p. m.] **Tú:** Coo tas

[6:55 p. m.] **Tú:** Que hiciste en la tarde

[6:56 p. m.] **Vale 🌙:** Bien mi cielo lavar una ropa y comprarle la arena a la gata

[6:57 p. m.] **Tú:** Luego no la compraste  ayer

[6:57 p. m.] **Tú:** Que bueno

[6:57 p. m.] **Tú:** Y que mas

[6:57 p. m.] **Tú:** Si te dijeron algo sobre el trabajo

[6:57 p. m.] **Tú:** De tu padrastro

[7:18 p. m.] **Vale 🌙:** Mi padrastro no a llegado

[7:18 p. m.] **Vale 🌙:**
> _Tú: Y que mas_
Nada amor organizar hacer la comida

[8:06 p. m.] **Tú:**
> _Vale 🌙: Mi padrastro no a llegado_
Ahs

[8:06 p. m.] **Tú:** Igual preguntale

[8:06 p. m.] **Tú:** A ver que te dice

[8:06 p. m.] **Tú:**
> _Vale 🌙: Nada amor organizar hacer la comida_
Juiciosa

[8:06 p. m.] **Tú:** Asi  como me gusta

[8:07 p. m.] **Tú:** Y que tal el día de descanso

[8:07 p. m.] **Tú:** Mucho estrés

[8:07 p. m.] **Tú:** Hoy si puedes jugar o andas mal de señal

[8:10 p. m.] **Vale 🌙:** Bien cielo tranquilidad adsoluta

[8:11 p. m.] **Vale 🌙:** Aburrida eso sí

[8:22 p. m.] **Tú:**
> _Vale 🌙: Bien cielo tranquilidad adsoluta_
Si encontraste lo del bolso

[8:22 p. m.] **Tú:** Que se perdió

[8:22 p. m.] **Tú:**
> _Vale 🌙: Aburrida eso sí_
Jum

[8:22 p. m.] **Tú:** Y sin internet

[8:22 p. m.] **Tú:** Difícil

[8:22 p. m.] **Tú:** Pero es que no tienes

[8:22 p. m.] **Tú:** O el internet está lento

[8:22 p. m.] **Tú:** Si no pa que mires

[8:22 p. m.] **Tú:** Y te ayudo jajasj

[8:32 p. m.] **Vale 🌙:** No tengo solo tengo WhatsApp y Facebook

[8:33 p. m.] **Vale 🌙:**
> _Tú: Si encontraste lo del bolso_
Nada cielo

[8:44 p. m.] **Tú:**
> _Vale 🌙: No tengo solo tengo WhatsApp y Facebook_
Pero osea tienen el router

[8:44 p. m.] **Tú:** O no tienen Internet  internet

[8:44 p. m.] **Tú:** Osea no tienen compañia

[8:44 p. m.] **Tú:**
> _Vale 🌙: Nada cielo_
Y eso

[8:44 p. m.] **Tú:** Donde lo dejaste

[8:44 p. m.] **Tú:** Pero si fue dentro  de la casa

[8:50 p. m.] **Tú:** https://vt.tiktok.com/ZSVEDRYPa/

[8:52 p. m.] **Vale 🌙:**
> _Tú: Osea no tienen compañia_
Pues toca ir actualizar los datos a Tigo por que  cambiaron la contraseña. Los códigos los están mandando a un número que ya no existe

[8:52 p. m.] **Vale 🌙:**
> _Tú: Pero si fue dentro  de la casa_
Sii

[8:53 p. m.] **Vale 🌙:**
> _Tú: https://vt.tiktok.com/ZSVEDRYPa/_
No tengo megas recuerdas

[8:59 p. m.] **Tú:**
> _Vale 🌙: Pues toca ir actualizar los datos a Tigo por que  cambiaron la contraseña. Los códigos los están mandando a un número que ya no existe_
Del Internet

[8:59 p. m.] **Tú:** O de la cuenta que maneja eso

[9:00 p. m.] **Tú:** Porque eso lo pueden hacer por el cel

[9:00 p. m.] **Tú:** O la aplicación

[9:00 p. m.] **Tú:**
> _Vale 🌙: Pues toca ir actualizar los datos a Tigo por que  cambiaron la contraseña. Los códigos los están mandando a un número que ya no existe_
Los datos de quien pidió el servicio

[9:00 p. m.] **Tú:** Pero ya lo cancelaron

[9:00 p. m.] **Tú:** Porque si no lo usan

[9:00 p. m.] **Tú:** Y pagan que gracia tiene yporque no contratan otra mejor

[9:00 p. m.] **Tú:** Algo que si sea estable para donde viven

[9:01 p. m.] **Tú:**
> _Vale 🌙: Sii_
Jum

[9:01 p. m.] **Tú:** Mañana  ya que tienes tiempo organizar un poco más y mirar que puedes en otra

[9:01 p. m.] **Tú:** Encontrar

[9:01 p. m.] **Tú:**
> _Vale 🌙: No tengo megas recuerdas_
[Sticker]

[9:01 p. m.] **Tú:** Uno intentando ayudar

[9:02 p. m.] **Tú:** Usa tiktok lite

[9:02 p. m.] **Tú:** Creo que para eso sirve

[9:20 p. m.] **Vale 🌙:**
> _Tú: Y pagan que gracia tiene yporque no contratan otra mejor_
Estamos mirando si nos pasamos pero no se acual

[9:21 p. m.] **Vale 🌙:**
> _Tú: Creo que para eso sirve_
Tengo el tictok normal instalado

[10:47 p. m.] **Tú:**
> _Vale 🌙: Estamos mirando si nos pasamos pero no se acual_
Tocaria que  miraras que ofrece cada una

[10:47 p. m.] **Tú:** Y que beneficios

[10:47 p. m.] **Tú:** Y obvio el precio

[10:47 p. m.] **Tú:** Porque si te molesta tigo

[10:47 p. m.] **Tú:** Y no responden mija

[10:47 p. m.] **Tú:** Cambio eso de andar sin Internet cansa

[10:47 p. m.] **Tú:** Yo ando haciendo mi hoja de vida jajajaaja

[10:48 p. m.] **Tú:** La hice toda bonita pero eso no lo aceptan así jakaak

[10:50 p. m.] **Vale 🌙:** Jsjd  si ahora tienen que se mas serias y directas

[10:50 p. m.] **Tú:** [Documento]

[10:50 p. m.] **Tú:** esa me hice pero no se

[10:50 p. m.] **Tú:** aparte es mucha pagina

[10:51 p. m.] **Tú:** cansa ver tanto

[10:52 p. m.] **Vale 🌙:** Si creo que toca organizarla de forma que ocupe menos espacio y el tipo blanco y negro

[10:53 p. m.] **Vale 🌙:** Pues así lo explicaron en lo de la capacitación  como para tener mejor perfil y eso

[11:02 p. m.] **Tú:** [Documento]

[11:02 p. m.] **Tú:** asi

[11:15 p. m.] **Vale 🌙:**
> _Tú: Documento_
Esta me gusta más

[11:15 p. m.] **Tú:** Ayudame tu

[11:15 p. m.] **Tú:** A decorarla

[11:15 p. m.] **Tú:** Me dijeron que le metiera un poco de diseño pero no se

[11:16 p. m.] **Tú:** No soy fan de eso pero si funciona hacerle y me falta la foto también

[11:16 p. m.] **Tú:** https://vt.tiktok.com/ZSVEqGRwh/

[11:16 p. m.] **Vale 🌙:** [Mensaje de voz]

[11:17 p. m.] **Tú:** Ayudameee jajaajaj

[11:17 p. m.] **Tú:** Que opinas tu

[11:17 p. m.] **Tú:** Y te pago con picha a crédito

[11:17 p. m.] **Tú:** Crédicuerpo

[11:17 p. m.] **Tú:** Lo que quieras

[11:26 p. m.] **Vale 🌙:** [Imagen] Más o menos haci

[11:26 p. m.] **Vale 🌙:** [Mensaje de voz]

[11:26 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Jajajaajaj

[11:26 p. m.] **Tú:** Gracias mi vida

[11:27 p. m.] **Tú:** Pero así si vale la pena

[11:27 p. m.] **Tú:** No es como muy pequeña

[11:27 p. m.] **Vale 🌙:** [Mensaje de voz]

[11:27 p. m.] **Tú:** Osea esta lindo pero no de es como todo en uno y aveces  no se eso es lo que no me gusta de ese tipo de hojas de vida

[11:27 p. m.] **Tú:** Pero si pasa

[11:28 p. m.] **Tú:** Algo así yo se que lo reciben pero si vale la pena

[11:28 p. m.] **Tú:** Tu que dices

[11:28 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Veee

[11:28 p. m.] **Tú:** Yo mañana le mando a poner ehhh

[11:28 p. m.] **Tú:** Y si mañana llamamos a claro

[11:28 p. m.] **Tú:** Jajaan

[11:28 p. m.] **Tú:** Y preguntas

[11:28 p. m.] **Tú:** O que

[11:31 p. m.] **Vale 🌙:** Esque me toca

[11:31 p. m.] **Tú:** Ahhh pues como la señora

[11:31 p. m.] **Tú:** Le da pereza todo

[11:31 p. m.] **Tú:** Por eso digo

[11:31 p. m.] **Tú:** Pero lo de tigo

[11:31 p. m.] **Tú:** Esta cancelado ya

[11:32 p. m.] **Vale 🌙:** [Mensaje de voz]

[11:33 p. m.] **Tú:** No mija

[11:33 p. m.] **Tú:** No se entiende nada se metió bajo la cama para hablarme

[11:33 p. m.] **Tú:** O esta en el baño porque no se entiende

[11:33 p. m.] **Tú:** Pilla lo de cancelar eso es lo de menos para cancelar no hay que actualizar nada tu llegas y les dices que ya te cansaste de esperar un tecnico

[11:34 p. m.] **Tú:** Y que la excusa sea que los datos entonces  para que tienen la atención al cliente si solo se puede en sedes algo asi

[11:34 p. m.] **Tú:** Bueno también  teniendo en cuenta que el Internet sea malo

[11:34 p. m.] **Tú:** Porque si no pues decir que que puntos tienen

[11:34 p. m.] **Tú:** Para ir

[11:35 p. m.] **Tú:** Porque eso tienen que ser lugares específicos

[11:35 p. m.] **Tú:** Ahi si tu veras tienes  que tener en cuenta que esta el tv  tu hermana tu mamá tu el pc y no el novio de tu mamá y visita

[11:36 p. m.] **Tú:** 9 personas que se van a conectar prácticamente

[11:36 p. m.] **Vale 🌙:** [Documento] CamScanner 01-09-2026 23.36.pdf

[11:36 p. m.] **Tú:** Y para eso necesitas algo estable

[11:37 p. m.] **Tú:**
> _Vale 🌙: Documento: CamScanner 01-09-2026 23.36.pdf_
Ojito

[11:37 p. m.] **Tú:** Quedaron como 6 marcas de agua pero no importa

[11:37 p. m.] **Tú:** Muchas gracias bb

[11:37 p. m.] **Tú:** Que le debo

[11:37 p. m.] **Tú:** O que desea de mi

[11:38 p. m.] **Vale 🌙:**
> _Tú: Ahi si tu veras tienes  que tener en cuenta que esta el tv  tu hermana tu mamá tu el pc y no el novio de tu mamá y visita_
Solo sería el pc y celulares por que tele tica arreglarlo

[11:38 p. m.] **Tú:**
> _Vale 🌙: Solo sería el pc y celulares por que tele tica arreglarlo_
Como así

[11:38 p. m.] **Vale 🌙:**
> _Tú: Quedaron como 6 marcas de agua pero no importa_
Aregla eso a mor esque ami no me da no tengo internet si le quieers poner foto también se podría solo que no tengo fotos tuyas tipo laborales

[11:38 p. m.] **Tú:** Ahora que paso

[11:39 p. m.] **Tú:** A lo que me refiero es que este o no este tiene que a ver buena conexión

[11:39 p. m.] **Vale 🌙:** Mi hermana se tiró los televisores

[11:39 p. m.] **Tú:**
> _Vale 🌙: Mi hermana se tiró los televisores_
No mija en  un orfanato yo creo que la aceptan

[11:39 p. m.] **Vale 🌙:**
> _Tú: A lo que me refiero es que este o no este tiene que a ver buena conexión_
Si por eso yo estoy pensando pasar el inter esa para claro o para Movistar

[11:39 p. m.] **Tú:** Si les tiras la liga si

[11:40 p. m.] **Vale 🌙:**
> _Tú: No mija en  un orfanato yo creo que la aceptan_
Jsjsjs deje a mi pulga yo sé que es desastrosa pero la amo

[11:40 p. m.] **Tú:**
> _Vale 🌙: Jsjsjs deje a mi pulga yo sé que es desastrosa pero la amo_
Nombd

[11:41 p. m.] **Tú:** Alla le va mejor

[11:41 p. m.] **Tú:**
> _Vale 🌙: Si por eso yo estoy pensando pasar el inter esa para claro o para Movistar_
Movistar no se

[11:41 p. m.] **Tú:** Dicen que es bueno por la fibra pero el rendimiento  pesimo

[11:41 p. m.] **Vale 🌙:** Sjsjsj ya que eso se podía de bb ya me encariñe

[11:41 p. m.] **Tú:** Horrible tons tocaría probar

[11:41 p. m.] **Tú:** Porque para cancelar un contrato de esos

[11:41 p. m.] **Tú:** Jum

[11:41 p. m.] **Tú:**
> _Vale 🌙: Sjsjsj ya que eso se podía de bb ya me encariñe_
Ombe

[11:41 p. m.] **Tú:** En 1 mes

[11:42 p. m.] **Tú:** No te acordaras del nombrd

[11:42 p. m.] **Tú:** Pero si de todo lo que vas a comprar y ahorrar después  de ella

[11:42 p. m.] **Vale 🌙:**
> _Tú: No te acordaras del nombrd_
Nojoda osea yo se que aveses no tengo corazón pero es mi hermana no cualquier hp mk

[11:43 p. m.] **Tú:**
> _Vale 🌙: Nojoda osea yo se que aveses no tengo corazón pero es mi hermana no cualquier hp mk_
Es joda ombe

[11:43 p. m.] **Tú:** Calma

[11:44 p. m.] **Tú:** No sabe el humor negro

[11:44 p. m.] **Tú:** Eh

[11:44 p. m.] **Tú:** Y que le hizo al tv luego

[11:44 p. m.] **Tú:** Ahorita un martillaso

[11:44 p. m.] **Vale 🌙:** Jsjsjs yo sé cielo

[11:44 p. m.] **Tú:** Jajsjssj

[11:44 p. m.] **Tú:**
> _Vale 🌙: Jsjsjs yo sé cielo_
Tonces  sigo

[11:44 p. m.] **Vale 🌙:**
> _Tú: Y que le hizo al tv luego_
Uno se calló y no prendió más

[11:44 p. m.] **Tú:** En la banca vendiendo dulces pa que aprenda

[11:44 p. m.] **Tú:** Y compre otro tv

[11:44 p. m.] **Tú:**
> _Vale 🌙: Uno se calló y no prendió más_
No mija nada

[11:44 p. m.] **Tú:** Pa la basura

[11:45 p. m.] **Tú:** Sale más caro el arreglo que el tv

[11:45 p. m.] **Vale 🌙:** Y se le desprendía la pantalla como de la base medio lo pegaron pero aja

[11:45 p. m.] **Tú:** O vender a la pela

[11:45 p. m.] **Tú:** Yo conozco unos amigos que pagan bueno

[11:45 p. m.] **Tú:** Tu me dirás el riñon

[11:45 p. m.] **Tú:** Y sale

[11:45 p. m.] **Tú:** 10% pa mi el resto pa utds

[11:45 p. m.] **Vale 🌙:** Sjjsjsjs

[11:45 p. m.] **Vale 🌙:** [Sticker]

[11:45 p. m.] **Tú:**
> _Vale 🌙: Y se le desprendía la pantalla como de la base medio lo pegaron pero aja_
[Sticker]

[11:46 p. m.] **Vale 🌙:**
> _Tú: Sticker_
[Sticker]

[11:46 p. m.] **Vale 🌙:** Como si tu fueras blanco

[11:46 p. m.] **Tú:**
> _Vale 🌙: Como si tu fueras blanco_
Más que ella si

[11:46 p. m.] **Tú:** Tengo más estatus

[11:46 p. m.] **Tú:**
> _Vale 🌙: Sticker_
[Sticker]

[11:47 p. m.] **Vale 🌙:**
> _Tú: Tengo más estatus_
[Sticker]

[11:47 p. m.] **Vale 🌙:**
> _Tú: Sticker_
[Sticker]

[11:47 p. m.] **Tú:**
> _Vale 🌙: Sticker_
[Sticker]

[11:47 p. m.] **Tú:** Porque no vienes y me la chapas mejor

[11:47 p. m.] **Tú:** Pero solo era 1

[11:48 p. m.] **Tú:** Y que monda estaba haciendo para tumbar el tv

[11:48 p. m.] **Vale 🌙:** Nosé ya no me acuerdo me toca pregúntale a mi mamá

[11:48 p. m.] **Tú:**
> _Vale 🌙: Nosé ya no me acuerdo me toca pregúntale a mi mamá_
Deja así que la vende después

[11:48 p. m.] **Vale 🌙:** Ella hizo eso antes de que me viniera

[11:50 p. m.] **Tú:**
> _Vale 🌙: Ella hizo eso antes de que me viniera_
Jajaja aprovecho a pa ver si llevabas uno

[11:50 p. m.] **Tú:** Ombe no lo llevaste

---

## 2 de septiembre de 2026

[12:01 a. m.] **Vale 🌙:** Jsjs

[12:01 a. m.] **Vale 🌙:** Descansa amor estoy más dormida que despierta ya

[12:01 a. m.] **Tú:** Nahh

[12:02 a. m.] **Tú:** Ya estaba negociando a la mocosa

[12:02 a. m.] **Tú:** Bueno descansa  besos en esa cuca

[12:02 a. m.] **Tú:** Mañana  llamas para ya sabes que

[12:02 a. m.] **Tú:** A ver cual te sirve más

[12:02 a. m.] **Tú:** [Sticker]

[6:00 a. m.] **Vale 🌙:** Wuenos días amor

[10:06 a. m.] **Tú:** Holii

[10:07 a. m.] **Tú:** Buenos dias como amaneciste mi vida

[10:07 a. m.] **Tú:** Ya llamaste

[10:07 a. m.] **Tú:** [Sticker]

[10:08 a. m.] **Vale 🌙:** Buen mi vida

[10:29 a. m.] **Vale 🌙:** [Video]

[10:29 a. m.] **Vale 🌙:** Esperando a mi hermana

[10:35 a. m.] **Tú:**
> _Vale 🌙: Video_
Jajajaajesa ponla

[10:35 a. m.] **Tú:** Pinta

[10:35 a. m.] **Tú:** Y ya fuiste a tigo

[10:35 a. m.] **Tú:** Ombe

[10:35 a. m.] **Tú:** Toca que vayas deja la pereza

[10:36 a. m.] **Tú:** Que salga tu hermana  y vas en un momento

[10:36 a. m.] **Tú:**
> _Vale 🌙: Esperando a mi hermana_
Avisas cuando llegues

[10:36 a. m.] **Vale 🌙:** [Mensaje de voz]

[10:36 a. m.] **Tú:** Yo voy por unos medicamentos  de mi mamá

[10:36 a. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Si saca excusa

[10:36 a. m.] **Tú:** Y por ahí cerca no hay un punto

[10:36 a. m.] **Tú:** Imposible

[10:36 a. m.] **Vale 🌙:**
> _Tú: Y por ahí cerca no hay un punto_
Noo

[10:37 a. m.] **Tú:**
> _Vale 🌙: Noo_
Noo mija

[10:37 a. m.] **Tú:** Toca que llegues

[10:37 a. m.] **Tú:** A buscar eso

[10:37 a. m.] **Vale 🌙:** Quedan en fábricato y en el parque principal de bello

[10:39 a. m.] **Tú:** No idea

[10:39 a. m.] **Tú:** Pero comieron la más lejana

[10:39 a. m.] **Tú:** Ni modo

[10:39 a. m.] **Tú:** Mija a organizar la casa

[10:39 a. m.] **Tú:** Hasta encontrar eso

[10:59 a. m.] **Vale 🌙:** Si ya se 😭

[2:33 p. m.] **Tú:** Como vas

[2:33 p. m.] **Tú:** Encontraste algo

[2:49 p. m.] **Vale 🌙:** Nada

[2:49 p. m.] **Vale 🌙:** Mi mamá ahora que venga me ayuda alzar la cama

[3:00 p. m.] **Tú:**
> _Vale 🌙: Mi mamá ahora que venga me ayuda alzar la cama_
Y eso

[3:00 p. m.] **Tú:** Luego  donde dejaste es0

[3:00 p. m.] **Tú:** O lo perdiste

[3:00 p. m.] **Vale 🌙:** En la cama

[3:01 p. m.] **Vale 🌙:** [Mensaje de voz]

[3:01 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Foto

[3:01 p. m.] **Tú:** O video

[3:02 p. m.] **Tú:** De las tetas

[3:02 p. m.] **Tú:** Digo de lo que quieres explicar

[3:02 p. m.] **Vale 🌙:** Jsjjs

[3:23 p. m.] **Tú:** Me que esperando la explicación

[3:23 p. m.] **Tú:** En video

[3:23 p. m.] **Tú:** Aja

[3:23 p. m.] **Tú:** Pero que hiciste hoy

[3:25 p. m.] **Vale 🌙:** [Mensaje de voz]

[3:25 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Y

[3:25 p. m.] **Tú:** Mande eso

[3:25 p. m.] **Tú:** Ni que nunca hubiera visto sus desastres

[3:26 p. m.] **Vale 🌙:** [Mensaje de voz]

[3:28 p. m.] **Tú:** Khe

[3:28 p. m.] **Tú:** Eso es que no me quieres mostrar

[3:29 p. m.] **Tú:** Me toca conformarme con la casa porque  ya fotos de ella no manda

[3:33 p. m.] **Vale 🌙:** _Esperando el mensaje… Esto puede demorar un poco._

[3:33 p. m.] **Tú:**
> _Vale 🌙: Video_
Nombe

[3:34 p. m.] **Tú:** Como así que para ver una vez

[3:34 p. m.] **Tú:** Yo que no soy marido tuyo o qie

[3:34 p. m.] **Tú:** Pero dame 10 voy al baño

[3:34 p. m.] **Tú:** Y ya te respondo

[3:34 p. m.] **Tú:** Que medio por hacer algo importante

[3:34 p. m.] **Tú:** Ya vuelvo

[3:34 p. m.] **Vale 🌙:** Oki

[3:34 p. m.] **Tú:**
> _Vale 🌙: Video_
[Sticker]

[3:35 p. m.] **Tú:** Necetas que te muestre o me esperas

[3:35 p. m.] **Tú:** [Sticker]

[3:36 p. m.] **Vale 🌙:** Yo te esperó

[3:37 p. m.] **Tú:**
> _Vale 🌙: Yo te esperó_
Ya se me fueron las ganas

[3:38 p. m.] **Tú:** Pero y la parte que me ibas a mostrar mañosa

[3:45 p. m.] **Tú:** [Imagen]

[3:45 p. m.] **Tú:** Ese pa cuando tengas tiempo pa jugar un ratico

[3:51 p. m.] **Tú:**
> _Vale 🌙: Video_
Erda uno con ganas de volearle picha a esa niña y con las que sale

[3:52 p. m.] **Tú:** Cuando vengas

[3:52 p. m.] **Tú:** No vayas a decir nada

[3:52 p. m.] **Tú:** No quiero ni una queja tuya

[3:52 p. m.] **Tú:** De porque pasó lo que que pasó

[3:55 p. m.] **Tú:** Ahora te aguantas

[3:55 p. m.] **Tú:** Si mando un video tirando paja

[3:56 p. m.] **Tú:** [Sticker]

[3:58 p. m.] **Vale 🌙:**
> _Tú: Si mando un video tirando paja_
Jsjsj amor

[3:58 p. m.] **Vale 🌙:**
> _Tú: Ese pa cuando tengas tiempo pa jugar un ratico_
Dale cielo

[4:07 p. m.] **Tú:**
> _Vale 🌙: Jsjsj amor_
Y me dejaste el huevo bien mojoso

[4:07 p. m.] **Tú:** Quieres ver

[4:09 p. m.] **Tú:** Que andas haciendo

[4:10 p. m.] **Tú:** Así sea pa llamarte

[4:10 p. m.] **Vale 🌙:** Mi hermana por fin celevanto le voy a dar comida

[4:11 p. m.] **Tú:**
> _Vale 🌙: Mi hermana por fin celevanto le voy a dar comida_
Estabas acostada

[4:11 p. m.] **Tú:** Jajajaj

[4:11 p. m.] **Tú:** Ta bien me avisas cuando termines

[4:14 p. m.] **Vale 🌙:**
> _Tú: Estabas acostada_
Si estamos durmiendo un poquito

[4:15 p. m.] **Tú:**
> _Vale 🌙: Si estamos durmiendo un poquito_
Y tu hermana en qué curso esta

[4:15 p. m.] **Tú:**
> _Vale 🌙: Si estamos durmiendo un poquito_
No hagan mas

[4:15 p. m.] **Tú:** Jum

[4:15 p. m.] **Tú:** Ahorita me toca hacer el almuerzo

[4:16 p. m.] **Tú:** [Sticker]

[4:17 p. m.] **Vale 🌙:**
> _Tú: Y tu hermana en qué curso esta_
Cuarto

[4:17 p. m.] **Vale 🌙:** Fritar una carne y ya

[4:18 p. m.] **Vale 🌙:** El arroz lo hice esta mañana

[4:32 p. m.] **Tú:** _Esperando el mensaje… Esto puede demorar un poco._

[4:32 p. m.] **Tú:** Mija le tocó ver eso en otro lado

[4:34 p. m.] **Tú:** _Esperando el mensaje… Esto puede demorar un poco._

[4:37 p. m.] **Tú:** Me iré hacer la comida

[4:59 p. m.] **Vale 🌙:**
> _Tú: Video_
[Sticker]

[4:59 p. m.] **Vale 🌙:**
> _Tú: Video_
[Sticker]

[4:59 p. m.] **Vale 🌙:** [Sticker]

[4:59 p. m.] **Vale 🌙:** Que rico y que lindo estás mi amor

[5:58 p. m.] **Tú:** Joa

[5:58 p. m.] **Tú:** Tú me salaste el pene verdad

[5:59 p. m.] **Tú:** Cule mala suerte apenas salí

[5:59 p. m.] **Tú:** JajaK

[5:59 p. m.] **Vale 🌙:**
> _Tú: Tú me salaste el pene verdad_
Jsjdjd eso no se puede

[6:06 p. m.] **Tú:**
> _Vale 🌙: Jsjdjd eso no se puede_
Noo y lo que me acaba de pasar que

[6:06 p. m.] **Tú:** Jum

[6:06 p. m.] **Tú:** Siga haciendo sus merjurges raros

[6:06 p. m.] **Vale 🌙:** Cuéntame

[6:08 p. m.] **Tú:** Al rato

[6:08 p. m.] **Tú:** Me voy a poner hacer la comida

[6:08 p. m.] **Tú:** Ya te muestro la picha

[6:09 p. m.] **Tú:** [Sticker]

[6:09 p. m.] **Vale 🌙:**
> _Tú: Ya te muestro la picha_
Jsjdhs

[6:09 p. m.] **Vale 🌙:**
> _Tú: Me voy a poner hacer la comida_
Vale mi amor

[6:26 p. m.] **Tú:** Vente

[6:26 p. m.] **Tú:** Tengo ganas de comerte ya

[6:26 p. m.] **Tú:** Toca que ayudes a bajar la calentura

[6:27 p. m.] **Tú:** https://open.spotify.com/socialsession/2ZBpgcuQiIIMp9jhrwwN8S?si=Bf3fqgDoRL-mKhh2ymSHTQ&utm_source=whatsapp

[6:27 p. m.] **Tú:** Vamos a escuchar musiquita

[6:27 p. m.] **Tú:** Juntos

[6:34 p. m.] **Vale 🌙:** Amorr no internet

[6:45 p. m.] **Tú:** [Mensaje de voz]

[6:46 p. m.] **Vale 🌙:**
> _Tú: Mensaje de voz_
Te amo

[6:48 p. m.] **Vale 🌙:** Yo estoy escuchando morat

[7:59 p. m.] **Tú:** Y utd

[7:59 p. m.] **Tú:** Que señorita

[7:59 p. m.] **Tú:** A qué juega

[7:59 p. m.] **Tú:** Que quito la ubicación del ig

[7:59 p. m.] **Tú:** 🧐

[8:00 p. m.] **Vale 🌙:** Si no tengo ig por que no tengo internet

[8:00 p. m.] **Tú:** Pero la quito

[8:00 p. m.] **Vale 🌙:** No

[8:00 p. m.] **Tú:** 🫥

[8:00 p. m.] **Tú:** Si

[8:00 p. m.] **Tú:** [Imagen]

[8:00 p. m.] **Tú:** Por hay anda

[8:01 p. m.] **Tú:** Donde está Valentina maria

[8:01 p. m.] **Tú:** De todos lo ángeles

[8:01 p. m.] **Vale 🌙:** Pues donde e estado todo el día en mi casa

[8:01 p. m.] **Tú:** [Sticker]

[8:01 p. m.] **Tú:**
> _Vale 🌙: Pues donde e estado todo el día en mi casa_
Ahí no dice eso

[8:01 p. m.] **Tú:** [Sticker]

[8:01 p. m.] **Tú:** Foto en su cama

[8:01 p. m.] **Tú:** Ya

[8:01 p. m.] **Vale 🌙:** [Mensaje de voz]

[8:01 p. m.] **Tú:** 🫦

[8:02 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Mmmm

[8:02 p. m.] **Tú:** Sospechoso

[8:02 p. m.] **Vale 🌙:** [Mensaje de video]

[8:02 p. m.] **Tú:**
> _Vale 🌙: Mensaje de video_
Que dijo carboncito

[8:03 p. m.] **Tú:**
> _Vale 🌙: Mensaje de video_
Ta bien por hoy se la perdono

[8:03 p. m.] **Vale 🌙:** Jsjsj que se le encalambro  pie

[8:03 p. m.] **Tú:** Jajaj

[8:03 p. m.] **Tú:** Que andas haciendo

[8:03 p. m.] **Tú:**
> _Vale 🌙: Jsjsj que se troncho el pie_
Como monda

[8:03 p. m.] **Tú:** Si está en la cama

[8:03 p. m.] **Tú:**
> _Vale 🌙: Mensaje de video_
Que andas haciendo y el bolso

[8:03 p. m.] **Tú:** Señorita

[8:03 p. m.] **Tú:** Ya lo encontró

[8:03 p. m.] **Tú:** [Imagen]

[8:03 p. m.] **Tú:** Apenas termine eso

[8:03 p. m.] **Tú:** Jajaja

[8:03 p. m.] **Vale 🌙:** No

[8:03 p. m.] **Tú:** Creo que está como seco le falta aguita

[8:04 p. m.] **Tú:**
> _Vale 🌙: No_
Y eso

[8:04 p. m.] **Vale 🌙:** Estoy asiendo lentejas

[8:04 p. m.] **Tú:**
> _Vale 🌙: Estoy asiendo lentejas_
A vers

[8:04 p. m.] **Tú:** Esas tetas

[8:04 p. m.] **Tú:** Digo. Esa carita

[8:04 p. m.] **Tú:** Digo la comida mia

[8:04 p. m.] **Tú:** Ósea utd mi amor

[8:05 p. m.] **Vale 🌙:**
> _Tú: A vers_
Están pitando

[8:06 p. m.] **Tú:**
> _Vale 🌙: Están pitando_
Esas excusas

[8:06 p. m.] **Tú:** Com y como así que están

[8:06 p. m.] **Tú:** Luego quien más está allá

[8:06 p. m.] **Tú:** [Sticker]

[8:06 p. m.] **Tú:** Quién sabe con quién anda

[8:06 p. m.] **Tú:** Que no es capaz de mandar un video en el apartamento

[8:06 p. m.] **Tú:** [Sticker]

[8:07 p. m.] **Vale 🌙:**
> _Tú: Esas excusas_
[Mensaje de voz]

[8:07 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Le entendí

[8:07 p. m.] **Tú:** Pintando

[8:07 p. m.] **Tú:** Jajajaajaj

[8:07 p. m.] **Tú:** Y

[8:07 p. m.] **Tú:** Que pasa que estén pitando

[8:07 p. m.] **Tú:** Mírate a ver

[8:07 p. m.] **Tú:** Ese desorde

[8:08 p. m.] **Tú:** Yo quiero ver donde me voy a quedar

[8:08 p. m.] **Vale 🌙:** [Video]

[8:08 p. m.] **Tú:**
> _Vale 🌙: Video_
Que le dio a esa pela

[8:08 p. m.] **Tú:** Pilas que como que la cogio la corriente

[8:09 p. m.] **Tú:**
> _Vale 🌙: Video_
Que cuente el chisme

[8:09 p. m.] **Tú:** Bien

[8:09 p. m.] **Vale 🌙:** [Mensaje de voz]

[8:12 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Se pone un que

[8:12 p. m.] **Tú:** Najajakaak

[8:13 p. m.] **Tú:** Yo si iba a decir

[8:13 p. m.] **Tú:** Si me está pelando a mi

[8:13 p. m.] **Tú:** Damalas me tendrá que querer

[8:13 p. m.] **Tú:** Si no lo le mando nada

[8:13 p. m.] **Tú:** Después tiris

[8:13 p. m.] **Tú:** [Video]

[8:14 p. m.] **Tú:** [Imagen]

[8:14 p. m.] **Tú:** Has una foto de nosotros

[8:14 p. m.] **Tú:** Para ponerla ahí

[8:14 p. m.] **Tú:** Luchando

[8:14 p. m.] **Tú:** Pichando porfa

[8:14 p. m.] **Tú:** Bien rico

[8:15 p. m.] **Tú:** Para cuando jugue me acuerde de vos así bien rico

[8:21 p. m.] **Vale 🌙:**
> _Tú: Pichando porfa_
Noo

[8:22 p. m.] **Tú:**
> _Vale 🌙: Noo_
[Sticker]

[8:23 p. m.] **Vale 🌙:** Hazla tu yo no voy a ensuciar mis inteligencias artificiales  con sex

[8:23 p. m.] **Tú:**
> _Vale 🌙: Hazla tu yo no voy a ensuciar mis inteligencias artificiales  con sex_
Yo tampoco

[8:23 p. m.] **Tú:** Jum

[8:23 p. m.] **Tú:** Jajajaajaj

[8:23 p. m.] **Tú:** Tons has una bonita para ponerla ahí v

[8:23 p. m.] **Tú:** En 4

[8:23 p. m.] **Tú:** Tiris

[8:23 p. m.] **Tú:** Unas buen buena

[8:23 p. m.] **Vale 🌙:** Jsjshs

[8:24 p. m.] **Tú:** Puedo poner una de nosotros dos pinchando

[8:24 p. m.] **Vale 🌙:** Toca el lunes que ya cambié el internet

[8:24 p. m.] **Tú:** Para cuando la gente venga a jugar miren nuestro amor

[8:24 p. m.] **Tú:**
> _Vale 🌙: Toca el lunes que ya cambié el internet_
Ta bien

[8:24 p. m.] **Vale 🌙:** No gas andres

[8:24 p. m.] **Tú:**
> _Vale 🌙: Toca el lunes que ya cambié el internet_
Y eso que miraste

[8:25 p. m.] **Tú:** Sigues con tigo

[8:25 p. m.] **Tú:** O que averiguaste

[8:25 p. m.] **Tú:**
> _Vale 🌙: No gas andres_
Como que Andrés carechimba

[8:25 p. m.] **Tú:** Utd está con alguien más cierto

[8:25 p. m.] **Tú:** [Sticker]

[8:25 p. m.] **Vale 🌙:** Hp vida  amor dios mío

[8:25 p. m.] **Vale 🌙:**
> _Tú: Utd está con alguien más cierto_
Con mi hermana

[8:25 p. m.] **Tú:** https://open.spotify.com/track/3AIVCSqTfDX9NxStqhi80S?si=kQZPpOHNRkuF7C82mDBZUQ&utm_source=whatsapp&pi=XZhLUzVEQ6a1r

[8:26 p. m.] **Tú:**
> _Vale 🌙: Hp vida  amor dios mío_
Ajá

[8:26 p. m.] **Tú:** Hágase utd quiere que yo me vaya para allá

[8:26 p. m.] **Vale 🌙:**
> _Tú: Sigues con tigo_
Mi mamá dice que pase para claro

[8:26 p. m.] **Tú:** A vigilarla cierto

[8:26 p. m.] **Tú:**
> _Vale 🌙: Mi mamá dice que pase para claro_
Te pasaste a claro

[8:26 p. m.] **Tú:** Y qué tal los precios

[8:27 p. m.] **Vale 🌙:** Caro pero sirve por lo menos o eso me an dicho

[8:27 p. m.] **Vale 🌙:**
> _Tú: A vigilarla cierto_
Si tu quieres  total no estoy asiendo nada malo

[8:27 p. m.] **Tú:**
> _Vale 🌙: Caro pero sirve por lo menos o eso me an dicho_
Esperar a ver cómo sale

[8:28 p. m.] **Tú:**
> _Vale 🌙: Si tu quieres  total no estoy asiendo nada malo_
Ya que no tienes chamba

[8:28 p. m.] **Tú:** Cuando regresas

[8:28 p. m.] **Tú:** Ya ando como con ganas de hacerle el sin respeto

[8:28 p. m.] **Tú:** Y como no colaboras con la causa

[8:29 p. m.] **Tú:** Tocó con el video que tengo metiéndole un dedo y haciéndole cosquillas en la boca

[8:29 p. m.] **Tú:** Jajaja

[8:29 p. m.] **Vale 🌙:** Me voy a quedar acá igual pasajes tampoco tengo

[8:29 p. m.] **Vale 🌙:**
> _Tú: Tocó con el video que tengo metiéndole un dedo y haciéndole cosquillas en la boca_
Jsjjsjs

[8:29 p. m.] **Tú:**
> _Vale 🌙: Me voy a quedar acá igual pasajes tampoco tengo_
Utd ya no me quiere verdad

[8:29 p. m.] **Tú:** Dígame si ya no me quiere

[8:29 p. m.] **Tú:** [Sticker]

[8:29 p. m.] **Vale 🌙:** [Sticker]

[8:30 p. m.] **Vale 🌙:** Deje esos enojos que le va a dar un paro dios mio

[8:30 p. m.] **Tú:** https://vt.tiktok.com/ZSqJ1evNe/

[8:30 p. m.] **Vale 🌙:** Yo a usted lo amoo

[8:30 p. m.] **Tú:**
> _Vale 🌙: Deje esos enojos que le va a dar un paro dios mio_
Deme cariño

[8:30 p. m.] **Tú:** Que yo no le pido nada más

[8:30 p. m.] **Tú:** Creo que eso no dice

[8:30 p. m.] **Tú:** Najask

[8:30 p. m.] **Tú:**
> _Vale 🌙: Yo a usted lo amoo_
No parece

[8:31 p. m.] **Tú:** Porque ya no me manda fotos de lo que hace

[8:31 p. m.] **Tú:** Ni que hace

[8:31 p. m.] **Tú:** Apenas se levantaba me mandaba una foto

[8:31 p. m.] **Tú:** Cuando se bañaba

[8:31 p. m.] **Tú:** Cuando hacía oficio

[8:31 p. m.] **Tú:** Ya no

[8:31 p. m.] **Tú:** [Sticker]

[8:31 p. m.] **Vale 🌙:** Todo el hp día areglo la casa ago almuerzo como vuelvo a organizar espero a que llegue mi mama

[8:32 p. m.] **Tú:**
> _Vale 🌙: Todo el hp día areglo la casa ago almuerzo como vuelvo a organizar espero a que llegue mi mama_
Y que pasa en ese tiempo

[8:32 p. m.] **Vale 🌙:** Por que aveses me da pereza

[8:32 p. m.] **Tú:** Puede mandar como unas 60 fotos

[8:33 p. m.] **Vale 🌙:**
> _Tú: Puede mandar como unas 60 fotos_
No luego me toca borrar fotos de la galería  ya que no tengo espacio

[8:34 p. m.] **Tú:** Todas son iguales le mente el clitoris a uno y lo dejan, y salen con una excusa nueva

[8:34 p. m.] **Tú:**
> _Vale 🌙: No luego me toca borrar fotos de la galería  ya que no tengo espacio_
[Sticker]

[8:38 p. m.] **Vale 🌙:** [Imagen]

[8:38 p. m.] **Tú:**
> _Vale 🌙: Imagen_
Hp por fin

[8:38 p. m.] **Tú:** Cuánto le debo por la foto

[8:38 p. m.] **Tú:** Yo pago lo que sea por utd mi amor

[8:38 p. m.] **Tú:** Menos un peluche

[8:38 p. m.] **Tú:** Ya me di cuenta que no le gustaba

[8:38 p. m.] **Tú:** Jsjsjsj

[8:40 p. m.] **Vale 🌙:**
> _Tú: Ya me di cuenta que no le gustaba_
[Sticker]

[8:40 p. m.] **Vale 🌙:** [Sticker]

[8:41 p. m.] **Tú:**
> _Vale 🌙: Sticker_
[Sticker]

[8:41 p. m.] **Tú:** [Sticker]

[8:44 p. m.] **Vale 🌙:** [Sticker]

[8:44 p. m.] **Tú:** https://open.spotify.com/track/3w1h7uNU1Dfk2tOaHiIGat?si=MNkq3EYUSdKkQhnqMmnIGQ&utm_source=whatsapp&pi=-nmhbe-kTN614

[8:44 p. m.] **Tú:**
> _Vale 🌙: Sticker_
Voy hacer uno bonito

[8:44 p. m.] **Tú:** Pere

[8:45 p. m.] **Tú:** Y no le ha escrito a mi mamá cierto

[8:45 p. m.] **Tú:** [Sticker]

[8:46 p. m.] **Vale 🌙:** Hay amor siempre que puedas saludarla ami simpre se me olvida

[9:38 p. m.] **Tú:**
> _Vale 🌙: Imagen: Amee_
????

[9:39 p. m.] **Tú:**
> _Vale 🌙: Hay amor siempre que puedas saludarla ami simpre se me olvida_
Que que está haciendo

[9:39 p. m.] **Tú:** Toca que le escriba porque también

[9:39 p. m.] **Tú:** Yo de intermendiarion

[9:39 p. m.] **Vale 🌙:** [Mensaje de video]

[9:39 p. m.] **Vale 🌙:** Nada estoy leyendo

[9:39 p. m.] **Tú:** Si no le quieres escribir no le escribas

[9:39 p. m.] **Tú:** Jsjsjssk

[9:39 p. m.] **Tú:**
> _Vale 🌙: Nada estoy leyendo_
Ojito

[9:40 p. m.] **Vale 🌙:**
> _Tú: Si no le quieres escribir no le escribas_
Mañana le escribo temprano para que no se me olvidé

[9:40 p. m.] **Tú:**
> _Vale 🌙: Mañana le escribo temprano para que no se me olvidé_
Jum

[9:40 p. m.] **Vale 🌙:**
> _Tú: ????_
Nada solo me gustó mucho ese

[9:40 p. m.] **Tú:** Eso lleva diciendo desde que se fue

[9:40 p. m.] **Tú:**
> _Vale 🌙: Nada solo me gustó mucho ese_
Ahhh jajajajaja

[9:40 p. m.] **Vale 🌙:**
> _Tú: Eso lleva diciendo desde que se fue_
Perdón vida

[9:40 p. m.] **Tú:** Como no sabía que tenías libros allá

[9:40 p. m.] **Tú:** Si está como desgastado

[9:40 p. m.] **Tú:** Hace cuanto lo tienes

[9:41 p. m.] **Tú:** Que mas

[9:41 p. m.] **Tú:** Cómo te fue con ese almuerzo para mañana

[9:41 p. m.] **Vale 🌙:** Ese me lo regalo una  de las jefas de mamá

[9:41 p. m.] **Tú:**
> _Vale 🌙: Ese me lo regalo una  de las jefas de mamá_
Ahh ta bello

[9:41 p. m.] **Vale 🌙:**
> _Vale 🌙: Ese me lo regalo una  de las jefas de mamá_
Y mi hermana me lo dio hoy

[9:42 p. m.] **Tú:** Ya dejo dejó de gritar tu hermana

[9:42 p. m.] **Vale 🌙:**
> _Tú: Ya dejo dejó de gritar tu hermana_
Jsjsj si

[9:42 p. m.] **Vale 🌙:** Aveses nos enojamos pero así nos queremos

[9:44 p. m.] **Tú:** Pero no entendí

[9:44 p. m.] **Tú:** Lo de los gritos

[9:44 p. m.] **Tú:** Estaban peleando

[9:44 p. m.] **Tú:** Y ezl

[9:45 p. m.] **Tú:** Perate que me estaba cambiando

[9:45 p. m.] **Tú:** Y se me salió el pene

[9:45 p. m.] **Tú:** [Sticker]

[9:45 p. m.] **Tú:** [Sticker]

[9:49 p. m.] **Vale 🌙:**
> _Tú: Estaban peleando_
Si aveses peleamos

[9:49 p. m.] **Tú:** Pero porque estaba gritando

[9:49 p. m.] **Tú:** Jajaja

[9:50 p. m.] **Vale 🌙:** [Mensaje de voz]

[9:51 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Jajaja

[9:51 p. m.] **Tú:** Que están haciendo ahora

[9:51 p. m.] **Tú:** Porque tu duermes con ella no

[9:53 p. m.] **Vale 🌙:** [Mensaje de voz]

[9:57 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Ah que jucio

[9:58 p. m.] **Tú:** Luego no había televisor

[9:58 p. m.] **Tú:** Es que no entiendo eso me desespera

[9:58 p. m.] **Tú:** Mande a ver como se ve la casa

[9:58 p. m.] **Tú:** Haceme un toxi tour

[10:00 p. m.] **Vale 🌙:**
> _Tú: Es que no entiendo eso me desespera_
[Mensaje de voz]

[10:00 p. m.] **Vale 🌙:** [Mensaje de voz]

[10:00 p. m.] **Vale 🌙:** [Imagen]

[10:01 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Ahh pero si prende

[10:01 p. m.] **Tú:** Ahh no

[10:01 p. m.] **Tú:** Ah

[10:01 p. m.] **Tú:** Mañana muestras bien eso pa mirar

[10:01 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Ahhh

[10:01 p. m.] **Tú:** Bajajasj

[10:01 p. m.] **Tú:** Severo espejo

[10:01 p. m.] **Tú:**
> _Vale 🌙: Imagen_
Y el resto de la casa que

[10:01 p. m.] **Vale 🌙:** Obio jsjshs

[10:01 p. m.] **Tú:** Y no me mandó una foto suya

[10:01 p. m.] **Vale 🌙:** [Mensaje de voz]

[10:02 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Una foto leyendo

[10:02 p. m.] **Tú:** A ver hágase la interesante

[10:02 p. m.] **Vale 🌙:** [Imagen]

[10:02 p. m.] **Tú:** Y muestras una tetica ahí de chill

[10:02 p. m.] **Tú:** Bien tic

[10:02 p. m.] **Tú:** Rico

[10:03 p. m.] **Tú:**
> _Vale 🌙: Imagen_
Esa mamasota

[10:03 p. m.] **Tú:** A ver y sé que trata el libro

[10:03 p. m.] **Tú:** Dialoguemos vos y yo

[10:03 p. m.] **Tú:** Uff

[10:03 p. m.] **Tú:** Le tengo una escena

[10:03 p. m.] **Vale 🌙:** Son poemas

[10:04 p. m.] **Tú:** Vos lees y lo te acabó esa boca de abajo mientras me vas leyendo sin parar

[10:04 p. m.] **Tú:** Uhs

[10:04 p. m.] **Tú:** Y si gime hacemos cambio

[10:04 p. m.] **Tú:** Najakakaks

[10:04 p. m.] **Vale 🌙:** [Mensaje de voz]

[10:04 p. m.] **Tú:**
> _Vale 🌙: Son poemas_
A ver

[10:04 p. m.] **Tú:** No le ganan a mi único libro que me queda

[10:04 p. m.] **Tú:** A ver competencia de poemas

[10:04 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Pues los poemas son chiquitos

[10:04 p. m.] **Vale 🌙:**
> _Tú: Vos lees y lo te acabó esa boca de abajo mientras me vas leyendo sin parar_
Una de mis fantasías si quiero

[10:05 p. m.] **Tú:** Porque si son largos ya tienen otro nombre

[10:05 p. m.] **Tú:** Algo así

[10:05 p. m.] **Vale 🌙:** [Imagen]

[10:05 p. m.] **Tú:**
> _Vale 🌙: Imagen_
Uyyyy

[10:05 p. m.] **Vale 🌙:** [Mensaje de voz]

[10:05 p. m.] **Tú:** A ver ahora sin ese chor

[10:05 p. m.] **Tú:**
> _Vale 🌙: Imagen_
Pero la parte que toca leer

[10:05 p. m.] **Tú:** Jajaaka

[10:06 p. m.] **Tú:** Me manda todo el libro

[10:06 p. m.] **Vale 🌙:** [Mensaje de voz]

[10:06 p. m.] **Vale 🌙:** [Mensaje de voz]

[10:06 p. m.] **Tú:** Como hay contra luz puede que sea vea un poco mi pene pero no hay problema verdad

[10:06 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Pero siempre es largo

[10:06 p. m.] **Tú:** Jsjsjssk

[10:06 p. m.] **Tú:** Está re chimba

[10:06 p. m.] **Vale 🌙:** Ese si

[10:06 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Si si lo vi.

[10:07 p. m.] **Vale 🌙:** [Mensaje de voz]

[10:07 p. m.] **Tú:** Bueno y de qué tratan

[10:07 p. m.] **Tú:** Hasta donde ah leído

[10:07 p. m.] **Vale 🌙:** [Mensaje de voz]

[10:08 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Nah nah nah

[10:08 p. m.] **Tú:** Que leyó

[10:08 p. m.] **Tú:** No se que era el tema

[10:10 p. m.] **Tú:** Si estabas leyendo o solo mirando cuál te gustaba más

[10:10 p. m.] **Tú:** 😑

[10:10 p. m.] **Vale 🌙:** [Mensaje de voz]

[10:10 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Uyy música para mis oídos

[10:11 p. m.] **Tú:** Que rico como lees

[10:11 p. m.] **Tú:** Me mojé

[10:11 p. m.] **Tú:** [Sticker]

[10:13 p. m.] **Vale 🌙:** [Mensaje de voz]

[10:13 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Hp

[10:13 p. m.] **Tú:** Me vengooo

[10:13 p. m.] **Tú:** Yo canto porque la mujer mía hace gemir

[10:13 p. m.] **Tú:** Muy ricooo

[10:13 p. m.] **Tú:** Ahhhhhhh

[10:13 p. m.] **Tú:** Nopooo hay leche por todas partes

[10:14 p. m.] **Tú:** [Sticker]

[10:14 p. m.] **Tú:** Siii

[10:14 p. m.] **Tú:** Se me está levantando el muerto

[10:14 p. m.] **Vale 🌙:**
> _Tú: Yo canto porque la mujer mía hace gemir_
Hay amor 🤭

[10:15 p. m.] **Tú:** Y si yo gimo a ella le gusta

[10:15 p. m.] **Tú:** Y después cambiamos de roles

[10:15 p. m.] **Tú:** Quiere que le gima bb jajajaja

[10:15 p. m.] **Tú:** A ver si se va al baño de una vez

[10:16 p. m.] **Tú:** Y hacemos un poema en tre los dos

[10:17 p. m.] **Vale 🌙:** No porque me éxito

[10:17 p. m.] **Tú:** Y versos sobran pero, pero sus suspiros acelerados, cuando me dices que no salga pero no de me detenga es uno de los poemas más lentos pero ricos que hay

[10:17 p. m.] **Tú:** Cuando nos acercamos uno al otro solo para decir esas frases que solo el otro entiende, y llega al clímax de momento

[10:18 p. m.] **Tú:** Donde agrrras las sábanas no tantas fuerzas, que no sabes si gritar o pedir más

[10:19 p. m.] **Tú:** Cuando enredas tus piernas a mi cintura como quien no quiere dejar ir a una persona pero sabes lo que conlleva entonces lo sueltas

[10:20 p. m.] **Vale 🌙:** [Sticker]

[10:21 p. m.] **Tú:** Apretas tu vientre para lo que sientes es un calor que invade tu cuerpo, y deja salir el gemido que termina con un suspiro de satisfacción, y un encanto en los ojos que solo los besos pueden seguir, algo que el cuerpo no puede expresar más

[10:21 p. m.] **Tú:** Ahh no

[10:21 p. m.] **Tú:** Mija vaya encuérese

[10:21 p. m.] **Tú:** Y me manda un video

[10:21 p. m.] **Tú:** Le falta mucho para llegar a ese nivel de detalle poético y sexual

[10:22 p. m.] **Tú:**
> _Vale 🌙: No porque me éxito_
Y lo malo donde esta

[10:22 p. m.] **Tú:** Si lo quiere se lo hago

[10:23 p. m.] **Tú:** Un gran poder conlleva una gran responsabilidad, yo me hago responsable de utd hasta que el calor deje ese cuerpo

[10:24 p. m.] **Vale 🌙:** Amor dame un segundo que estoy procesando la excitación mental y corporal que acabas de provocar

[10:24 p. m.] **Tú:**
> _Vale 🌙: Amor dame un segundo que estoy procesando la excitación mental y corporal que acabas de provocar_
Ahh no y eso que hace falta el Audio

[10:28 p. m.] **Tú:** _Esperando el mensaje… Esto puede demorar un poco._

[10:32 p. m.] **Vale 🌙:** 🌒
Súplico a tu mente y a tu cuerpo ,
quédate un verso más sobre mi piel,
que tus suspiros acelerados son el único reloj
que quiero escuchar esta noche.

y yo obedezco a tu contradicción perfecta,incluso cuando creo que puedo más mi cuerpo te sigue necesitando  más 
lento, pero igual de fuerte , para aprenderte de memoria,
rico, profundo, lo memorioso en mi celebro  como si fuese  un secreto.

Cuando nuestras frentes se rozan,
cuando nos decimos esas frases que nadie más traduce,
sé que estamos a punto de caer,
y caer contigo es mi forma favorita de tocar el cielo.

Agarra las sábanas, aferrarme a tí,
no decido todavía si voy a gritar o a pedirte más,
dejo que tu cuerpo dude, que tiemble, que elija,
estaré ahí hasta que mi cuerpo tiemble para ti 

Enrédame, apriétame con esas manos que no mienten,
suelta, vuelve, castígame con irte un segundo,
siento cómo se tensa mi vientre, cómo me invade tu calor,
y cómo por fin te rindes.

Ese gemido tuyo que termina en suspiro,
ese brillo en tus ojos que me pide sin voz,
es el final y el principio de todo cuando yo tambien lo ago 

Ven, que ahora solo los besos pueden con lo que mi mente no para de imaginar en las distancias física pero no sentimental

[10:34 p. m.] **Vale 🌙:** Y más humilde reacción 🤤🤤🤤

[10:41 p. m.] **Vale 🌙:** _Esperando el mensaje… Esto puede demorar un poco._

[10:41 p. m.] **Vale 🌙:**
> _Vale 🌙: Video_
Ver cuando estés solo

[10:57 p. m.] **Tú:**
> _Vale 🌙: Ver cuando estés solo_
Ojito y poque  para ver una vez

[10:57 p. m.] **Tú:** Diodos

[10:59 p. m.] **Vale 🌙:** Por que  estaba en el baño y fue algo rápido solo para tranquilizar mis ganas

[11:00 p. m.] **Tú:**
> _Vale 🌙: Video_
Dios

[11:00 p. m.] **Tú:** Que rico como se te ve mojadita

[11:00 p. m.] **Tú:** Que envidia que seas tu y no yo el que este haciendo ese trabajo

[11:00 p. m.] **Tú:** Jajajaj

[11:00 p. m.] **Tú:** Quien la ve tan arrecha

[11:00 p. m.] **Tú:** Ya ya mucho por hoy entonces

[11:01 p. m.] **Tú:** Rico rico

[11:01 p. m.] **Tú:** Quien diría que hacer competencias del pormss

[11:01 p. m.] **Tú:** Poemas

[11:01 p. m.] **Tú:** Seria tan interesante

[11:01 p. m.] **Tú:** Jajasjsk

[11:01 p. m.] **Tú:** A dormir felices

[11:01 p. m.] **Tú:** Ya ahorita te hago uno

[11:02 p. m.] **Vale 🌙:**
> _Tú: A dormir felices_
Descansa mi lindo amor

[11:04 p. m.] **Tú:** _Esperando el mensaje… Esto puede demorar un poco._

[11:05 p. m.] **Vale 🌙:** Que rico mi cielo

[11:11 p. m.] **Tú:** Descansa  mi vida bella

---

## 3 de septiembre de 2026

[7:15 a. m.] **Vale 🌙:** Wuenos días

[12:17 p. m.] **Tú:** Holiii

[12:17 p. m.] **Tú:** Como tas mi reina

[12:17 p. m.] **Tú:** Que haces

[12:19 p. m.] **Vale 🌙:** Ya voy a ir a buscar a mi hermana

[12:20 p. m.] **Tú:** Que te vaya bien por ahí

[12:20 p. m.] **Tú:** Avisas cuando llegues

[12:21 p. m.] **Vale 🌙:** Oki

[1:24 p. m.] **Tú:** https://www.instagram.com/p/Dcjjr3UGVDj/?img_index=1&igsi=MXRmY3NqMGFvenNyNQ==

[1:31 p. m.] **Tú:** https://www.instagram.com/reel/DcwKIXpImkP/?igsi=MTM4cDdmdzVhcnc1eg==

[1:33 p. m.] **Tú:** https://www.instagram.com/reel/DczztJbsZFw/?igsi=MTA2ejQ3bzN4cWZzYg==

[1:33 p. m.] **Tú:** https://www.instagram.com/reel/DczPjLvT121/?igsi=cmpnZGx2dXJxYXQx

[1:33 p. m.] **Tú:** https://www.instagram.com/reel/DbL3J2burMa/?igsi=MW53enJwaWoybHY4ZA==

[1:34 p. m.] **Tú:** https://www.instagram.com/reel/DcuOJEsO-vt/?igsi=MTMwZWRyZ21sd2dteQ==

[1:35 p. m.] **Tú:** https://www.instagram.com/reel/DcBm8yuuWCd/?igsi=N216bGkwYmhsaDJn

[1:36 p. m.] **Tú:** https://www.instagram.com/reel/DZWi4bJNNYv/?igsi=dTljdWp4bHFyZ2Q5

[1:37 p. m.] **Tú:** https://www.instagram.com/reel/DbmX2t8PAQV/?igsi=czQ2ODR4dXBiOTlm

[1:39 p. m.] **Tú:** https://www.instagram.com/reel/DczN0xzqq8C/?igsi=MWd6bXg3MGdhMWZ4cg==

[1:42 p. m.] **Tú:** https://www.instagram.com/reel/DccArvUsZ7-/?igsi=eGdqcXZobmM3b3o3

[1:46 p. m.] **Tú:** https://www.instagram.com/reel/DZ8kK5khkBP/?igsi=bmZpaXdudGg5c3Vs

[1:52 p. m.] **Vale 🌙:**
> _Tú: https://www.instagram.com/p/Dcjjr3UGVDj/?img_index=1&igsi=MXRmY3NqMGFvenNyNQ==_
En pocas palabras nunca

[1:52 p. m.] **Tú:** https://www.instagram.com/reel/Dblz3I5RHRz/?igsi=aWQyZzl5MzFyZ3p6

[1:52 p. m.] **Vale 🌙:**
> _Tú: https://www.instagram.com/reel/DcwKIXpImkP/?igsi=MTM4cDdmdzVhcnc1eg==_
Jsjsj

[1:53 p. m.] **Tú:** https://www.instagram.com/reel/DcwLWoyNjXs/?igsi=aXA3ZWUzeGYyMnNo

[1:54 p. m.] **Vale 🌙:**
> _Tú: https://www.instagram.com/reel/DczztJbsZFw/?igsi=MTA2ejQ3bzN4cWZzYg==_
Tan lindo el bb

[1:55 p. m.] **Tú:** https://www.instagram.com/reel/DW1ULzWOubn/?igsi=NHliNDV2dzV6NWE4

[1:55 p. m.] **Vale 🌙:**
> _Tú: https://www.instagram.com/reel/DcuOJEsO-vt/?igsi=MTMwZWRyZ21sd2dteQ==_
Eso Takis que tenían jsjs

[1:57 p. m.] **Tú:** https://www.instagram.com/reel/DbmplTyxo93/?igsi=NHBxczYxbmthajAz

[1:58 p. m.] **Tú:** https://www.instagram.com/reel/DcNftklncwD/?igsi=MWx4Z2d4ZDE3cXpsMw==

[1:58 p. m.] **Vale 🌙:**
> _Tú: https://www.instagram.com/reel/DczN0xzqq8C/?igsi=MWd6bXg3MGdhMWZ4cg==_
Como ami no me compran ando como me da la gana

[1:59 p. m.] **Vale 🌙:**
> _Tú: https://www.instagram.com/reel/DccArvUsZ7-/?igsi=eGdqcXZobmM3b3o3_
Antes morida que tatuarne eso

[1:59 p. m.] **Tú:** https://www.instagram.com/reel/Dczlhl_RG6j/?igsi=OWJ1czh6ZGUzNmJ5

[2:00 p. m.] **Tú:** https://www.instagram.com/reel/DavlwBWRtE4/?igsi=M3RoMXppbW0zd3Vn

[2:00 p. m.] **Vale 🌙:**
> _Tú: https://www.instagram.com/reel/DW1ULzWOubn/?igsi=NHliNDV2dzV6NWE4_
Que putas

[2:01 p. m.] **Tú:** https://www.instagram.com/reel/DcySlg3TJI8/?igsi=Z2U3bGY0M2E2dHhq

[2:02 p. m.] **Tú:** https://www.instagram.com/reel/DcvlVpshHn_/?igsi=MWpkb3E1MmY5a2l4dA==

[2:03 p. m.] **Tú:** https://www.instagram.com/reel/Dcs41bNx6SX/?igsi=aWcwNWY4bG5kdmVl

[2:08 p. m.] **Tú:** https://www.instagram.com/reel/DaCTg9TSyZH/?igsi=MmRobzdmMndjZG13

[2:09 p. m.] **Tú:** https://www.instagram.com/reel/DcxI65-gboH/?igsi=cXl6ZmpkYjd6d3F0

[2:10 p. m.] **Tú:** https://www.instagram.com/reel/DcMNrR5Ieyi/?igsi=dDJrdHR6ZDdzeWRn

[2:15 p. m.] **Tú:** https://www.instagram.com/reel/DcveeNlhxsM/?igsi=M3MwZnVrdmJtYjZl

[2:16 p. m.] **Vale 🌙:**
> _Tú: https://www.instagram.com/reel/DaCTg9TSyZH/?igsi=MmRobzdmMndjZG13_
El almuadaso

[2:17 p. m.] **Vale 🌙:**
> _Tú: https://www.instagram.com/reel/DcveeNlhxsM/?igsi=M3MwZnVrdmJtYjZl_
El menos masoquista

[2:25 p. m.] **Tú:** https://www.instagram.com/reel/Dbqex_rMltA/?igsi=amx2bzNjbWV2YWll

[2:27 p. m.] **Tú:** https://www.instagram.com/reel/Daau2T6tzF6/?igsi=aGx2bjJrNTcyYW8w

[2:33 p. m.] **Tú:** https://www.instagram.com/reel/DaYH_mqPjF_/?igsi=MWJwbDlkY3ZuMXVwcg==

[3:01 p. m.] **Tú:** Join my Circle in Life360! Invite code: BNX-34O. Tap the link to join. https://i.lf360.co/IkUeXFNM85b

[3:09 p. m.] **Vale 🌙:**
> _Tú: Join my Circle in Life360! Invite code: BNX-34O. Tap the link to join. https://i.lf360.co/IkUeXFNM85b_
Ya

[3:10 p. m.] **Tú:** Ya como te fue

[3:10 p. m.] **Tú:**
> _Vale 🌙: Ya_
Pero no le diste permisos de nada

[3:11 p. m.] **Tú:** Está ahí

[3:12 p. m.] **Tú:** [Imagen]

[3:13 p. m.] **Tú:** Me cuentas cómo te va en esa entrevista

[3:13 p. m.] **Tú:** Hablamos

[5:11 p. m.] **Vale 🌙:** Entro mañana a las 2:40

[6:27 p. m.] **Tú:**
> _Vale 🌙: Entro mañana a las 2:40_
Verga

[6:28 p. m.] **Tú:** Pero bueno eso fue rápido

[6:28 p. m.] **Tú:** Y de qué hora a qué hora te toca

[6:28 p. m.] **Tú:** Lo bueno es que es cerca de la casa no

[6:28 p. m.] **Tú:** Me toca ahorita pagar el Spotify

[6:29 p. m.] **Vale 🌙:**
> _Tú: Y de qué hora a qué hora te toca_
3 a 12

[6:29 p. m.] **Tú:**
> _Vale 🌙: 3 a 12_
A media noche pesado

[6:29 p. m.] **Vale 🌙:**
> _Tú: Me toca ahorita pagar el Spotify_
A mi me pagan el 15

[6:29 p. m.] **Tú:** Y qué tal ese restaurante

[6:29 p. m.] **Tú:** Si llega mucha gente o que

[6:29 p. m.] **Tú:** Y pagos

[6:29 p. m.] **Tú:** Qué tal el salario

[6:29 p. m.] **Tú:**
> _Vale 🌙: A mi me pagan el 15_
Relax

[6:29 p. m.] **Tú:** De momento tengo

[6:29 p. m.] **Vale 🌙:**
> _Tú: Y pagos_
Buenos hay trabaja la amiga de mi mamá pagan igual que en gaira

[6:30 p. m.] **Tú:** Igual necesito que me salga algo no puede estar en ese modo ahorro

[6:30 p. m.] **Vale 🌙:** El mínimo quincenal y  las propinas los 5

[6:30 p. m.] **Tú:**
> _Vale 🌙: Buenos hay trabaja la amiga de mi mamá pagan igual que en gaira_
En qué

[6:30 p. m.] **Tú:**
> _Vale 🌙: El mínimo quincenal y  las propinas los 5_
Como así

[6:30 p. m.] **Tú:** Mija escriba bien

[6:30 p. m.] **Tú:** El mínimo al mes

[6:30 p. m.] **Tú:** Y te dan la mitad quincenal si

[6:31 p. m.] **Tú:** Más propina

[6:43 p. m.] **Tú:** Como vas

[6:43 p. m.] **Tú:** Pero necesitas para algo pasajes

[6:43 p. m.] **Tú:** Le mando 20k

[6:43 p. m.] **Tú:** Si los llegas a necesitar

[6:48 p. m.] **Vale 🌙:** Vale amo mío gracias te amito

[6:53 p. m.] **Vale 🌙:** Tengo los exámenes en laureles

[6:54 p. m.] **Tú:**
> _Vale 🌙: Tengo los exámenes en laureles_
Mor

[6:54 p. m.] **Tú:** A mi explícame donde

[6:54 p. m.] **Tú:** Porque para mí eso es suba

[6:55 p. m.] **Tú:**
> _Vale 🌙: Vale amo mío gracias te amito_
Ósea que me avises para mandártelos si los llegas a necesitar

[6:55 p. m.] **Tú:** Porque ajá me toca pasar de una cuenta a otra

[6:55 p. m.] **Tú:** En dado caso que salgas muy tarde y esté sin money me avisas

[8:01 p. m.] **Vale 🌙:**
> _Tú: Mor_
Amor ni yo sé dónde queda nunca e ido por aya

[9:23 p. m.] **Tú:** [Video]

[10:07 p. m.] **Vale 🌙:** Siempre me toca lejos y me toca abrir una cuenta en BBVA

[10:50 p. m.] **Tú:**
> _Vale 🌙: Siempre me toca lejos y me toca abrir una cuenta en BBVA_
Luego eso no quedaba cerca de donde estás

[10:51 p. m.] **Tú:** Verga

[10:51 p. m.] **Tú:** Y tienes mañana para eso

[10:51 p. m.] **Tú:** Bueno igual te pagan 15 mal

[10:51 p. m.] **Tú:** Tienes tiempo

[10:51 p. m.] **Tú:** Eso es que te dan contrato súper bien

[10:51 p. m.] **Tú:** Re bien

[10:51 p. m.] **Tú:** Ojalá y dures más ahí

[10:51 p. m.] **Tú:** Me voy a poner a ver videos

[10:51 p. m.] **Tú:** Hablamos mañana

[10:52 p. m.] **Tú:** Sueña bonito

[11:08 p. m.] **Vale 🌙:**
> _Tú: Eso es que te dan contrato súper bien_
Si mañana tengo que firmar contrato y resubir la dotación

[11:09 p. m.] **Vale 🌙:**
> _Tú: Luego eso no quedaba cerca de donde estás_
Yo te dije que los exámenes los mandaron para laureles y el BBVA nosé donde me queda

[11:10 p. m.] **Vale 🌙:**
> _Tú: Y tienes mañana para eso_
No pero será decirle a mi primo si tiene que me preste o ami mama

[11:11 p. m.] **Vale 🌙:** Hasta mañana mi bb lindo descansa

[11:12 p. m.] **Tú:** [Imagen]

---

## 4 de septiembre de 2026

[5:33 a. m.] **Vale 🌙:**
> _Tú: Imagen_
Gracias amor mío

[5:33 a. m.] **Vale 🌙:** Tengo los exámenes a las 8

[11:58 a. m.] **Vale 🌙:** [Mensaje de voz]

[12:01 p. m.] **Tú:** [Mensaje de voz]

[12:05 p. m.] **Vale 🌙:** [Mensaje de voz]

[1:11 p. m.] **Vale 🌙:** Ya estoy en la casa

[1:11 p. m.] **Vale 🌙:** Almuerzo y salgo a trabajar

[2:43 p. m.] **Vale 🌙:** Ya voy entrar te ablo cuando salga

[2:51 p. m.] **Tú:** [Imagen]

[2:51 p. m.] **Tú:** Yo ando por acá

[2:51 p. m.] **Tú:** Yo me demoro

[2:51 p. m.] **Tú:** Me cuentas cómo te va

[2:51 p. m.] **Tú:** A qué hora sales a las 10

[2:53 p. m.] **Tú:** Acá hay una cantidad de gente muy hp

[2:59 p. m.] **Vale 🌙:**
> _Tú: A qué hora sales a las 10_
12

[3:47 p. m.] **Tú:**
> _Vale 🌙: 12_
Verga

[3:47 p. m.] **Tú:** Me cuentas qué tal el trabajo

[3:48 p. m.] **Tú:** Pues yo sé que en la noche es duro pero cuando uno abre es fácil o

[3:48 p. m.] **Tú:** Porque en el pueblo es así

[3:48 p. m.] **Tú:** Me avisas cuando salgas

[3:48 p. m.] **Tú:** Yo ya voy para la casas

[5:21 p. m.] **Tú:** Apenas llegué

[5:21 p. m.] **Tú:** Cómo vas

[5:55 p. m.] **Vale 🌙:** ya voy a comer me dan una hora y vuelvo

[5:58 p. m.] **Tú:**
> _Vale 🌙: ya voy a comer me dan una hora y vuelvo_
Qué bueno

[5:58 p. m.] **Tú:** Y qué tal esa eso

[5:58 p. m.] **Tú:** Mucho trabajo

[5:58 p. m.] **Tú:** O está relax

[6:01 p. m.] **Vale 🌙:** Me gusta

[6:03 p. m.] **Tú:** Qué bueno

[6:03 p. m.] **Tú:** Y de qué es el restaurante

[6:05 p. m.] **Vale 🌙:** [Imagen]

[8:00 p. m.] **Tú:**
> _Vale 🌙: Imagen_
Ojito

[8:00 p. m.] **Tú:** Pero es un restaurante  así como el de Carlos vives

[8:00 p. m.] **Tú:** En el que trabajaste alguna ves

[8:00 p. m.] **Tú:** O más suave

[8:00 p. m.] **Tú:** Me imagino

[8:01 p. m.] **Tú:**
> _Vale 🌙: Imagen_
Los cortes no están caros

[8:01 p. m.] **Tú:** Los que si explotan es las bebidas

[8:44 p. m.] **Tú:** [Sticker]

[9:12 p. m.] **Tú:** [Mensaje de album]

[9:12 p. m.] **Tú:** [Imagen]

[9:12 p. m.] **Tú:** [Imagen]

[9:12 p. m.] **Tú:** [Imagen]

[9:12 p. m.] **Tú:** [Imagen]

[9:12 p. m.] **Tú:** [Imagen]

[9:12 p. m.] **Tú:** [Mensaje de unknown]

[9:12 p. m.] **Tú:** [Mensaje de unknown]

[9:12 p. m.] **Tú:** [Mensaje de unknown]

---

## 5 de septiembre de 2026

[1:13 a. m.] **Vale 🌙:** Te aviso cuando llegue

[1:13 a. m.] **Tú:** Pss

[1:13 a. m.] **Tú:** Si porque quién sabe dónde anda

[1:14 a. m.] **Vale 🌙:** Por venimos un momentico con mis compañeras a despedir a una

[1:14 a. m.] **Vale 🌙:** Y a celebrar mi ingreso

[1:14 a. m.] **Tú:** Claro

[1:15 a. m.] **Vale 🌙:** [Imagen]

[2:19 a. m.] **Tú:**
> _Vale 🌙: Imagen_
Será esperar

[2:20 a. m.] **Tú:** Yo estoy pendiente hasta que llegue a la casa entonces

[2:20 a. m.] **Tú:** No deje apagar el celular

[4:25 a. m.] **Tú:** Cómo va

[4:26 a. m.] **Tú:** _Eliminaste este mensaje._

[4:26 a. m.] **Tú:** _Eliminaste este mensaje._

[4:46 a. m.] **Vale 🌙:** Tomando tinto con mi mamá

[4:46 a. m.] **Vale 🌙:** [Imagen]

[4:47 a. m.] **Vale 🌙:** Estaba cargando el cel

[5:04 a. m.] **Vale 🌙:** Aprendí hacer todas las sodas todos los jugos un el cóctel que más sale el Américano el expreso y el capuchino

[5:04 a. m.] **Vale 🌙:** Csibme voleo pero todo redib

[5:05 a. m.] **Vale 🌙:** Hay más boleo en la noche

[5:11 a. m.] **Vale 🌙:** Me levanto a las 10 :39 te amo

[5:11 a. m.] __[Llamada]__

[10:44 a. m.] **Vale 🌙:** Hoy entro a las 4 de la tarde

[2:55 p. m.] **Tú:**
> _Vale 🌙: Hoy entro a las 4 de la tarde_
Ya casi

[2:55 p. m.] **Tú:** Si descanso

[2:56 p. m.] **Tú:** De tanta vuelta que dio

[2:56 p. m.] **Tú:** No te había escrito

[2:56 p. m.] **Tú:** Se me dañó el cargador de celular

[2:56 p. m.] **Tú:** Se quemó

[2:56 p. m.] **Tú:** Y como ayer no lo puse a cargar

[2:57 p. m.] **Tú:** Apenas llegó utd me acosté

[2:57 p. m.] **Tú:** Y me llamaron al rato

[2:57 p. m.] **Tú:** Quién sabe qué Valentina sería

[2:57 p. m.] **Tú:** Que andas haciendo

[2:57 p. m.] **Tú:** Ya pasó el guayabo

[3:22 p. m.] **Vale 🌙:** Ya voy a entrar a trabajar

[3:29 p. m.] **Tú:** Vale me cuentas como te va

[3:29 p. m.] **Tú:** Hoy también va a salir

[4:24 p. m.] **Tú:** Bueno

[4:24 p. m.] **Tú:** Igual que te vaya bien

[4:25 p. m.] **Tú:** T amo

[5:12 p. m.] **Vale 🌙:** Ya voy almorzar

[5:27 p. m.] **Tú:** Almuerzo a las 5 de la tard3

[5:27 p. m.] **Tú:** No empieces otra vez con ese descontrol de las comidas

[5:27 p. m.] **Tú:** Que bien difícil que es que coma bien

[5:27 p. m.] **Tú:** 2 meses dure

[5:27 p. m.] **Tú:** Para que se comiera un plato completo

[5:28 p. m.] **Tú:** Alla te dan comida o llevaste

[5:28 p. m.] **Vale 🌙:** Pues la comida

[5:28 p. m.] **Vale 🌙:** Que dan acá en el trabajo

[5:28 p. m.] **Vale 🌙:** [Imagen]

[5:29 p. m.] **Tú:**
> _Vale 🌙: Imagen_
Se ve rico

[5:29 p. m.] **Tú:** Me guarda

[5:29 p. m.] **Tú:** Y un vive 100

[5:29 p. m.] **Tú:** [Sticker]

[5:29 p. m.] **Vale 🌙:**
> _Tú: Y un vive 100_
El vive si lo compre aparte

[5:29 p. m.] **Tú:**
> _Vale 🌙: El vive si lo compre aparte_
Aja y porque compras eso

[5:30 p. m.] **Tú:** Eso es malo

[5:30 p. m.] **Tú:** [Sticker]

[5:30 p. m.] **Vale 🌙:** _Esperando el mensaje… Esto puede demorar un poco._

[5:30 p. m.] **Tú:** No podré estar allá

[5:30 p. m.] **Tú:** Más no significa  que no este pendiente  de vos

[5:30 p. m.] **Tú:** Ese lejos o cerca no dejas de ser mi novia

[5:30 p. m.] **Tú:**
> _Vale 🌙: Imagen_
Ahh ya

[5:30 p. m.] **Tú:** Jajajaj

[5:31 p. m.] **Tú:** Por lo menos tienes buen apetito

[5:31 p. m.] **Tú:** A ver esa cara

[5:31 p. m.] **Vale 🌙:** [Mensaje de voz]

[5:31 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Esta llenita  entonces

[5:31 p. m.] **Tú:** Bueno por lo menos

[5:31 p. m.] **Tú:** Ya me calmo por ese lado

[5:32 p. m.] **Tú:** Besos, en esa cuca que ya me hace falta

[5:32 p. m.] **Tú:** Y se escapa unos diitas

[5:32 p. m.] **Tú:** Y yo le pago los días

[5:32 p. m.] **Tú:** Voy a salir

[5:32 p. m.] **Tú:** Al rato hablamos

[5:32 p. m.] **Tú:** Me manda foto de la cara

[5:32 p. m.] **Tú:** Quiero ver

[5:32 p. m.] **Tú:** Que tan demacrada esta

[5:33 p. m.] **Vale 🌙:** [Video]

[5:33 p. m.] **Tú:**
> _Vale 🌙: Video_
Esta hasta bonito el uniforme

[5:33 p. m.] **Tú:** Diles que si no hay un puesto para mi

[5:33 p. m.] **Tú:** Yo de alcoholizar  a la gente de una forma

[5:34 p. m.] **Tú:** Cusndo vengas traete

[5:34 p. m.] **Tú:** Lo

[5:34 p. m.] **Tú:** Me la como de mesera

[5:34 p. m.] **Tú:** [Sticker]

[5:34 p. m.] **Tú:** Ya voy a salir

[5:34 p. m.] **Tú:** Halvamos

[5:34 p. m.] **Tú:** Estas bella mía mor

[5:34 p. m.] **Tú:** Besos

[5:34 p. m.] **Tú:** Así me saque la piedra

[5:34 p. m.] **Tú:** No dormi por estar pendiente  a utd

[5:34 p. m.] **Vale 🌙:** 💋 te amo mi bb

[5:35 p. m.] **Vale 🌙:**
> _Tú: No dormi por estar pendiente  a utd_
Hay amor te ubieras acostado

[7:50 p. m.] **Tú:** Oscar me invitó a una cerveza

[7:51 p. m.] **Tú:** [Imagen]

[9:10 p. m.] **Tú:** [Imagen]

[9:10 p. m.] **Tú:** Cambiamos de lado

[9:10 p. m.] **Tú:** Igual sigo en el barrio

[10:00 p. m.] **Tú:** [Imagen]

[10:44 p. m.] **Tú:** [Video]

[11:05 p. m.] **Tú:** [Mensaje de voz]

[11:06 p. m.] **Tú:** [Video]

[11:16 p. m.] **Tú:** Ya llegué

---

## 6 de septiembre de 2026

[12:41 a. m.] **Vale 🌙:** [Mensaje de voz]

[12:47 a. m.] **Vale 🌙:**
> _Tú: Mensaje de voz_
Jsjd Abla en ebrio

[12:49 a. m.] __[Llamada]__

[10:30 a. m.] **Vale 🌙:** _Esperando el mensaje… Esto puede demorar un poco._

[10:31 a. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Verga

[10:31 a. m.] **Tú:** Yo no sé yo me quedé dormído

[10:31 a. m.] **Vale 🌙:** Me está doliendo muela y amanecí con la cara inchada

[10:31 a. m.] **Tú:**
> _Vale 🌙: [call_log]_
Y eso jsjsjssj

[10:31 a. m.] **Tú:**
> _Vale 🌙: Imagen_
Esa cara

[10:31 a. m.] **Tú:** La tienes como inchada de un lado

[10:31 a. m.] **Tú:**
> _Vale 🌙: Me está doliendo muela y amanecí con la cara inchada_
Siii se nota

[10:31 a. m.] **Tú:** Y eso

[10:32 a. m.] **Tú:** Luego que hiciste comiste algo

[10:32 a. m.] **Tú:** O que

[10:32 a. m.] **Vale 🌙:** Nada

[10:32 a. m.] **Vale 🌙:** Es por lo de la muela

[11:00 a. m.] **Tú:**
> _Vale 🌙: Es por lo de la muela_
Toca que tomes un desinflamatorio

[11:00 a. m.] **Tú:** Porque eso para trabajar o hablar puede empeorar

[11:00 a. m.] **Tú:** O sacarla

[11:12 a. m.] **Vale 🌙:**
> _Tú: Toca que tomes un desinflamatorio_
Ya

[11:39 a. m.] **Tú:** [Mensaje de voz]

[1:34 p. m.] **Tú:** [Mensaje de voz]

[5:15 p. m.] **Vale 🌙:** [Imagen] Ya voy almorzar

[5:17 p. m.] **Vale 🌙:** [Mensaje de video]

[5:33 p. m.] **Tú:**
> _Vale 🌙: Imagen: Ya voy almorzar_
Ojito

[5:33 p. m.] **Tú:** Pero te dan cules cosas

[5:33 p. m.] **Tú:** Para comer que rico

[5:33 p. m.] **Tú:**
> _Vale 🌙: Mensaje de video_
Y eso que

[5:33 p. m.] **Tú:** Donde estas

[5:33 p. m.] **Tú:** Saliste o qué

[5:33 p. m.] **Tú:**
> _Vale 🌙: Mensaje de video_
Con tus compañeros o que

[5:36 p. m.] **Tú:** [Imagen]

[5:38 p. m.] **Vale 🌙:**
> _Tú: Saliste o qué_
De tras de el trabajo

[5:38 p. m.] **Tú:** [Imagen]

[5:38 p. m.] **Tú:** El atardecer del maicra

[5:38 p. m.] **Tú:** Te lo dedico

[5:38 p. m.] **Tú:** [Imagen]

[5:38 p. m.] **Tú:** Con esa imagen sota

[5:38 p. m.] **Vale 🌙:** Hermoso

[7:34 p. m.] **Tú:** Dime una cosa

[7:34 p. m.] **Tú:** Después de eso digo una pregunta

[8:40 p. m.] **Vale 🌙:**
> _Tú: Dime una cosa_
Dime amor

[10:45 p. m.] **Vale 🌙:** Ya salí

[10:45 p. m.] **Tú:** Vale mi vida

[10:45 p. m.] **Tú:** Me avisas cuando llegues  a la casita

[10:46 p. m.] **Tú:** Estoy viendo una serie con mi mama y Oscar

[10:46 p. m.] **Vale 🌙:**
> _Vale 🌙: Dime amor_
??

[10:46 p. m.] **Tú:**
> _Vale 🌙: ??_
Al rato te digo

[10:46 p. m.] **Tú:** Llega primero

[10:46 p. m.] **Tú:** Me avisas

[10:52 p. m.] **Vale 🌙:** Oki

[11:04 p. m.] **Vale 🌙:** Todavía demoro ando ablando mierda con la jefa de mi alma y mis compañeros

[11:08 p. m.] **Vale 🌙:** Mientras me llega la moto

[11:09 p. m.] **Tú:** Tranqui

[11:09 p. m.] **Tú:** Igual por ahí que te estás tomando algo

[11:09 p. m.] **Tú:** Me vas contando

[11:10 p. m.] **Vale 🌙:**
> _Tú: Igual por ahí que te estás tomando algo_
Ya me la termine estoy esperando la moto esa me la gasto la jefa de mi mama

[11:18 p. m.] **Tú:** Vale mi vida

---

## 7 de septiembre de 2026

[12:04 a. m.] **Vale 🌙:** Yo ya me cambié ya voy a dormir amor

[12:09 a. m.] **Vale 🌙:** Mañana entro a las 5 asta el cierre

[12:10 a. m.] **Vale 🌙:** Toda la semana voy asta el cierre

[12:10 a. m.] **Vale 🌙:** El miércoles descanso

[12:17 a. m.] **Vale 🌙:** [Video] Mi mami me compro una pijama de mi color favorito

[12:17 a. m.] **Vale 🌙:** [Mensaje de video]

[10:18 a. m.] **Tú:** Holiii

[10:18 a. m.] **Tú:** Jajaaj

[10:19 a. m.] **Tú:**
> _Vale 🌙: Yo ya me cambié ya voy a dormir amor_
Ta bien amor

[10:19 a. m.] **Tú:** Ya te despertaste

[10:19 a. m.] **Tú:** Buenos días mi vida

[10:19 a. m.] **Tú:** Como  estas

[10:19 a. m.] **Tú:**
> _Vale 🌙: Mañana entro a las 5 asta el cierre_
Osea

[10:19 a. m.] **Tú:** Hasta las 12

[10:19 a. m.] **Tú:** Si

[10:19 a. m.] **Tú:**
> _Vale 🌙: Toda la semana voy asta el cierre_
Verga

[10:19 a. m.] **Tú:** Toca duro

[10:19 a. m.] **Tú:** Pero no se ve que llegue  tanta gente o si

[10:19 a. m.] **Tú:**
> _Vale 🌙: El miércoles descanso_
Oye y si

[10:20 a. m.] **Tú:** Que días descansas

[10:20 a. m.] **Tú:**
> _Vale 🌙: Video: Mi mami me compro una pijama de mi color favorito_
Esta bien bonita

[10:20 a. m.] **Tú:** Esa es la que me vas a dar cuando me quede

[10:20 a. m.] **Tú:**
> _Vale 🌙: Mensaje de video_
Jajaajajaa

[10:20 a. m.] **Tú:** Toda consentida

[10:25 a. m.] **Vale 🌙:**
> _Tú: Pero no se ve que llegue  tanta gente o si_
Tiene sus momentos ayer simpre me bolie un rato

[10:26 a. m.] **Vale 🌙:** Voy para el odontólogo

[10:26 a. m.] **Vale 🌙:** Hoy amanecí con la cara peor que ayet

[10:38 a. m.] **Tú:**
> _Vale 🌙: Tiene sus momentos ayer simpre me bolie un rato_
Claro como todos esos trabajos

[10:38 a. m.] **Tú:** Pero bueno

[10:39 a. m.] **Tú:** Ya le estas comiendo el tir

[10:39 a. m.] **Tú:** Pero como te sientes alla bien

[10:39 a. m.] **Tú:** Me imagino  con tus compañeros

[10:39 a. m.] **Tú:**
> _Vale 🌙: Voy para el odontólogo_
Por el dolor de muela

[10:39 a. m.] **Tú:** Amor si te duele mucho

[10:39 a. m.] **Tú:** Eso va para sacarla

[10:39 a. m.] **Tú:** Pero mejor descansas

[10:39 a. m.] **Tú:**
> _Vale 🌙: Hoy amanecí con la cara peor que ayet_
Eso es que ya

[10:40 a. m.] **Tú:** Ya

[10:40 a. m.] **Tú:** Tiene algo

[10:40 a. m.] **Tú:** Eso le pasa por montarme cacho

[10:40 a. m.] **Tú:** Tririsme cuentas como te va

[10:40 a. m.] **Tú:** Ya saliste?

[10:40 a. m.] **Vale 🌙:** Ya estoy esperando a que me atiendan

[10:44 a. m.] **Tú:** Avers

[10:44 a. m.] **Tú:** Como  tiene la cara mi princesa

[10:45 a. m.] **Tú:** Siga chupando  geta  agena

[10:45 a. m.] **Tú:** Siga

[10:45 a. m.] **Vale 🌙:** Grosero yo no me ando besando con nadie

[10:45 a. m.] **Tú:** Eso no me dijeron

[10:46 a. m.] **Tú:** Muestra pa ve

[10:46 a. m.] **Tú:** Que tienes

[10:46 a. m.] **Vale 🌙:** _Esperando el mensaje… Esto puede demorar un poco._

[10:48 a. m.] **Tú:**
> _Vale 🌙: Imagen_
Por el amor a dios

[10:48 a. m.] **Tú:** Y a ti que te mereces

[10:49 a. m.] **Tú:** Te voy a decir algo

[10:49 a. m.] **Tú:** Valentina

[10:49 a. m.] **Tú:** Maria

[10:49 a. m.] **Tú:** De todos los angeles

[10:49 a. m.] **Tú:** Tu y yo que somos

[10:57 a. m.] **Vale 🌙:** [Mensaje de voz]

[10:58 a. m.] **Vale 🌙:** [Imagen]

[10:58 a. m.] **Vale 🌙:** Y mañana me toca volver

[2:40 p. m.] **Tú:** [Imagen]

[2:45 p. m.] **Vale 🌙:** Voy a dormir una hora

[2:46 p. m.] **Vale 🌙:** Y ya me paro entro a las 5

[2:48 p. m.] **Tú:** El dolor

[2:48 p. m.] **Tú:** Dale

[2:48 p. m.] **Tú:** [Imagen]

[2:49 p. m.] **Tú:** [Mensaje de voz]

[2:50 p. m.] **Vale 🌙:**
> _Tú: El dolor_
Ya me tomé los medicamentos esperar que se baje la inflamación

[2:50 p. m.] **Tú:** [Mensaje de voz]

[2:50 p. m.] **Tú:** [Imagen]

[2:50 p. m.] **Vale 🌙:** Saludes a tu mami

[2:50 p. m.] **Tú:** [Video]

[2:51 p. m.] **Vale 🌙:**
> _Tú: Mensaje de voz_
Te amo tu para mí eres mi novio así no sea la oficial

[2:51 p. m.] **Vale 🌙:**
> _Tú: Mensaje de voz_
Por el hospital  amor

[2:51 p. m.] **Vale 🌙:** Me estaban asiendo lo de la muela

[2:52 p. m.] **Vale 🌙:** Luego fui a sacar la cívica

[2:53 p. m.] **Vale 🌙:** [Mensaje de voz]

[2:53 p. m.] **Vale 🌙:** [Mensaje de voz]

[2:53 p. m.] **Vale 🌙:** [Mensaje de voz]

[2:56 p. m.] **Vale 🌙:** [Video]

[2:56 p. m.] **Vale 🌙:** Voy amir te ablo a las 4:10

[5:50 p. m.] **Vale 🌙:** Amor ya estoy en el trabajo ya comí

[5:50 p. m.] **Tú:** Nosotros apenas llegamos

[5:50 p. m.] **Tú:** Ando re cansando y mañana toca volver jajajajaak

[5:51 p. m.] **Vale 🌙:** Yo mañana también me toca ir asta laureles  para lo de la muela

[5:51 p. m.] **Tú:**
> _Vale 🌙: Yo mañana también me toca ir asta laureles  para lo de la muela_
Ufff

[5:51 p. m.] **Tú:** Te la van a quitar

[5:51 p. m.] **Tú:** O para hacer seguimiento

[5:51 p. m.] **Tú:**
> _Vale 🌙: Amor ya estoy en el trabajo ya comí_
Que comiste

[5:51 p. m.] **Tú:** Pero comes mejor que acs

[5:51 p. m.] **Tú:** Mejor

[5:51 p. m.] **Tú:** Vas a llegar goridta

[5:51 p. m.] **Tú:** Más carne pa mi

[5:52 p. m.] **Tú:** Ya escucho los audios

[6:02 p. m.] **Vale 🌙:** [Mensaje de voz]

[6:02 p. m.] **Vale 🌙:** [Mensaje de voz]

[6:54 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Conducto

[6:54 p. m.] **Tú:** Eso que es

[6:54 p. m.] **Tú:** Explicate

[6:54 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Chorizo

[6:54 p. m.] **Tú:** Quien le dio chorizo

[6:54 p. m.] **Tú:** 🧐

[6:55 p. m.] **Tú:** Ya andas comiendo bien

[6:55 p. m.] **Tú:** Qué tal el trabajo

[9:17 p. m.] **Tú:** Mor

[9:18 p. m.] **Tú:** Dime 5 cosas que te gusten

[9:18 p. m.] **Tú:** Y si tienen variante aja una en especifico

[9:18 p. m.] **Tú:** No se flores imágenes, muñecos etc

[9:23 p. m.] **Tú:** Bueno lo que tu quieras

[9:23 p. m.] **Tú:** Me los mandas porfa

[9:23 p. m.] **Tú:** O me mandas un texto pues

[9:30 p. m.] **Tú:** Andas muy ocupada

[9:31 p. m.] **Tú:** O te puedes meter al baño

[9:31 p. m.] **Tú:** Jajjaja

[9:31 p. m.] **Tú:** O más tarde

[10:01 p. m.] **Tú:** https://corazon-galactico-dia-de-la-novia.netlify.app/

[10:18 p. m.] **Vale 🌙:** [Mensaje de voz]

[10:18 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Temprano

[10:18 p. m.] **Tú:** Como te fue

[10:18 p. m.] **Vale 🌙:** Hoy cerramos antes

[10:18 p. m.] **Tú:** Me avisas cusndo llegues

[10:18 p. m.] **Tú:** Y me cuentas como te fue

[10:19 p. m.] **Vale 🌙:** Buen amor hoy estuvo solito

[10:24 p. m.] **Tú:** Vale mi amor

[10:24 p. m.] **Tú:** Como vas con el tema del Internet

[10:24 p. m.] **Tú:** Quiera que jugáramos algo

[10:25 p. m.] **Vale 🌙:** [Mensaje de voz]

[10:25 p. m.] **Tú:** Nada entonces

[10:34 p. m.] **Vale 🌙:** No amor ya con el favor de Dios mañana ya

[10:48 p. m.] **Tú:** Dale

[10:48 p. m.] **Vale 🌙:** Ya llegué

[10:48 p. m.] **Tú:** Pero si quieres es un jueguito de pokemon re viejo kakaak

[10:48 p. m.] **Tú:** Yo juego eso cuando tenía como 6

[10:49 p. m.] **Tú:** Pero es fácil y pues se puede online así que pa jugar los dos

[10:49 p. m.] **Tú:** O si no seguimos con el mundo del minecraft

[10:49 p. m.] **Tú:**
> _Vale 🌙: Ya llegué_
Como te fue hoy

[10:49 p. m.] **Tú:** Y eso que cerraron temprano

[10:51 p. m.] **Vale 🌙:** No aviann tantos clientes y hisimos haceo antes

[10:57 p. m.] **Tú:** Hay días que toca así de duro

[10:57 p. m.] **Tú:** Pero si hicieron el dia

[10:58 p. m.] **Vale 🌙:**
> _Tú: Pero si hicieron el dia_
Nosé ni me preocupo igual ami me pagan

[10:59 p. m.] **Tú:**
> _Vale 🌙: Nosé ni me preocupo igual ami me pagan_
Que respuesta super estrella

[10:59 p. m.] **Tú:** Hoy le toco relax entonces

[10:59 p. m.] **Tú:** Explicame bien eso

[10:59 p. m.] **Tú:** De lo de la muela

[10:59 p. m.] **Tú:** Que no te entendí

[11:17 p. m.] **Tú:** Parce utd que tiene

[11:17 p. m.] **Tú:** Unos días si esta bien rechevere

[11:17 p. m.] **Tú:** Y otros esta como aburrida no se

[11:17 p. m.] **Tú:** Ta rara

[11:18 p. m.] **Vale 🌙:** Hay amor yo soy así aveses ni yo me entiendo

[11:18 p. m.] **Tú:** Pasame fotos de chiquita

[11:18 p. m.] **Tú:** Porfa

[11:18 p. m.] **Tú:**
> _Vale 🌙: Hay amor yo soy así aveses ni yo me entiendo_
Si no me habla

[11:18 p. m.] **Tú:** Raro

[11:18 p. m.] **Tú:** En donde queda la relación

[11:18 p. m.] **Tú:** Tus problemas, los podemos solucionar entre los dos un mal día etc

[11:19 p. m.] **Vale 🌙:** Esa muela ya me la habían calzado pero dejaron un algodón  dentro  y por eso se levantó la calza y con ella con pedazo de la  muela  hay me sacaron ese algon mañana me toca volver a ir a ver cómo avanza para que me la puedan sellar por que por la hinchazon no se puede hacer más hoy

[11:19 p. m.] **Tú:** Pero vos no te dejas dar ni amor

[11:19 p. m.] **Tú:** Ni na

[11:20 p. m.] **Vale 🌙:**
> _Tú: Tus problemas, los podemos solucionar entre los dos un mal día etc_
No esque tenga problemas todo el tiempo solo que aveses simplemente no quiero ablar o solo quiero dormir también soy muy distraída

[11:20 p. m.] **Vale 🌙:**
> _Tú: Pasame fotos de chiquita_
Voy amor pero tú también pásame tuyas

[11:21 p. m.] **Vale 🌙:**
> _Tú: O para hacer seguimiento_
Para ver si con el conducto la pueden repar si no toca estraerla

[11:21 p. m.] **Vale 🌙:**
> _Tú: Pero si quieres es un jueguito de pokemon re viejo kakaak_
Creo que ya sé cuál es mi mejor amigo es adicto a Pokémon pero la verdad amo casi no megusta

[11:26 p. m.] **Tú:** De los dos

[11:26 p. m.] **Tú:** Pasame

[11:26 p. m.] **Tú:** Porfa

[11:26 p. m.] **Tú:** Solo tengo como 5

[11:26 p. m.] **Vale 🌙:**
> _Tú: Dime 5 cosas que te gusten_
Chocolates , el morado , peluches , lirios gerberas girasoles  amo la mayoria de flores ,libros en específico poemas clichés y dark romans  las salchipapa los vestidos largos soy team dorado  los Busos largos las películas de humost y todo lo referente a al amor los dramas  la música bailar todo lo relacionado al arte los lugares solitarios pero con bonitas vistas y donde aya mucha naturaleza cosas de playa desde la música asta el mar

[11:26 p. m.] **Tú:** En este cel

[11:26 p. m.] **Tú:**
> _Vale 🌙: Chocolates , el morado , peluches , lirios gerberas girasoles  amo la mayoria de flores ,libros en específico poemas clichés y dark romans  las salchipapa los vestidos largos soy team dorado  los Busos largos las películas de humost y todo lo referente a al amor los dramas  la música bailar todo lo relacionado al arte los lugares solitarios pero con bonitas vistas y donde aya mucha naturaleza cosas de playa desde la música asta el mar_
Verga

[11:26 p. m.] **Tú:**
> _Vale 🌙: Chocolates , el morado , peluches , lirios gerberas girasoles  amo la mayoria de flores ,libros en específico poemas clichés y dark romans  las salchipapa los vestidos largos soy team dorado  los Busos largos las películas de humost y todo lo referente a al amor los dramas  la música bailar todo lo relacionado al arte los lugares solitarios pero con bonitas vistas y donde aya mucha naturaleza cosas de playa desde la música asta el mar_
Anotao

[11:27 p. m.] **Vale 🌙:**
> _Tú: Andas muy ocupada_
Eso te lo conteste en el medio minuto que estuve en el baño

[11:29 p. m.] **Tú:** https://vt.tiktok.com/ZSqrQsCfq/

[11:29 p. m.] **Tú:** No supe como jakakakakaka

[11:30 p. m.] **Tú:** No tenemos casi fotos

[11:30 p. m.] **Tú:** Bueno mientras tu me cuentas toda tu verdad

[11:31 p. m.] **Tú:** Me anotando unas cosas que necesito

[11:31 p. m.] **Tú:** Confiesese

[11:32 p. m.] **Vale 🌙:** [Mensaje de album]

[11:32 p. m.] **Vale 🌙:** [Imagen]

[11:32 p. m.] **Vale 🌙:** [Imagen]

[11:32 p. m.] **Vale 🌙:** [Imagen]

[11:33 p. m.] **Tú:**
> _Vale 🌙: [album]_
De ti no de tu hermana

[11:33 p. m.] **Tú:** Son idénticas

[11:34 p. m.] **Vale 🌙:** [Mensaje de album]

[11:34 p. m.] **Vale 🌙:** _Se eliminó este mensaje_

[11:34 p. m.] **Vale 🌙:** [Imagen]

[11:34 p. m.] **Vale 🌙:** [Imagen]

[11:34 p. m.] **Vale 🌙:** [Imagen]

[11:34 p. m.] **Vale 🌙:** [Imagen]

[11:34 p. m.] **Vale 🌙:** [Imagen]

[11:34 p. m.] **Vale 🌙:** [Imagen]

[11:34 p. m.] **Vale 🌙:** [Imagen]

[11:34 p. m.] **Vale 🌙:** [Imagen]

[11:34 p. m.] **Vale 🌙:** [Imagen]

[11:34 p. m.] **Vale 🌙:** [Imagen]

[11:34 p. m.] **Vale 🌙:** [Imagen]

[11:34 p. m.] **Vale 🌙:** [Imagen]

[11:38 p. m.] **Tú:**
> _Vale 🌙: [album]_
Quien es el pelado ese

[11:38 p. m.] **Tú:** Ya con eso mi bkda

[11:38 p. m.] **Tú:** Pero si tienes más pasalas

[11:38 p. m.] **Tú:**
> _Tú: Confiesese_
.....

[11:38 p. m.] **Tú:** Hable no pa que me ignore y se vaya pa otra aplicación

[11:39 p. m.] **Tú:** [Sticker]

[11:42 p. m.] **Vale 🌙:** [Mensaje de album]

[11:42 p. m.] **Vale 🌙:** [Imagen]

[11:42 p. m.] **Vale 🌙:** [Imagen]

[11:42 p. m.] **Vale 🌙:** [Imagen]

[11:42 p. m.] **Vale 🌙:** [Imagen]

[11:42 p. m.] **Vale 🌙:** [Imagen]

[11:42 p. m.] **Vale 🌙:** [Imagen]

[11:42 p. m.] **Vale 🌙:** [Imagen]

[11:42 p. m.] **Vale 🌙:** [Imagen]

[11:42 p. m.] **Vale 🌙:** [Imagen]

[11:42 p. m.] **Vale 🌙:**
> _Tú: Hable no pa que me ignore y se vaya pa otra aplicación_
Estaba robándome las fotos del Facebook viejo de mi mamá

[11:44 p. m.] **Vale 🌙:**
> _Tú: Quien es el pelado ese_
Es damian nosotros vimos en la misma casa en ese entonces nunca nos separabamos asta que su papá murió y ellos un día se mudaron h no volví a saber de le ni de su familia

[11:44 p. m.] **Vale 🌙:**
> _Tú: Confiesese_
Que quieres saber

[11:51 p. m.] **Vale 🌙:** Esas son todas las fotos que tengo básicamente sola

[11:51 p. m.] **Vale 🌙:** Tengo más pero estoy con mi herms familia y asi

[11:53 p. m.] **Tú:**
> _Vale 🌙: Que quieres saber_
Quien  eres tu, que te gusta, como te gusta 😏
Que es de tu vida, secretos que no te gusta decir detalles de tu vida quiero todo quien  eres porque actúas como si necesitaras más atención  de la que ya tienes, en amistad personal hombres mujeres, errores promesas cruces amores, decepciones,  y porque ocultas cosas, porque dices las cosas con que fin las dices que metas tienes tus ideas que manejas, sentimientos, dudas, igual sobre mi todo, cosas que no te dejan dormir, porque piensas en eso, tus deseos más más anhelados, todo esos detalles pequeños  que te hacen ser tu, los quiero todos, quiero saber quien es mi novia mi futura esposa y eso espero a que me enfrentó, y que consecuencias llevo, aquí en me estoy entregando ciegamente, yo quiero saber si lo entrego todo, a esa persona  que  esta inestable y poder hacer que todo pase por un buen camino y ser el apoyo de ella para todo

[11:55 p. m.] **Vale 🌙:** Esta conversación probablemente va ser de las más duras de mi vida pero estaba bien

[11:55 p. m.] **Vale 🌙:** Voy a tratar de hacer algo así como una autobiografía para ti

[11:56 p. m.] **Tú:** Lo digo es porque no sé cómo tratar contigo no sé cuándo estás bien o mal es difícil estar lejos de ti y no saber qué expresión o qué hacer

[11:57 p. m.] **Vale 🌙:** Soy claywis Valentina Torres Matta nací en Bogotá Colombia a las 10:30 PM un 22 de junio del 2006 mis padres me planearon y mi padre paso por distintas situaciones para poder tenerme llegando al punto de ir donde un brujo para darle algo o más o menos así me contó

[11:57 p. m.] **Tú:** Si está bien o mal que tal tú te estés esforzando por algo que solo siente uno o viseversa que yo me esté esforzando demás por algo que tú no ves o no quieres ver en ese momento

[11:59 p. m.] **Vale 🌙:** Quien soy es una pregunta que me ago diariamente sabes caos amor tranquilidad y locura soy una mezcla de todo lo que la vida me enseñó fragmentos de las mejores personas que me e encontrado  soy todo aquello que te hace dudar y te ase descifrar  soy una mezcla de culturas lugares y aromas

---

## 8 de septiembre de 2026

[12:01 a. m.] **Vale 🌙:** Es tenido mil trabajos como vender rifas cuidar niños ser ama de casa mesera florista administradora mandará el trabajado en  fruterías y por último ahora soy bar tender

[12:02 a. m.] **Vale 🌙:**
> _Tú: Si está bien o mal que tal tú te estés esforzando por algo que solo siente uno o viseversa que yo me esté esforzando demás por algo que tú no ves o no quieres ver en ese momento_
No amor no me esfuerzo amo ser yo contigo amo tus preguntas y responderlas solo que no estoy acostumbrada a esto

[12:11 a. m.] **Vale 🌙:** Desde pequeña mi vida no a sido color de rosas mi padre se fue cuando tenía 6 meses e busto a mi madre hacer todo por hacerme feliz desde entonces  primeramente para mi mi papá fue un amigo de mi mamá que siempre estuvo sin estarlo del todo me consintió mucho asta que se me tío con mi tía  cuando tenía más o menos 6 alguien me tocó es algo que asta la fecha no sabe ni mi mamá mi prefiero no ablar de eso  luegonmi mamá cuando tenía 8 conoció a mi padrastro desde hay mi vida cambió demaciado  el llegó siendo un buen hombre y luego se convirtió en mi peor pesadilla nos insiltaba le pegaba a mi mamá mi mama llegó a estar embaraza antes de mi hermana y lo perdió  Lugo se me tío con mi tía ya que mi amam se la trajo a vivir con nosotros para que terminara el colegio le fue infiel infinitas veces luego de que todos si pasara y muchas cosas más como amenazas unidas cambios de ciudades que me tratará de matar de diferentes maneras tanto ami  omo ami mamá y más que todo ami  a mis 15 me ofreció plata al decirle que no me mostró su ajam grité y conté todo estuve dos días en el bienestar cuando salí no podía vivir con mi mamá estuve en la costa con otra tía que me trataba fatal volví con mi mamá en ese mismo año pasaron mío cosas y decido irme a vivir con una amiga de mi amam hay empiezo a trabajar y conoci después de un tiempo a mi primer novio

[12:24 a. m.] **Tú:** Opino al final mi vida

[12:59 a. m.] **Tú:** Amor llevas rato escribiendo estas bien o te quedaste mimida

[1:06 a. m.] **Vale 🌙:** con el pasaron muchas primeras es veses y bueno después de unos meses que ya conocia a sierras personas se lo presente a la amiga de mi ama pasaron cosas y luego el se fue más lejos de lo que ya estaba durante ese lazotiempk  empeze a fumar y cree una especie de arter ego pues la versión que conocen la mayoría de personas es esa mujer indestructible que nada le afecta que no llora que no le importa jugar con las emociones de alguien más que no teme a ver el sufrimiento y si yo fui todo eso   pero cuando era el por más que se fuera volviera me restregar su felicidad luego me volviera a elegir luego jugara con migo y así así lo quieres con migo y mis emociones yo pues hay asta que por cosas de la vida y que tú ya sabes me metí con David termine luego viviendo con el las cosas entre nosotros nunca fueron tan románticas y luego terminamos  pero simpre estamos hay el uno para el otro pues el me enseñó mucho y yo a él básicamente más aya de tratar de ser mi pareja fue como un hermano mayor el supo lo de Daniel luego de un tiempo también que  yo solté a Daniel viviendo con el   luego te conocí de la manera más inesperada del mundo realmente me dijeron muchas cosas de ti pero aún así  avía algo en ti que me dieron ganas de conocerte( termine David como una semana antes de esa fiesta   cabe aclarar) bueno  algo en ti me daba curiosidad aunque sabie que tal vez solo querías sex por que también ya me lk avían dicho me valió madres y me empresate a gustar pero me daba miedo sentir  pero bueno   yo trabajaba lejos en ese entonces y ya te vía agrado cariño pues conocíychos de tus  gustos de tu forma de ser por que como siempre te lo e dicho eres increíble  nuestras comversaciones muchas iban  más aya de lo físico que es realmente lo que hace que pueda amar a alguien asta que  me mandaron esa foto y depue de eso decidí alejarme aunque por x o y motivo simpre terminábamos ablando con el  decidi auto convencerme de que no avía nada ya que me avian echo mucho daño en todos los sentidos después de mi primer novio tuve depresión y más porto lo que avía vivido en eses años tuve un bloqueo emocional para lo cual me recetaron anti depresivos y aprendí a fingir mis emociones según la situación  en la que estuviera  por lo cual nunca llegué a amar a David  aunque lo quise mucho y hay empecé a bañar con mucha gente luego por influencia  de personas que conocí me empecé a ablar con persona pero como para distraerme no sentía nada solo me gustaba su atención y eso reamet no pienso mucho lo que contesto ni lo que me dicen empecé a responder por inercia sabía que estaba mal pero me daba como lo mismo a eses cuando empecé con La.bloquie a medio mundo eliminé a todo mundo por que pues Quería un hogar con L pero no se pudo un pue se cuando terminamos me volvieron ablar y  era pura charla yo a
simpre estaba trabajando pero aveses me ponía a borrar cosas y no borraba por completo y se confundía con lo anterior  aunque realmente a salidas ni fui  (esos fue lo que viste cuando agarraste mi celular cabe aclar que para ese momento yo no sabía que me iba enamorar de ti y como tú no me respondías que eramamosny yo yo te amaba del todo todavía pues como que no me importó asta que me di cuenta que no te queeia peder y acepte que si sentía demás por ti  )por que mantenía trabajando eso sí salí con un pelao  antes de eso que me ablaba que antes estaba en España por que el se fue cuando resien nos conocimos  que fue más o menos cuando yo  termine con Daniel la primera  vez que fue la razón por la que Sheyla se alejó cuando ella en su momento también estuvo con un ex o bueno casi algo mío que actualmente es su novio  y ella con este pelao no tuvo nada asta le oregunte pero bueno  el día que la vimos por que el me dijo que para se algo serio y tal pero yo dije que no por que ajá no lo amaba ya volviendo a lo de Daniel puesnla futura también también  que me causo la anemia entre otras cosas también en ese año se me descubrieron los quistes  e tratado de matarme más o menos 4 veses creo   el resto más o menos ya lo sabes  luego volví a sentir mucho y me vine para Medellín  y pues hay ya te empecé a ver más como un amigo por que como que pues aparte del gusto tenía rotundamente decidido no enamorarme de ti por muchas cosas pero la más importabte no quería hacerte todo el daño que me isieron a mi y el mismo que le hice a las personas  que no ame luego conocí a Marlon con el salí unos meses  no estaba enamorada pero llamaba mi atención seguía pensando en ti aveses pero pues bueno no funcionen se me tío con otra frente a mi ama y pues ya  yo mantenía ocupada 24 7 trabajar estudiar etc mientras estudiaba conocí a L y bueno. Eso cambio toda mi forma de ver el amor más ya de que era un muy buen tipo literalmente elimino todas mis barreras aún sin tocarme un solo cabello   todo empezó por una pinche llamada  en clase me gustó su voz antes de eso yo avía soñado con alguien ablamos durante bastante tiempo  luego lo vi y pues era el mismo de mi sueño  después de vernos por primera  vez empezamos una realacion viajaba mucho a verlo y eso lo ame con todo lo sé soy el ya conocia todo de mi  asta que un día se fue y me dejó con el amor en las manos como en el pasado volví a recaer  y decidi volver a Bogotá a trabajar y salir de todo eso  pues bueno por cosas de la vida tu y yo empezamos a blar más de enuvi y volvimos a lo de siempre pero está vez  avía algo diferente  más ganas y una forma diferente  de verte no como antes está vez con menos lujuria pero más amor luego bueno me presentaste a tus amigos a tu mamá y nosé después de que deje de esconderme las cosas se pusieron más personales empecé a quererte serca a ablar mucho de ti sin darme cuenta a pensarte a querer analizar todo en ti  poco a poco todo lo que creía que avía ya no era a hora eras diferente o yo lo era nosé pero uno un punto en que simplemente ya no podía sontenelo te amaba y tenía que aceptarlo pero con ello venía la responsabilidad de cambiar y ser mejor que es lo que trato    cada día

[1:08 a. m.] **Vale 🌙:** Creo que hay partes donde salto y vuelvo por se me olvidaba algo pero creo que así es más o menos el orden  cronológicocreo nosé  por que estoy más dormida que despierta si necesitas saber algo más lo puedes preguntar siento que me faltan cosas pero es como un resumen

[1:12 a. m.] **Tú:**
> _Vale 🌙: Creo que hay partes donde salto y vuelvo por se me olvidaba algo pero creo que así es más o menos el orden  cronológicocreo nosé  por que estoy más dormida que despierta si necesitas saber algo más lo puedes preguntar siento que me faltan cosas pero es como un resumen_
No pues todo, ya estás en esa etapa de recordar

[1:12 a. m.] **Tú:** Suéltalo

[1:12 a. m.] **Tú:** Todo ese odio remordimiento que te come por dentro

[1:13 a. m.] **Tú:** Pensar de más es malo pero para alguien que no sabe cómo dejar ir

[1:13 a. m.] **Tú:** Eso es lo que yo veo en ti

[1:13 a. m.] **Vale 🌙:** Esque no recuerdo mucho estoy esque me duermo ahorita solo respondo preguntas

[1:13 a. m.] **Tú:**
> _Vale 🌙: Esque no recuerdo mucho estoy esque me duermo ahorita solo respondo preguntas_
Bueno para mañana tendrás el tiempo entonces

[1:13 a. m.] **Tú:** O otro día con esto hay cosas que me enredan

[1:14 a. m.] **Vale 🌙:**
> _Tú: Todo ese odio remordimiento que te come por dentro_
Pues ahorita no odio a nacer aunque en su momento quise matar a mi padrastro ahora siento que todo lo que me pasó por algo y algo aprendí

[1:14 a. m.] **Tú:** Bueno segun lo que entendí en este último texto tu primero novio fue tu trauma

[1:14 a. m.] **Tú:** Por cule poco de tiempo

[1:14 a. m.] **Tú:** Después fue David

[1:15 a. m.] **Tú:** El pelao este que estudió en el mismo que yo

[1:15 a. m.] **Tú:** Es lo que entiendo hasta el momento

[1:15 a. m.] **Tú:** Que él fue como un hermano pero no lo quisiste con ese afecto

[1:15 a. m.] **Tú:** Más allá

[1:15 a. m.] **Tú:** Lo de la fiesta no lo entendí

[1:15 a. m.] **Tú:** Es que dices que yo

[1:15 a. m.] **Tú:** Una foto

[1:15 a. m.] **Vale 🌙:**
> _Tú: El pelao este que estudió en el mismo que yo_
El no fue un trauma pero  no fui la mejor persona con el básicamente pago los platos rotos de mis emociones

[1:15 a. m.] **Tú:** Que eliminaste todo

[1:16 a. m.] **Tú:** Querías un hogar con quien

[1:16 a. m.] **Tú:** Eso me dejó x

[1:16 a. m.] **Vale 🌙:**
> _Tú: Una foto_
A bueno una miga de Sheyla meando una foto tuya con otra pela comiendo una vez acundo resien nos conocimos

[1:17 a. m.] **Vale 🌙:**
> _Tú: Eso me dejó x_
L es Lenin solo tiene en nombre complicado o bueno Santi

[1:18 a. m.] **Tú:**
> _Vale 🌙: con el pasaron muchas primeras es veses y bueno después de unos meses que ya conocia a sierras personas se lo presente a la amiga de mi ama pasaron cosas y luego el se fue más lejos de lo que ya estaba durante ese lazotiempk  empeze a fumar y cree una especie de arter ego pues la versión que conocen la mayoría de personas es esa mujer indestructible que nada le afecta que no llora que no le importa jugar con las emociones de alguien más que no teme a ver el sufrimiento y si yo fui todo eso   pero cuando era el por más que se fuera volviera me restregar su felicidad luego me volviera a elegir luego jugara con migo y así así lo quieres con migo y mis emociones yo pues hay asta que por cosas de la vida y que tú ya sabes me metí con David termine luego viviendo con el las cosas entre nosotros nunca fueron tan románticas y luego terminamos  pero simpre estamos hay el uno para el otro pues el me enseñó mucho y yo a él básicamente más aya de tratar de ser mi pareja fue como un hermano mayor el supo lo de Daniel luego de un tiempo también que  yo solté a Daniel viviendo con el   luego te conocí de la manera más inesperada del mundo realmente me dijeron muchas cosas de ti pero aún así  avía algo en ti que me dieron ganas de conocerte( termine David como una semana antes de esa fiesta   cabe aclarar) bueno  algo en ti me daba curiosidad aunque sabie que tal vez solo querías sex por que también ya me lk avían dicho me valió madres y me empresate a gustar pero me daba miedo sentir  pero bueno   yo trabajaba lejos en ese entonces y ya te vía agrado cariño pues conocíychos de tus  gustos de tu forma de ser por que como siempre te lo e dicho eres increíble  nuestras comversaciones muchas iban  más aya de lo físico que es realmente lo que hace que pueda amar a alguien asta que  me mandaron esa foto y depue de eso decidí alejarme aunque por x o y motivo simpre terminábamos ablando con el  decidi auto convencerme de que no avía nada ya que me avian echo mucho daño en todos los sentidos después de mi primer novio tuve depresión y más porto lo que avía vivido en eses años tuve un bloqueo emocional para lo cual me recetaron anti depresivos y aprendí a fingir mis emociones según la situación  en la que estuviera  por lo cual nunca llegué a amar a David  aunque lo quise mucho y hay empecé a bañar con mucha gente luego por influencia  de personas que conocí me empecé a ablar con persona pero como para distraerme no sentía nada solo me gustaba su atención y eso reamet no pienso mucho lo que contesto ni lo que me dicen empecé a responder por inercia sabía que estaba mal pero me daba como lo mismo a eses cuando empecé con La.bloquie a medio mundo eliminé a todo mundo por que pues Quería un hogar con L pero no se pudo un pue se cuando terminamos me volvieron ablar y  era pura charla yo a
simpre estaba trabajando pero aveses me ponía a borrar cosas y no borraba por completo y se confundía con lo anterior  aunque realmente a salidas ni fui  (esos fue lo que viste cuando agarraste mi celular cabe aclar que para ese momento yo no sabía que me iba enamorar de ti y como tú no me respondías que eramamosny yo yo te amaba del todo todavía pues como que no me importó asta que me di cuenta que no te queeia peder y acepte que si sentía demás por ti  )por que mantenía trabajando eso sí salí con un pelao  antes de eso que me ablaba que antes estaba en España por que el se fue cuando resien nos conocimos  que fue más o menos cuando yo  termine con Daniel la primera  vez que fue la razón por la que Sheyla se alejó cuando ella en su momento también estuvo con un ex o bueno casi algo mío que actualmente es su novio  y ella con este pelao no tuvo nada asta le oregunte pero bueno  el día que la vimos por que el me dijo que para se algo serio y tal pero yo dije que no por que ajá no lo amaba ya volviendo a lo de Daniel puesnla futura también también  que me causo la anemia entre otras cosas también en ese año se me descubrieron los quistes  e tratado de matarme más o menos 4 veses creo   el resto más o menos ya lo sabes  luego volví a sentir mucho y me vine para Medellín  y pues hay ya te empecé a ver más como un amigo por que como que pues aparte del gusto tenía rotundamente decidido no enamorarme de ti por muchas cosas pero la más importabte no quería hacerte todo el daño que me isieron a mi y el mismo que le hice a las personas  que no ame luego conocí a Marlon con el salí unos meses  no estaba enamorada pero llamaba mi atención seguía pensando en ti aveses pero pues bueno no funcionen se me tío con otra frente a mi ama y pues ya  yo mantenía ocupada 24 7 trabajar estudiar etc mientras estudiaba conocí a L y bueno. Eso cambio toda mi forma de ver el amor más ya de que era un muy buen tipo literalmente elimino todas mis barreras aún sin tocarme un solo cabello   todo empezó por una pinche llamada  en clase me gustó su voz antes de eso yo avía soñado con alguien ablamos durante bastante tiempo  luego lo vi y pues era el mismo de mi sueño  después de vernos por primera  vez empezamos una realacion viajaba mucho a verlo y eso lo ame con todo lo sé soy el ya conocia todo de mi  asta que un día se fue y me dejó con el amor en las manos como en el pasado volví a recaer  y decidi volver a Bogotá a trabajar y salir de todo eso  pues bueno por cosas de la vida tu y yo empezamos a blar más de enuvi y volvimos a lo de siempre pero está vez  avía algo diferente  más ganas y una forma diferente  de verte no como antes está vez con menos lujuria pero más amor luego bueno me presentaste a tus amigos a tu mamá y nosé después de que deje de esconderme las cosas se pusieron más personales empecé a quererte serca a ablar mucho de ti sin darme cuenta a pensarte a querer analizar todo en ti  poco a poco todo lo que creía que avía ya no era a hora eras diferente o yo lo era nosé pero uno un punto en que simplemente ya no podía sontenelo te amaba y tenía que aceptarlo pero con ello venía la responsabilidad de cambiar y ser mejor que es lo que trato    cada día_
Esta cronología de Medellín

[1:18 a. m.] **Tú:** El tal Daniel volvió varias veces

[1:18 a. m.] **Tú:** Por lo que veo

[1:19 a. m.] **Tú:** Quién es el de fusa

[1:19 a. m.] **Tú:** O cual

[1:19 a. m.] **Tú:** Y lo de que me ves como un amigo

[1:19 a. m.] **Tú:** Es actual

[1:19 a. m.] **Tú:** Jakaka

[1:19 a. m.] **Tú:**
> _Vale 🌙: A bueno una miga de Sheyla meando una foto tuya con otra pela comiendo una vez acundo resien nos conocimos_
Comiendo como así

[1:20 a. m.] **Vale 🌙:**
> _Tú: El tal Daniel volvió varias veces_
Miles y millones ata principios de este año que me dio que el mes paso de  el ejército pero lo bloqueé por que ese parchesito me lo pierdo

[1:20 a. m.] **Tú:** Como era o que

[1:20 a. m.] **Vale 🌙:**
> _Tú: Quién es el de fusa_
Lenin

[1:21 a. m.] **Vale 🌙:**
> _Tú: Y lo de que me ves como un amigo_
No  eso fue a principios antes de que me empezará a quedar en tu casa y era una forma de esquivar los sentimientos

[1:21 a. m.] **Tú:**
> _Vale 🌙: con el pasaron muchas primeras es veses y bueno después de unos meses que ya conocia a sierras personas se lo presente a la amiga de mi ama pasaron cosas y luego el se fue más lejos de lo que ya estaba durante ese lazotiempk  empeze a fumar y cree una especie de arter ego pues la versión que conocen la mayoría de personas es esa mujer indestructible que nada le afecta que no llora que no le importa jugar con las emociones de alguien más que no teme a ver el sufrimiento y si yo fui todo eso   pero cuando era el por más que se fuera volviera me restregar su felicidad luego me volviera a elegir luego jugara con migo y así así lo quieres con migo y mis emociones yo pues hay asta que por cosas de la vida y que tú ya sabes me metí con David termine luego viviendo con el las cosas entre nosotros nunca fueron tan románticas y luego terminamos  pero simpre estamos hay el uno para el otro pues el me enseñó mucho y yo a él básicamente más aya de tratar de ser mi pareja fue como un hermano mayor el supo lo de Daniel luego de un tiempo también que  yo solté a Daniel viviendo con el   luego te conocí de la manera más inesperada del mundo realmente me dijeron muchas cosas de ti pero aún así  avía algo en ti que me dieron ganas de conocerte( termine David como una semana antes de esa fiesta   cabe aclarar) bueno  algo en ti me daba curiosidad aunque sabie que tal vez solo querías sex por que también ya me lk avían dicho me valió madres y me empresate a gustar pero me daba miedo sentir  pero bueno   yo trabajaba lejos en ese entonces y ya te vía agrado cariño pues conocíychos de tus  gustos de tu forma de ser por que como siempre te lo e dicho eres increíble  nuestras comversaciones muchas iban  más aya de lo físico que es realmente lo que hace que pueda amar a alguien asta que  me mandaron esa foto y depue de eso decidí alejarme aunque por x o y motivo simpre terminábamos ablando con el  decidi auto convencerme de que no avía nada ya que me avian echo mucho daño en todos los sentidos después de mi primer novio tuve depresión y más porto lo que avía vivido en eses años tuve un bloqueo emocional para lo cual me recetaron anti depresivos y aprendí a fingir mis emociones según la situación  en la que estuviera  por lo cual nunca llegué a amar a David  aunque lo quise mucho y hay empecé a bañar con mucha gente luego por influencia  de personas que conocí me empecé a ablar con persona pero como para distraerme no sentía nada solo me gustaba su atención y eso reamet no pienso mucho lo que contesto ni lo que me dicen empecé a responder por inercia sabía que estaba mal pero me daba como lo mismo a eses cuando empecé con La.bloquie a medio mundo eliminé a todo mundo por que pues Quería un hogar con L pero no se pudo un pue se cuando terminamos me volvieron ablar y  era pura charla yo a
simpre estaba trabajando pero aveses me ponía a borrar cosas y no borraba por completo y se confundía con lo anterior  aunque realmente a salidas ni fui  (esos fue lo que viste cuando agarraste mi celular cabe aclar que para ese momento yo no sabía que me iba enamorar de ti y como tú no me respondías que eramamosny yo yo te amaba del todo todavía pues como que no me importó asta que me di cuenta que no te queeia peder y acepte que si sentía demás por ti  )por que mantenía trabajando eso sí salí con un pelao  antes de eso que me ablaba que antes estaba en España por que el se fue cuando resien nos conocimos  que fue más o menos cuando yo  termine con Daniel la primera  vez que fue la razón por la que Sheyla se alejó cuando ella en su momento también estuvo con un ex o bueno casi algo mío que actualmente es su novio  y ella con este pelao no tuvo nada asta le oregunte pero bueno  el día que la vimos por que el me dijo que para se algo serio y tal pero yo dije que no por que ajá no lo amaba ya volviendo a lo de Daniel puesnla futura también también  que me causo la anemia entre otras cosas también en ese año se me descubrieron los quistes  e tratado de matarme más o menos 4 veses creo   el resto más o menos ya lo sabes  luego volví a sentir mucho y me vine para Medellín  y pues hay ya te empecé a ver más como un amigo por que como que pues aparte del gusto tenía rotundamente decidido no enamorarme de ti por muchas cosas pero la más importabte no quería hacerte todo el daño que me isieron a mi y el mismo que le hice a las personas  que no ame luego conocí a Marlon con el salí unos meses  no estaba enamorada pero llamaba mi atención seguía pensando en ti aveses pero pues bueno no funcionen se me tío con otra frente a mi ama y pues ya  yo mantenía ocupada 24 7 trabajar estudiar etc mientras estudiaba conocí a L y bueno. Eso cambio toda mi forma de ver el amor más ya de que era un muy buen tipo literalmente elimino todas mis barreras aún sin tocarme un solo cabello   todo empezó por una pinche llamada  en clase me gustó su voz antes de eso yo avía soñado con alguien ablamos durante bastante tiempo  luego lo vi y pues era el mismo de mi sueño  después de vernos por primera  vez empezamos una realacion viajaba mucho a verlo y eso lo ame con todo lo sé soy el ya conocia todo de mi  asta que un día se fue y me dejó con el amor en las manos como en el pasado volví a recaer  y decidi volver a Bogotá a trabajar y salir de todo eso  pues bueno por cosas de la vida tu y yo empezamos a blar más de enuvi y volvimos a lo de siempre pero está vez  avía algo diferente  más ganas y una forma diferente  de verte no como antes está vez con menos lujuria pero más amor luego bueno me presentaste a tus amigos a tu mamá y nosé después de que deje de esconderme las cosas se pusieron más personales empecé a quererte serca a ablar mucho de ti sin darme cuenta a pensarte a querer analizar todo en ti  poco a poco todo lo que creía que avía ya no era a hora eras diferente o yo lo era nosé pero uno un punto en que simplemente ya no podía sontenelo te amaba y tenía que aceptarlo pero con ello venía la responsabilidad de cambiar y ser mejor que es lo que trato    cada día_
Quién es o

[1:21 a. m.] **Tú:** L

[1:21 a. m.] **Vale 🌙:**
> _Tú: L_
Lenin

[1:23 a. m.] **Tú:**
> _Vale 🌙: con el pasaron muchas primeras es veses y bueno después de unos meses que ya conocia a sierras personas se lo presente a la amiga de mi ama pasaron cosas y luego el se fue más lejos de lo que ya estaba durante ese lazotiempk  empeze a fumar y cree una especie de arter ego pues la versión que conocen la mayoría de personas es esa mujer indestructible que nada le afecta que no llora que no le importa jugar con las emociones de alguien más que no teme a ver el sufrimiento y si yo fui todo eso   pero cuando era el por más que se fuera volviera me restregar su felicidad luego me volviera a elegir luego jugara con migo y así así lo quieres con migo y mis emociones yo pues hay asta que por cosas de la vida y que tú ya sabes me metí con David termine luego viviendo con el las cosas entre nosotros nunca fueron tan románticas y luego terminamos  pero simpre estamos hay el uno para el otro pues el me enseñó mucho y yo a él básicamente más aya de tratar de ser mi pareja fue como un hermano mayor el supo lo de Daniel luego de un tiempo también que  yo solté a Daniel viviendo con el   luego te conocí de la manera más inesperada del mundo realmente me dijeron muchas cosas de ti pero aún así  avía algo en ti que me dieron ganas de conocerte( termine David como una semana antes de esa fiesta   cabe aclarar) bueno  algo en ti me daba curiosidad aunque sabie que tal vez solo querías sex por que también ya me lk avían dicho me valió madres y me empresate a gustar pero me daba miedo sentir  pero bueno   yo trabajaba lejos en ese entonces y ya te vía agrado cariño pues conocíychos de tus  gustos de tu forma de ser por que como siempre te lo e dicho eres increíble  nuestras comversaciones muchas iban  más aya de lo físico que es realmente lo que hace que pueda amar a alguien asta que  me mandaron esa foto y depue de eso decidí alejarme aunque por x o y motivo simpre terminábamos ablando con el  decidi auto convencerme de que no avía nada ya que me avian echo mucho daño en todos los sentidos después de mi primer novio tuve depresión y más porto lo que avía vivido en eses años tuve un bloqueo emocional para lo cual me recetaron anti depresivos y aprendí a fingir mis emociones según la situación  en la que estuviera  por lo cual nunca llegué a amar a David  aunque lo quise mucho y hay empecé a bañar con mucha gente luego por influencia  de personas que conocí me empecé a ablar con persona pero como para distraerme no sentía nada solo me gustaba su atención y eso reamet no pienso mucho lo que contesto ni lo que me dicen empecé a responder por inercia sabía que estaba mal pero me daba como lo mismo a eses cuando empecé con La.bloquie a medio mundo eliminé a todo mundo por que pues Quería un hogar con L pero no se pudo un pue se cuando terminamos me volvieron ablar y  era pura charla yo a
simpre estaba trabajando pero aveses me ponía a borrar cosas y no borraba por completo y se confundía con lo anterior  aunque realmente a salidas ni fui  (esos fue lo que viste cuando agarraste mi celular cabe aclar que para ese momento yo no sabía que me iba enamorar de ti y como tú no me respondías que eramamosny yo yo te amaba del todo todavía pues como que no me importó asta que me di cuenta que no te queeia peder y acepte que si sentía demás por ti  )por que mantenía trabajando eso sí salí con un pelao  antes de eso que me ablaba que antes estaba en España por que el se fue cuando resien nos conocimos  que fue más o menos cuando yo  termine con Daniel la primera  vez que fue la razón por la que Sheyla se alejó cuando ella en su momento también estuvo con un ex o bueno casi algo mío que actualmente es su novio  y ella con este pelao no tuvo nada asta le oregunte pero bueno  el día que la vimos por que el me dijo que para se algo serio y tal pero yo dije que no por que ajá no lo amaba ya volviendo a lo de Daniel puesnla futura también también  que me causo la anemia entre otras cosas también en ese año se me descubrieron los quistes  e tratado de matarme más o menos 4 veses creo   el resto más o menos ya lo sabes  luego volví a sentir mucho y me vine para Medellín  y pues hay ya te empecé a ver más como un amigo por que como que pues aparte del gusto tenía rotundamente decidido no enamorarme de ti por muchas cosas pero la más importabte no quería hacerte todo el daño que me isieron a mi y el mismo que le hice a las personas  que no ame luego conocí a Marlon con el salí unos meses  no estaba enamorada pero llamaba mi atención seguía pensando en ti aveses pero pues bueno no funcionen se me tío con otra frente a mi ama y pues ya  yo mantenía ocupada 24 7 trabajar estudiar etc mientras estudiaba conocí a L y bueno. Eso cambio toda mi forma de ver el amor más ya de que era un muy buen tipo literalmente elimino todas mis barreras aún sin tocarme un solo cabello   todo empezó por una pinche llamada  en clase me gustó su voz antes de eso yo avía soñado con alguien ablamos durante bastante tiempo  luego lo vi y pues era el mismo de mi sueño  después de vernos por primera  vez empezamos una realacion viajaba mucho a verlo y eso lo ame con todo lo sé soy el ya conocia todo de mi  asta que un día se fue y me dejó con el amor en las manos como en el pasado volví a recaer  y decidi volver a Bogotá a trabajar y salir de todo eso  pues bueno por cosas de la vida tu y yo empezamos a blar más de enuvi y volvimos a lo de siempre pero está vez  avía algo diferente  más ganas y una forma diferente  de verte no como antes está vez con menos lujuria pero más amor luego bueno me presentaste a tus amigos a tu mamá y nosé después de que deje de esconderme las cosas se pusieron más personales empecé a quererte serca a ablar mucho de ti sin darme cuenta a pensarte a querer analizar todo en ti  poco a poco todo lo que creía que avía ya no era a hora eras diferente o yo lo era nosé pero uno un punto en que simplemente ya no podía sontenelo te amaba y tenía que aceptarlo pero con ello venía la responsabilidad de cambiar y ser mejor que es lo que trato    cada día_
La última parte ajá

[1:23 a. m.] **Tú:** Está suave jajajaa

[1:23 a. m.] **Tú:**
> _Vale 🌙: Lenin_
No mija muchos novios

[1:23 a. m.] **Tú:** Yo te voy a decir algo oféndase o no es mi punto de vista

[1:24 a. m.] **Vale 🌙:**
> _Tú: Yo te voy a decir algo oféndase o no es mi punto de vista_
Hay mi vida a este punto ya casi nada me ofende

[1:24 a. m.] **Tú:** A ti te da miedo eliminar todos los videos y recuerdos que tienes de tus ex parejas verdad

[1:24 a. m.] **Tú:** Eso lo noté hace mucho mucho tiempo

[1:24 a. m.] **Tú:** Borras pero vuelves a guardar

[1:24 a. m.] **Tú:** Es un patrón que no dejas de hacer

[1:24 a. m.] **Tú:**
> _Vale 🌙: Hay mi vida a este punto ya casi nada me ofende_
Puta

[1:25 a. m.] **Tú:** Ahhh Tiris

[1:25 a. m.] **Tú:** Jajaja

[1:26 a. m.] **Tú:** Ese miedo que se le forma en la cara cuando alguien ve algo privando tuyo es arte, porque sabes que está mal para ti tener eso ahí pero lo dejas pensando que nadie se va a dar cuenta

[1:26 a. m.] **Vale 🌙:**
> _Tú: A ti te da miedo eliminar todos los videos y recuerdos que tienes de tus ex parejas verdad_
No es miedo es como costumbre  sabes  aveses  me gusta tener como esos recuerdos porque pues independiente de fui feliz peor si en algún momento deseas que no tenga nada por mi está bien

[1:27 a. m.] **Vale 🌙:**
> _Tú: Ese miedo que se le forma en la cara cuando alguien ve algo privando tuyo es arte, porque sabes que está mal para ti tener eso ahí pero lo dejas pensando que nadie se va a dar cuenta_
No es que no se den cuenta es que simplemente es algo no me molesta tener ya que pues en mi defensa estaba sola

[1:28 a. m.] **Tú:** Yo sé que tu eres una mujer, derecha que ya tiene sus planes puede que a futuro no realizados, pero a corto sabes lo que necesitas, pero soltar mija, la que se daña es utd misma, yo aprendí algo con los años y es la gente no sabe lo que tiene hasta que lo pierde, y lo pierde sabes como con costumbre, ay si yo hago esto y no me dice nada no me importa

[1:28 a. m.] **Vale 🌙:** Es muy diferente ahora por que ahora te veo diferente yo te amo Andrés y en ese orden de ideas áre los que sea para que estés tranquilo en cuanto a ese tipo de cosas se trate

[1:30 a. m.] **Vale 🌙:** Yo ahora quiero hacer las cosas bien en contigo y el resto se puede morir si quiere

[1:30 a. m.] **Tú:** A eso voy tú te detuviste me imagino yo cuando tuve tu teléfono en que pensara si tengo videos de amor como otros muchachos, si le digo bb a otro cosa que ya lo eh dicho varias veces no cabe volverlo a decir. 
Yo como consejo te digo bloquea y elimina yo antes pensaba que si no lo hacía me iba a dar igual con elimina tiempo mentira dure 4 años así bueno como 2 y uno con tormentos de que es difícil  dejar algo un nombre o un objeto que se dejó cuando estuvieron esos sentimientos

[1:31 a. m.] **Vale 🌙:** Yo se que tienes una imagen cuestionable de mi y pues saber todo esto no lo ayuda pero  en realidad quiero  mejorar

[1:32 a. m.] **Tú:** Pero te lo aconsejo vas a dormir mejor en las noches mira lo que tienes alrededor no es mucho lo sé pero te sientes mal, serías capaz de cambiar eso por un comentario una persona o una mala decisión y volver a donde ya sabes que duras en salir

[1:32 a. m.] **Tú:** Deja de atormentanter no tienes que pensar el algo que no te hace bien yo se lo que digo

[1:33 a. m.] **Vale 🌙:**
> _Tú: A eso voy tú te detuviste me imagino yo cuando tuve tu teléfono en que pensara si tengo videos de amor como otros muchachos, si le digo bb a otro cosa que ya lo eh dicho varias veces no cabe volverlo a decir. 
Yo como consejo te digo bloquea y elimina yo antes pensaba que si no lo hacía me iba a dar igual con elimina tiempo mentira dure 4 años así bueno como 2 y uno con tormentos de que es difícil  dejar algo un nombre o un objeto que se dejó cuando estuvieron esos sentimientos_
Obviamente ya no lo ago claramente fue duro básicamente birara meses entreyos de mi vida no tenlo voy a negar pero si de algo estoy segura esque hay que botar el pasado para sostener el futuro

[1:33 a. m.] **Tú:** Yo sé que tú tienes más que solo lo que quise mirar porque es tu vida son tus sentimientos y lo que está dentro de tu corazón es lo que vale

[1:34 a. m.] **Tú:** Bueno el ejemplo más reciente que tengo para decirte y ya lo sabes, yo con clara

[1:35 a. m.] **Tú:** Mk yo con ella fui la más mierda, porque no la entendí, hasta que ella se fue mk se me fue todo problemas con mi mamá se empezaron a morir personas a las que les brinde mis sentimientos y pensamientos

[1:35 a. m.] **Tú:** Horrible yo sigo diciendo esa mujer fue el karma a todo lo que no hice bien en una relación

[1:36 a. m.] **Tú:** Este año tome la decisión de dejarla

[1:37 a. m.] **Tú:** Porque no porque me dañara me dieron yo con ella después de eso hablamos muy poco pero yo nunca le di entrada y ella nunca me dio salida

[1:37 a. m.] **Vale 🌙:**
> _Tú: Horrible yo sigo diciendo esa mujer fue el karma a todo lo que no hice bien en una relación_
Si el karma existe el mío Lenin ami se murieron mi abuelos tíos me quedé sin trabajo sin plata en otra ciudad perdí a la amistad que más amaba que era Sheyla en eso me gane de enemiga a mi mamá

[1:38 a. m.] **Vale 🌙:** Por eso ya borré todo eliminé todo por que no quiero perderte Ati

[1:39 a. m.] **Vale 🌙:** Quiero hacer las cosas con Tigo mejor de como las hice con el y si no funciona pues bueno pero no quiero perder otra vez a alguien que amo

[1:39 a. m.] **Tú:** Me di cuenta de que ya era hora fue por unas instantáneas que montó, todo lo que yo le di a esa mujer que yo pensé que estaba en la basura subió las primeras cosas que le di. Mk eso me partió el alma eso y yo me apegue a ella por una cuestión con mi mamá pero eso ya es aparte, pero mk yo que me mataba la cabeza viendo la feliz de viaje tin allá ella con sus métodos Jajajaaj pero todo lo que pensé que no iba a existir estaba, claro el que se estaban haciendo el daño era yo

[1:39 a. m.] **Tú:** La dejé

[1:39 a. m.] **Tú:** Desde ese día mk descansé full

[1:40 a. m.] **Tú:**
> _Vale 🌙: Por eso ya borré todo eliminé todo por que no quiero perderte Ati_
[Sticker]

[1:40 a. m.] **Tú:** Pa ver muéstrame una teta

[1:40 a. m.] **Tú:** A ver si es verdad

[1:40 a. m.] **Vale 🌙:** Jsjsjs amor

[1:40 a. m.] **Vale 🌙:** Ya voy

[1:40 a. m.] **Tú:**
> _Vale 🌙: Quiero hacer las cosas con Tigo mejor de como las hice con el y si no funciona pues bueno pero no quiero perder otra vez a alguien que amo_
Suena feo sabes

[1:41 a. m.] **Tú:** Tú estás mal para el amor

[1:41 a. m.] **Tú:** Tú no sabes si confíar o desconfiar

[1:41 a. m.] **Tú:** Por eso le das entradas a más gente

[1:41 a. m.] **Tú:** Eso veo yo

[1:41 a. m.] **Vale 🌙:**
> _Tú: Suena feo sabes_
Aver no me refiero necesariamente a un amor romántico me refiero a que me importas

[1:41 a. m.] **Tú:** Y lo demuestras incluido

[1:41 a. m.] **Tú:**
> _Vale 🌙: Aver no me refiero necesariamente a un amor romántico me refiero a que me importas_
No

[1:41 a. m.] **Tú:** Analiza bien lo que dijiste

[1:43 a. m.] **Vale 🌙:** Tu eres más aya de alguien me me encanta eres alguien  que. Aprecio yo contigo puedo ser yo misma y aunque calle aveses simpre quiero ablar con Tigo y mejorar eres un increíble amigo hijo todo como hombre se que ahorita no te puedo dar la mejor relación del mundo  pero me esfuerzo para ser mejor de lo que soy hoy

[1:44 a. m.] **Tú:**
> _Vale 🌙: Tu eres más aya de alguien me me encanta eres alguien  que. Aprecio yo contigo puedo ser yo misma y aunque calle aveses simpre quiero ablar con Tigo y mejorar eres un increíble amigo hijo todo como hombre se que ahorita no te puedo dar la mejor relación del mundo  pero me esfuerzo para ser mejor de lo que soy hoy_
Yo sé mi vida

[1:44 a. m.] **Tú:** Pero no paraste bolas a lo que te dije

[1:44 a. m.] **Vale 🌙:** Tu eres como si fuera mi familia literalmente aparte de mi mamá y mi hermana eres todo lo que me queda

[1:44 a. m.] **Vale 🌙:**
> _Tú: Tú no sabes si confíar o desconfiar_
Pues ahora estoy confiando

[1:44 a. m.] **Tú:** Y segundo mija para mañana ni un hombre en esas redes como así que tiene hombres

[1:44 a. m.] **Tú:** Eggvjsjsjsjs

[1:45 a. m.] **Tú:** Tiris

[1:45 a. m.] **Vale 🌙:**
> _Vale 🌙: Pues ahora estoy confiando_
En ti ya no quiero conocer a nadie más la verdad como tú dices por mucho tiempo le di entrada a personas que no tenía que hacerlo

[1:45 a. m.] **Tú:** Sigo viendo comentarios que no me gustan

[1:45 a. m.] **Tú:** Ya ahorita te digo porque

[1:45 a. m.] **Tú:** Pero síguele

[1:46 a. m.] **Vale 🌙:** Que comentarios amor

[1:46 a. m.] **Tú:** Tanto me ama que no pone wifi pa jugar

[1:46 a. m.] **Tú:** Jsjsj

[1:46 a. m.] **Vale 🌙:** Yo sin internet ni redes e mirado

[1:46 a. m.] **Tú:** Yo sé que eso es más fastidioso

[1:46 a. m.] **Tú:** Relaz

[1:46 a. m.] **Tú:**
> _Vale 🌙: Que comentarios amor_
Mira para que puedas descansar ya

[1:47 a. m.] **Tú:**
> _Vale 🌙: Quiero hacer las cosas con Tigo mejor de como las hice con el y si no funciona pues bueno pero no quiero perder otra vez a alguien que amo_
Comparar relaciónes pasadas

[1:47 a. m.] **Tú:** Mija eso todavía le pesa allá en el fondo

[1:47 a. m.] **Tú:** No está mal

[1:47 a. m.] **Tú:** Pero ajá todo a su tiempo

[1:48 a. m.] **Tú:** Pero es tus palabras se deja ver lo que te pesa así no te des cuenta

[1:49 a. m.] **Tú:** Ombe yo sé que Mario bueno no soy

[1:49 a. m.] **Vale 🌙:** Pues amor cómo te digo yo estoy confiando en que esto salga bien pero aún me queda  miedo de mi ahorita literalmente me siento caminado en la cuerda floja no quiero hacer nada que pueda poner en riesgo lo que quiero con Tigo

[1:49 a. m.] **Tú:** Pero no soy tan hp para que desconfíe de mijajajssjajska

[1:50 a. m.] **Tú:**
> _Vale 🌙: Tu eres más aya de alguien me me encanta eres alguien  que. Aprecio yo contigo puedo ser yo misma y aunque calle aveses simpre quiero ablar con Tigo y mejorar eres un increíble amigo hijo todo como hombre se que ahorita no te puedo dar la mejor relación del mundo  pero me esfuerzo para ser mejor de lo que soy hoy_
Que me des teta no significa que sea hijo tuyo

[1:50 a. m.] **Tú:** Najajaajajs

[1:50 a. m.] **Tú:** Yo creo que tú das lo que crees necesario

[1:50 a. m.] **Tú:** Porque lo digo

[1:50 a. m.] **Tú:** Tus cambios de actitud son muy bruscos

[1:50 a. m.] **Tú:** Y es fácil de entender

[1:51 a. m.] **Tú:** Cuando estás full enamorada estás ahí

[1:51 a. m.] **Tú:** Que mandando miles de cosas

[1:51 a. m.] **Tú:** Contando que pasó que hizo

[1:51 a. m.] **Tú:** Donde fuiste

[1:52 a. m.] **Tú:** Llega un punto donde ya no sabes ni qué decir

[1:52 a. m.] **Tú:** Eso lo conozco bastante bien

[1:52 a. m.] **Tú:** Pero cuando no tienes esa conexión tan fuerte

[1:52 a. m.] **Tú:** Se aleja

[1:52 a. m.] **Vale 🌙:** [Sticker]

[1:52 a. m.] **Tú:** Te doy la prueba

[1:53 a. m.] **Vale 🌙:** Me acabas de dar en toda la madre pero es verdad

[1:53 a. m.] **Tú:** Mira los chats de antes de que te fueras a estos días era la misma situación mismas personas diferente conexión

[1:54 a. m.] **Tú:**
> _Vale 🌙: Tu eres como si fuera mi familia literalmente aparte de mi mamá y mi hermana eres todo lo que me queda_
Como así que te queda mija yo que soy pokemon tuyo

[1:54 a. m.] **Tú:**
> _Vale 🌙: Pues ahora estoy confiando_
Ósea no sabes si esto sea verdad o no

[1:54 a. m.] **Tú:** Claro se nota

[1:54 a. m.] **Vale 🌙:** Pero en realidad nisiquiera es eso siento que si te doy ya de manera exagera cariño te sobre cargo pues así creo yo

[1:55 a. m.] **Tú:**
> _Vale 🌙: En ti ya no quiero conocer a nadie más la verdad como tú dices por mucho tiempo le di entrada a personas que no tenía que hacerlo_
Eres tú

[1:55 a. m.] **Tú:** Esa que deja entrar por miedo a perder otra vez

[1:55 a. m.] **Tú:** Eres tú

[1:55 a. m.] **Tú:** Por eso te dije quién eres

[1:55 a. m.] **Tú:** A qué me enfrento

[1:55 a. m.] **Tú:** Y a quien le debo de tener

[1:55 a. m.] **Tú:** Temer

[1:55 a. m.] **Tú:** Tu

[1:55 a. m.] **Vale 🌙:** Por que muchas veses no esque no te quira contar nada esque no hay nada o no que yo me de cuenta porque están tan como en mi misma y tan agotada que solo quiero respirar trabajar y dormír

[1:56 a. m.] **Tú:**
> _Vale 🌙: Quiero hacer las cosas con Tigo mejor de como las hice con el y si no funciona pues bueno pero no quiero perder otra vez a alguien que amo_
Tú sigues dándome dos respuestas

[1:56 a. m.] **Tú:** Si te pido algo siempre me dices el lado negativo

[1:56 a. m.] **Tú:** Y si no funciona bueno

[1:57 a. m.] **Tú:** Claro es fácil dar lo que creas necesario hasta que se acabe

[1:57 a. m.] **Tú:** Está muy mal acostumbrada

[1:57 a. m.] **Tú:** A que solo das en momentos muy cercanos y cuando sientes que se va acabar

[1:57 a. m.] **Vale 🌙:** Esque amor osea hay semanas y días en los que voy ablar mucho voy a mandar fotos y voy a estar hay pero hay días en los que simplemente no quiero mover ningún pie

[1:57 a. m.] **Tú:** De resto respondamos como sea que hp

[1:57 a. m.] **Tú:** Igual se va acabar

[1:57 a. m.] **Tú:** Eso piensas

[1:58 a. m.] **Vale 🌙:** No

[1:58 a. m.] **Tú:**
> _Vale 🌙: Pero en realidad nisiquiera es eso siento que si te doy ya de manera exagera cariño te sobre cargo pues así creo yo_
Mija entonces todo lo que estabas diciendo que

[1:58 a. m.] **Tú:** Por conveniencia

[1:58 a. m.] **Tú:** Para que este tipo sea crea que creo en el

[1:58 a. m.] **Vale 🌙:** Amor yo quiero pero hay veses que realmente nosé ni que decir

[1:58 a. m.] **Tú:** Más arriba me decías que podías ser tú

[1:58 a. m.] **Tú:** Que pasó ahí

[1:59 a. m.] **Tú:** Entonces no eres 100% tu

[1:59 a. m.] **Tú:** Eres una imagen que me estás vendiendo

[1:59 a. m.] **Vale 🌙:** Realmente hay días en los que no Ago nada ni me tomo fotos ni nada literalmente aveses es toy en modo atumatico

[1:59 a. m.] **Tú:**
> _Vale 🌙: Por que muchas veses no esque no te quira contar nada esque no hay nada o no que yo me de cuenta porque están tan como en mi misma y tan agotada que solo quiero respirar trabajar y dormír_
Bueno dilo

[1:59 a. m.] **Tú:** Ya se dio cuenta que pendiente si estoy

[2:00 a. m.] **Vale 🌙:** Pero esque que por eso te digo yo con Tigo soy yo y esto soy yo aveses soy todo y aveses simplemente nada estoy flotando

[2:00 a. m.] **Tú:** No sé un oe ñero así como dices tú

[2:00 a. m.] **Tú:** Ando re cansada hablamos después

[2:00 a. m.] **Tú:**
> _Vale 🌙: Esque amor osea hay semanas y días en los que voy ablar mucho voy a mandar fotos y voy a estar hay pero hay días en los que simplemente no quiero mover ningún pie_
Como todo mundo

[2:01 a. m.] **Tú:** Descubriste que no eres diferente a nadie y tienes sentimientos

[2:01 a. m.] **Tú:** Y no tienes que estar muerta para saber lo

[2:01 a. m.] **Tú:**
> _Vale 🌙: Amor yo quiero pero hay veses que realmente nosé ni que decir_
Bueno

[2:01 a. m.] **Tú:** Ya sabes que hacer

[2:01 a. m.] **Tú:** Algo verás que te subiera los ánimos

[2:01 a. m.] **Tú:** O te dejará enviar así sea un mensaje de ando tal

[2:02 a. m.] **Vale 🌙:** Esta bien mi vida

[2:02 a. m.] **Tú:** Y no quiero hablar mucho

[2:02 a. m.] **Tú:** Cuando este mejor te escribo

[2:02 a. m.] **Tú:** No de

[2:02 a. m.] **Tú:** Vos verás

[2:02 a. m.] **Vale 🌙:** Me está doliendo la porra

[2:02 a. m.] **Vale 🌙:** Auch

[2:02 a. m.] **Tú:** Mucho pensar

[2:02 a. m.] **Tú:** Bueno vaya elimine todo eso

[2:02 a. m.] **Tú:** De sus fotos

[2:02 a. m.] **Tú:** Traumada

[2:03 a. m.] **Tú:** Todo de todo

[2:03 a. m.] **Tú:** Sin copias de nada

[2:03 a. m.] **Tú:** Ya pasó

[2:03 a. m.] **Tú:** Y utd está en otro momento de su vida no pensando en gente que ya no piensa en utd

[2:03 a. m.] **Vale 🌙:** No cielo esque me dolió la muela

[2:03 a. m.] **Vale 🌙:** Y eso también me da dolor de cabeza

[2:03 a. m.] **Tú:**
> _Vale 🌙: Y eso también me da dolor de cabeza_
Ahh pos obvio

[2:03 a. m.] **Tú:** Las pastas

[2:04 a. m.] **Tú:** Que te dieron que

[2:04 a. m.] **Tú:** Tomate una y a dormir

[2:04 a. m.] **Vale 🌙:** Ya me las tomé

[2:04 a. m.] **Tú:** Bueno relaja la quijada que bien tensa si la debe de tener

[2:05 a. m.] **Tú:** Y no me explico de la foto de yo

[2:05 a. m.] **Tú:** Comiendo

[2:05 a. m.] **Tú:** Eso cuando fue

[2:05 a. m.] **Tú:** Jajaja

[2:05 a. m.] **Vale 🌙:** Jsjd 💋

[2:05 a. m.] **Vale 🌙:** Ni me cuerdo solo te vi y te la tomé

[2:06 a. m.] **Tú:** Pero fue acá en bogota

[2:06 a. m.] **Tú:** Verga

[2:06 a. m.] **Tú:** No me acuerdo

[2:06 a. m.] **Tú:** Fue cerca del colegio o qué

[2:06 a. m.] **Tú:** Con uniforme

[2:06 a. m.] **Tú:** Estoy haciendo cálculos pero no se

[2:06 a. m.] **Vale 🌙:** Estabas en el Quirigua

[2:06 a. m.] **Tú:** Donde

[2:06 a. m.] **Vale 🌙:** Hay en eso donde venden como picada

[2:06 a. m.] **Tú:** Picada

[2:07 a. m.] **Tú:** Como así

[2:07 a. m.] **Tú:** Jajajaaj

[2:07 a. m.] **Vale 🌙:**
> _Tú: Con uniforme_
No normal

[2:07 a. m.] **Tú:** Explíquese que vio y donde

[2:08 a. m.] **Vale 🌙:**
> _Tú: Explíquese que vio y donde_
Estabas básicamente a punto de besarla la pelada era flaquita

[2:08 a. m.] **Tú:**
> _Vale 🌙: Estabas básicamente a punto de besarla la pelada era flaquita_
Que

[2:08 a. m.] **Tú:** Como así

[2:08 a. m.] **Tú:** Solo éramos los dos

[2:08 a. m.] **Tú:** O no se dio cuenta

[2:10 a. m.] **Tú:** Las descripciones no me dan

[2:12 a. m.] **Vale 🌙:** Estas tú y ella  es más la foto me la mandó Valeria la novia de Miguel que fue la que nos lleva la fiesta asta un vídeo me mandó en ese momento

[2:13 a. m.] **Tú:**
> _Vale 🌙: Estas tú y ella  es más la foto me la mandó Valeria la novia de Miguel que fue la que nos lleva la fiesta asta un vídeo me mandó en ese momento_
Noo

[2:13 a. m.] **Tú:** No se

[2:13 a. m.] **Vale 🌙:**
> _Vale 🌙: Estas tú y ella  es más la foto me la mandó Valeria la novia de Miguel que fue la que nos lleva la fiesta asta un vídeo me mandó en ese momento_
Y yo a bueno y hay me empecé a poner rara

[2:13 a. m.] **Tú:** Pero esas descripciones

[2:14 a. m.] **Tú:** No dan no dan

[2:14 a. m.] **Tú:** Yo saliendo a comer raro primero

[2:14 a. m.] **Tú:** Y solo

[2:14 a. m.] **Tú:** Y segundo solo

[2:14 a. m.] **Vale 🌙:**
> _Tú: Y solo_
Solo no con la pelada esa

[2:14 a. m.] **Tú:** No recuerdo ósea si pero eso fue con una pelada del colegio y fue para que le párala bolas a un pelado del salón

[2:14 a. m.] **Vale 🌙:** Y ni me pregunté más que ya me dio fue rabia

[2:15 a. m.] **Tú:** Y fue frente al colegio

[2:15 a. m.] **Tú:** Dónde hacer pizzzas

[2:15 a. m.] **Tú:** De resto solos

[2:15 a. m.] **Tú:** No

[2:15 a. m.] **Tú:** Te acuerda de la cara

[2:15 a. m.] **Tú:** O no

[2:15 a. m.] **Vale 🌙:** Andrés vea valla a dormir más bien que ya me emputa de recordar

[2:16 a. m.] **Tú:**
> _Vale 🌙: Andrés vea valla a dormir más bien que ya me emputa de recordar_
Jajaakakakaka

[2:16 a. m.] **Tú:** Pero me dejó con la duda

[2:16 a. m.] **Vale 🌙:** Hasta mañana amor

[2:16 a. m.] **Tú:** Perese que ni yo sabía eso

[2:16 a. m.] **Tú:** Ahhhhhh

[2:16 a. m.] **Vale 🌙:**
> _Tú: Perese que ni yo sabía eso_
Hay deje la estupides que yo eso ya se lo avía dicho

[2:16 a. m.] **Tú:**
> _Vale 🌙: Hay deje la estupides que yo eso ya se lo avía dicho_
No

[2:17 a. m.] **Tú:** hasta ahorita que me dices

[2:17 a. m.] **Vale 🌙:** [Sticker]

[2:17 a. m.] **Tú:** _Eliminaste este mensaje._

[2:17 a. m.] **Tú:** Esa no

[2:17 a. m.] **Vale 🌙:** Ya me dio más dolor de cabeza

[2:18 a. m.] **Tú:**
> _Vale 🌙: Ya me dio más dolor de cabeza_
Mira pa ver

[2:18 a. m.] **Tú:** Si no pa hechar cabeza

[2:18 a. m.] **Tú:** Pero dijiste flaca

[2:18 a. m.] **Tú:** Y ella no es

[2:18 a. m.] **Vale 🌙:**
> _Tú: Mira pa ver_
Nosé por qué solo se ve el pelo y en la otra la mitad de cara

[2:18 a. m.] **Tú:** No se

[2:19 a. m.] **Tú:** Eso pa cuando fue

[2:20 a. m.] **Vale 🌙:** Asta mañana me toca ir hoy otra vez donde el médico y no e dormido un culo y mañana me toca Adra el cierre

[2:20 a. m.] **Tú:** Jajajajaaja

[2:20 a. m.] **Vale 🌙:** Descansa mi amor lindo

[2:20 a. m.] **Tú:** Toda braca

[2:20 a. m.] **Tú:** Va descansa mi vida

[2:20 a. m.] **Tú:** Besos

[2:20 a. m.] **Tú:** En esos limones

[11:20 a. m.] **Tú:** Tonces

[11:21 a. m.] **Tú:** Ya ni habla

[11:21 a. m.] **Tú:** Que andas haciendo mi reina buenos días

[11:22 a. m.] **Vale 🌙:** [Mensaje de voz]

[11:23 a. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Pues si ya es como lo veas mejor

[11:23 a. m.] **Tú:** Y que andas haciendo

[11:23 a. m.] **Tú:** Que la escucho como atareada

[11:24 a. m.] **Vale 🌙:** [Mensaje de voz]

[11:24 a. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Jajajaja dormir todo el día

[11:25 a. m.] **Tú:** Y eso donde andas

[11:25 a. m.] **Tú:** Severo ventarrón

[11:25 a. m.] **Vale 🌙:** [Mensaje de voz]

[11:26 a. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Que va

[11:26 a. m.] **Tú:** Eso es suave por allá

[11:26 a. m.] **Tú:** Hay haces fotosíntesis

[11:26 a. m.] **Tú:** Ósea vas para el metro

[11:26 a. m.] **Vale 🌙:** [Mensaje de voz]

[11:26 a. m.] **Tú:** O para el Tito

[11:26 a. m.] **Tú:** Luego no habías contratado otra

[11:27 a. m.] **Vale 🌙:**
> _Tú: Ósea vas para el metro_
[Mensaje de voz]

[11:28 a. m.] **Vale 🌙:** [Mensaje de voz]

[11:29 a. m.] **Vale 🌙:** [Mensaje de voz]

[11:31 a. m.] **Vale 🌙:** [Mensaje de voz]

[11:42 a. m.] **Vale 🌙:** Me ando comiendo una dona del tamaño de mi cara

[11:42 a. m.] **Vale 🌙:** Tenis un antojo jsjs

[11:43 a. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Jum a cloro

[11:43 a. m.] **Tú:** Utd donde estaba metida Valentina

[11:43 a. m.] **Tú:** Por hay dicen que el semen deja un tufo a cloro

[11:43 a. m.] **Tú:** [Sticker]

[11:43 a. m.] **Vale 🌙:**
> _Tú: Por hay dicen que el semen deja un tufo a cloro_
Que putas

[11:44 a. m.] **Vale 🌙:** [Mensaje de voz]

[11:44 a. m.] **Tú:**
> _Vale 🌙: Me ando comiendo una dona del tamaño de mi cara_
Como así

[11:44 a. m.] **Tú:** Pa ver

[11:44 a. m.] **Tú:** Jajaja

[11:44 a. m.] **Tú:**
> _Vale 🌙: Tenis un antojo jsjs_
Antojo

[11:44 a. m.] **Vale 🌙:** [Mensaje de voz]

[11:44 a. m.] **Tú:** [Sticker]

[11:44 a. m.] **Tú:** Utd con antojos

[11:44 a. m.] **Tú:** Jum

[11:44 a. m.] **Vale 🌙:** [Imagen]

[11:44 a. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Clarooo

[11:45 a. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Yo también

[11:45 a. m.] **Tú:** Voy a ver si como ya jajaja

[11:45 a. m.] **Tú:**
> _Vale 🌙: Imagen_
Pelaa con plata

[11:45 a. m.] **Tú:** Me vas a prestar pa sacar un play

[11:45 a. m.] **Vale 🌙:**
> _Tú: Pelaa con plata_
Ojara me acabo de mecatiar los pasajes de mañana

[11:45 a. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Entras hoy que a las 5

[11:46 a. m.] **Tú:** Tienes tiempo de ir al internet

[11:46 a. m.] **Vale 🌙:**
> _Tú: Entras hoy que a las 5_
Sii

[11:46 a. m.] **Tú:** Y al banco nada mas

[11:46 a. m.] **Tú:**
> _Vale 🌙: Ojara me acabo de mecatiar los pasajes de mañana_
Jaasjsjsjs

[11:46 a. m.] **Tú:** Que utd tiene mucha plata

[11:46 a. m.] **Tú:** Qué días que le revise el Nequi tenia500

[11:46 a. m.] **Tú:** Y me pasé 10

[11:46 a. m.] **Vale 🌙:**
> _Tú: Tienes tiempo de ir al internet_
Que mi mamá ayer metió la plata del Inter en el otro bolso 🙄

[11:46 a. m.] **Vale 🌙:** Ahora me toca hacer esa vaina el viernes

[11:47 a. m.] **Vale 🌙:** Porque yo mañana no quiero salir

[11:47 a. m.] **Tú:**
> _Vale 🌙: Que mi mamá ayer metió la plata del Inter en el otro bolso 🙄_
Como así

[11:47 a. m.] **Tú:** Jajajaj

[11:47 a. m.] **Tú:** Ósea no vas a ir

[11:47 a. m.] **Tú:** Verga tons para el banc o

[11:47 a. m.] **Tú:** Vas mandando foto

[11:47 a. m.] **Tú:** Pa ver si es verdad

[11:47 a. m.] **Tú:** [Sticker]

[11:47 a. m.] **Tú:** [Sticker]

[11:47 a. m.] **Vale 🌙:**
> _Tú: Qué días que le revise el Nequi tenia500_
No si ojara  con 500 ya ubiera arreglado el celular

[11:47 a. m.] **Vale 🌙:**
> _Tú: Verga tons para el banc o_
Si

[11:48 a. m.] **Tú:**
> _Vale 🌙: No si ojara  con 500 ya ubiera arreglado el celular_
Ke

[11:48 a. m.] **Tú:** Luego no lo quieras cambiar

[11:48 a. m.] **Vale 🌙:** Oiga ese stiker dios mío Andrés

[11:48 a. m.] **Tú:** Igual ahí ta funcionando bien

[11:48 a. m.] **Tú:** Que peleas

[11:48 a. m.] **Tú:**
> _Vale 🌙: Oiga ese stiker dios mío Andrés_
Que

[11:48 a. m.] **Tú:** De puro amor

[11:48 a. m.] **Tú:** Malo si uno le hace sticker

[11:48 a. m.] **Vale 🌙:**
> _Tú: Ke_
[Mensaje de voz]

[11:48 a. m.] **Tú:** Como no soy sus amigas a las que se come si le molesta

[11:49 a. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Ahh no mija venda eso y coja uno

[11:49 a. m.] **Vale 🌙:** [Mensaje de voz]

[11:49 a. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Y cuál es el que quiere

[11:49 a. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Si no tengo más

[11:49 a. m.] **Vale 🌙:** [Mensaje de voz]

[11:49 a. m.] **Tú:** Y vos nunca te tomabas fotos con migo

[11:50 a. m.] **Tú:** Claro como le da pena

[11:50 a. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Yo tengo tengo un chamchum

[11:50 a. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
No se

[11:50 a. m.] **Tú:** Cuál es

[11:50 a. m.] **Tú:** Me imantó que debe de de un s20

[11:50 a. m.] **Tú:** Creo yo

[11:51 a. m.] **Vale 🌙:** [Mensaje de voz]

[11:51 a. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Que mentira

[11:51 a. m.] **Tú:** En qué celular están esas fotos en el mío

[11:51 a. m.] **Tú:** Porque en el suyo no hay nada mío

[11:51 a. m.] **Tú:** Todo el amor me tocaba darlo amo

[11:51 a. m.] **Vale 🌙:** [Mensaje de voz]

[11:51 a. m.] **Tú:** Aveces pienso que soy el único que pelea por esta relación

[11:51 a. m.] **Vale 🌙:**
> _Tú: En qué celular están esas fotos en el mío_
[Mensaje de voz]

[11:51 a. m.] **Tú:** 😭

[11:52 a. m.] **Tú:** [Sticker]

[11:52 a. m.] **Vale 🌙:** [Mensaje de voz]

[11:52 a. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Mande foto

[11:52 a. m.] **Tú:** Pa ver si me robo uno

[11:52 a. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Le da igual jajaakak

[11:52 a. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Pero porque se las paso

[11:52 a. m.] **Tú:** No porque las haya pasado

[11:52 a. m.] **Tú:** A tramar a otro

[11:53 a. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Chismosa

[11:53 a. m.] **Vale 🌙:** [Mensaje de voz]

[11:53 a. m.] **Tú:** Bueno metase en un baño y me manda una foto

[11:53 a. m.] **Tú:** Quiero tirar paja

[11:53 a. m.] **Tú:** Y pa eso sos mi mujer

[11:53 a. m.] **Vale 🌙:** [Mensaje de voz]

[11:53 a. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Donde

[11:53 a. m.] **Tú:** A ver

[11:53 a. m.] **Tú:** Mande foto de la galería donde diga cámara

[11:53 a. m.] **Tú:** Y que aparezcan fotos de los dos ahí

[11:53 a. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Busque

[11:54 a. m.] **Tú:** Mami resuelva

[11:55 a. m.] **Tú:** [Imagen]

[11:55 a. m.] **Tú:** Así

[11:56 a. m.] **Vale 🌙:** [Imagen] Y por hay hay más

[11:56 a. m.] **Tú:**
> _Vale 🌙: Imagen: Y por hay hay más_
Eso el Google

[11:56 a. m.] **Tú:** Fotos

[11:56 a. m.] **Tú:** Tan mentirosa

[11:56 a. m.] **Vale 🌙:** [Mensaje de voz]

[11:56 a. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Si

[11:56 a. m.] **Tú:** La del celular

[11:58 a. m.] **Tú:** [Mensaje de album]

[11:58 a. m.] **Tú:** [Imagen]

[11:58 a. m.] **Tú:** [Imagen]

[11:58 a. m.] **Tú:** [Imagen]

[11:58 a. m.] **Tú:** [Imagen]

[11:58 a. m.] **Tú:** [Imagen]

[11:59 a. m.] **Vale 🌙:** [Imagen]

[11:59 a. m.] **Vale 🌙:** [Mensaje de voz]

[12:03 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Que

[12:03 p. m.] **Tú:** Esas me las tomé yo

[12:03 p. m.] **Tú:** No cuenta

[12:03 p. m.] **Tú:** Jajajaaj

[12:04 p. m.] **Tú:** Tengo por hay unos pichando me tocó con esos

[12:04 p. m.] **Vale 🌙:** Estan en mi celular 😝

[12:04 p. m.] **Tú:**
> _Vale 🌙: Estan en mi celular 😝_
Que

[12:04 p. m.] **Tú:** Jajajaaja

[12:04 p. m.] **Tú:** Pues claro

[12:04 p. m.] **Vale 🌙:**
> _Tú: Tengo por hay unos pichando me tocó con esos_
Hay dios mío

[12:05 p. m.] **Tú:** [Imagen]

[12:05 p. m.] **Tú:** Ese

[12:05 p. m.] **Tú:** O cual

[12:05 p. m.] **Tú:**
> _Vale 🌙: Hay dios mío_
Rico

[12:05 p. m.] **Tú:** Como dese que se fue

[12:05 p. m.] **Tú:** Ya no lo quiere hacer

[12:05 p. m.] **Tú:** Toda grosera

[12:05 p. m.] **Tú:** Tocó con los recuerdos

[12:07 p. m.] **Vale 🌙:**
> _Tú: O cual_
No

[12:07 p. m.] **Tú:**
> _Vale 🌙: No_
Verga tons cual es

[12:07 p. m.] **Tú:** Porque Samsung de resto los viejos porque cual más

[12:08 p. m.] **Vale 🌙:**
> _Tú: Porque Samsung de resto los viejos porque cual más_
Es viejo

[12:08 p. m.] **Tú:**
> _Vale 🌙: Es viejo_
A utd le gustan los viejos ahí está

[12:08 p. m.] **Tú:** de dónde saca tanta plata

[12:08 p. m.] **Vale 🌙:** Solo que yo lo quiero es el z clip sus algo así

[12:08 p. m.] **Tú:** [Sticker]

[12:08 p. m.] **Tú:**
> _Vale 🌙: Solo que yo lo quiero es el z clip sus algo así_
Z que

[12:08 p. m.] **Tú:** Jajakaakskssksk

[12:08 p. m.] **Tú:** Ahh pero el nuevo

[12:08 p. m.] **Tú:** Z flip

[12:08 p. m.] **Tú:** Jajajaks

[12:08 p. m.] **Tú:** Ese es chévere

[12:09 p. m.] **Tú:** Pero ese si es de cuidar mucho

[12:09 p. m.] **Tú:** Es re delicado

[12:09 p. m.] **Vale 🌙:** Si ete

[12:09 p. m.] **Vale 🌙:** [Imagen]

[12:10 p. m.] **Vale 🌙:**
> _Tú: Pero ese si es de cuidar mucho_
Si obio

[12:10 p. m.] **Tú:** Verga pero el 8

[12:10 p. m.] **Tú:** Porque no el primero que salió

[12:10 p. m.] **Tú:** Es Melo

[12:10 p. m.] **Tú:** esos ya se pasan de caro

[12:11 p. m.] **Tú:** Bueno ahí miramos cómo le hacemos después

[12:11 p. m.] **Tú:** Pero si me va a dar culito o no

[12:11 p. m.] **Vale 🌙:** [Mensaje de voz]

[12:12 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
88

[12:12 p. m.] **Tú:** Jum

[12:12 p. m.] **Tú:** Convecinas

[12:12 p. m.] **Tú:** Jajajaj

[12:12 p. m.] **Tú:** Y el de Motorola no te gusta

[12:12 p. m.] **Tú:** Es el mismo pero sale mucho más barato

[12:12 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Si me vas a dar culito

[12:12 p. m.] **Tú:** Cuando

[12:12 p. m.] **Tú:** Pa viajar enseguida

[12:13 p. m.] **Vale 🌙:** [Mensaje de voz]

[12:13 p. m.] **Vale 🌙:**
> _Tú: Si me vas a dar culito_
Noo

[12:14 p. m.] **Tú:**
> _Vale 🌙: Noo_
Y porque no

[12:14 p. m.] **Tú:** Gorsera

[12:14 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Toca mirar

[12:14 p. m.] **Tú:** A ver si consigo chamba le ayudo

[12:14 p. m.] **Tú:** Pa que lo saque

[12:14 p. m.] **Tú:** Yo que ando más limpio me dan crédito de 100 palos por hay

[12:14 p. m.] **Tú:** Ahh jajajaaja

[12:14 p. m.] **Vale 🌙:** Jsjdjd

[12:14 p. m.] **Vale 🌙:**
> _Tú: Gorsera_
Por que no quiero

[12:15 p. m.] **Tú:** [Imagen]

[12:15 p. m.] **Tú:**
> _Vale 🌙: Por que no quiero_
Pero yo si

[12:15 p. m.] **Tú:** Utd no me quiere verdad

[12:16 p. m.] **Vale 🌙:**
> _Tú: Utd no me quiere verdad_
Eso no tiene nada que ver

[12:16 p. m.] **Vale 🌙:**
> _Tú: Imagen_
Si ya bonito

[12:17 p. m.] **Tú:**
> _Vale 🌙: Eso no tiene nada que ver_
Como que no

[12:17 p. m.] **Tú:** Es una prueba mas

[12:17 p. m.] **Tú:** De nuestro amor

[12:17 p. m.] **Tú:**
> _Vale 🌙: Si ya bonito_
Si le gustó o no

[12:17 p. m.] **Tú:** Nakaakakak

[12:17 p. m.] **Tú:** Eso no convence

[12:17 p. m.] **Tú:** Bueno igual toca que se aguante un poquitito

[12:18 p. m.] **Vale 🌙:**
> _Tú: Si le gustó o no_
Sii pero en otro color ese naranja never

[12:18 p. m.] **Tú:**
> _Vale 🌙: Sii pero en otro color ese naranja never_
Jajajaaj ahh

[12:18 p. m.] **Vale 🌙:**
> _Tú: De nuestro amor_
Nop  eso solo cuando me casé

[12:18 p. m.] **Tú:** Pues ese si lo podemos sacar de una vez

[12:18 p. m.] **Tú:** Mándeme una foto en tanga ta

[12:18 p. m.] **Tú:** Y se lo compro

[12:19 p. m.] **Tú:**
> _Vale 🌙: Nop  eso solo cuando me casé_
Si ya estamos casado

[12:19 p. m.] **Vale 🌙:**
> _Tú: Si ya estamos casado_
No me refiero a oficial mente a la iglesia

[12:20 p. m.] **Tú:**
> _Vale 🌙: No me refiero a oficial mente a la iglesia_
Ahh no quiere por el civil

[12:20 p. m.] **Tú:** Que grosera

[12:20 p. m.] **Tú:** Bueno vamos mañana

[12:20 p. m.] **Tú:** Pero mañana mismos me lo da

[12:20 p. m.] **Vale 🌙:**
> _Tú: Ahh no quiere por el civil_
No se me hace tan bonito

[12:20 p. m.] **Tú:**
> _Vale 🌙: No se me hace tan bonito_
Como que no

[12:21 p. m.] **Tú:** Más privado

[12:21 p. m.] **Tú:** Como vas

[12:21 p. m.] **Tú:** Ya mucho seso

[12:21 p. m.] **Tú:** Utd solo me quiere por mi pilin

[12:21 p. m.] **Tú:** Mande foto pa ver que está haciendo

[12:21 p. m.] **Tú:** [Sticker]

[12:21 p. m.] **Vale 🌙:** [Mensaje de voz]

[12:21 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Sí claro

[12:21 p. m.] **Tú:** Hasta no ver no creer

[12:22 p. m.] **Vale 🌙:** [Mensaje de video]

[12:22 p. m.] **Vale 🌙:**
> _Tú: Utd solo me quiere por mi pilin_
Obviamente no

[12:22 p. m.] **Tú:**
> _Vale 🌙: Mensaje de video_
Y porque no me mandó un pico

[12:22 p. m.] **Tú:** Ya no le gusto verdad

[12:22 p. m.] **Tú:** Voy a comer si no me da la palida

[12:22 p. m.] **Vale 🌙:**
> _Tú: Más privado_
Ose si pero no me gustan los lugar  yo quiero fotos bonitas y un vestido te

[12:22 p. m.] **Tú:**
> _Vale 🌙: Ose si pero no me gustan los lugar  yo quiero fotos bonitas y un vestido te_
Ahhh

[12:22 p. m.] **Tú:** Hubiera empezado por a ti

[12:23 p. m.] **Tú:** Ahí

[12:23 p. m.] **Tú:** 6 años y me caso

[12:23 p. m.] **Tú:** Ahí ya

[12:23 p. m.] **Vale 🌙:** Esta bien

[12:23 p. m.] **Tú:**
> _Vale 🌙: Esta bien_
Tons

[12:23 p. m.] **Tú:** Como es para hacer el apareamiento virtual

[12:23 p. m.] **Tú:** Mi amor

[12:23 p. m.] **Tú:** [Sticker]

[12:23 p. m.] **Vale 🌙:** Jsjsj cielo

[12:24 p. m.] **Vale 🌙:** Óyeme que estoy en la calle

[12:24 p. m.] **Tú:** Que lo vea todo mundo

[12:24 p. m.] **Tú:** Que vos si pichas rico no como esos lambones

[12:25 p. m.] **Tú:** [Sticker]

[12:25 p. m.] **Vale 🌙:** Amor 😳

[12:26 p. m.] **Tú:** Hablamos al rato que voy a calentar el almuerzo, y el pene no me da para sostener el teléfono tanto tiempo

[12:26 p. m.] **Tú:** Amenos de que me mandes una fotico bien bonita de su cara mi amor

[12:26 p. m.] **Vale 🌙:** Jsjsjs está bien amor mio

[12:34 p. m.] **Tú:** No me quieres chupar el pene

[12:34 p. m.] **Tú:** [Sticker]

[12:35 p. m.] **Vale 🌙:**
> _Tú: No me quieres chupar el pene_
[Mensaje de voz]

[12:35 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Que dijo al final

[12:35 p. m.] **Tú:** Jajakaka

[12:36 p. m.] **Tú:** Pero si o no

[12:36 p. m.] **Tú:** Eso no responde la pregunta

[12:36 p. m.] **Tú:** Cuanto vale el pasaje para que venga entonces

[12:37 p. m.] **Vale 🌙:** [Mensaje de voz]

[12:38 p. m.] **Tú:** Porque tu eres la que conoce ambas ciudades

[12:38 p. m.] **Tú:** Jajajaaj

[12:38 p. m.] **Vale 🌙:** [Mensaje de voz]

[12:39 p. m.] **Tú:** [Mensaje de voz]

[12:41 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
[Mensaje de voz]

[12:44 p. m.] **Vale 🌙:** [Mensaje de voz]

[12:45 p. m.] **Vale 🌙:** [Mensaje de voz]

[12:45 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Pero eso es un si para que vaya o  un no quédese en bogota

[12:45 p. m.] **Tú:** No lo quiero aca

[12:46 p. m.] **Tú:** Si utd me dice yo voy

[12:46 p. m.] **Tú:** Ya la decisión es suya

[12:46 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
Aver

[12:46 p. m.] **Tú:** Donde  estas sudando

[12:46 p. m.] **Tú:** Yo voy y se la lambo

[12:48 p. m.] **Vale 🌙:** [Mensaje de voz]

[12:49 p. m.] **Vale 🌙:** [Mensaje de voz]

[12:58 p. m.] **Vale 🌙:** [Mensaje de voz]

[12:59 p. m.] **Vale 🌙:** [Video]

[1:00 p. m.] **Tú:**
> _Vale 🌙: Mensaje de voz_
[Mensaje de voz]

[1:02 p. m.] **Vale 🌙:** Esta bien amor mio  si puedes cuando quieras venir me avisas y ya

[1:02 p. m.] **Vale 🌙:** Si creo yo por eso me vine  el trabajo aya está fatal

[1:08 p. m.] **Tú:**
> _Vale 🌙: Video_
Hp que rico

[1:08 p. m.] **Tú:** Se lo puedo ir a meter en el baño del banco

[1:08 p. m.] **Tú:** Mi amor utd esta muy rica

[1:08 p. m.] **Tú:** [Mensaje de voz]

[1:10 p. m.] **Vale 🌙:** [Mensaje de voz]

[3:17 p. m.] **Tú:** [Imagen]

[3:18 p. m.] **Tú:** [Mensaje de voz]

[3:18 p. m.] **Tú:** [Video]

[4:56 p. m.] **Vale 🌙:**
> _Tú: Imagen_
Tan chévere

[4:57 p. m.] **Vale 🌙:**
> _Tú: Mensaje de voz_
A bueno amor

[4:57 p. m.] **Vale 🌙:** Ya voy a entrar a trabajar

[4:57 p. m.] **Vale 🌙:** [Video]

[5:27 p. m.] **Vale 🌙:** [Imagen]

[11:13 p. m.] **Tú:** Holii

[11:13 p. m.] **Tú:** Amor como vas

[11:14 p. m.] **Tú:** Me acabo de levantar

[11:14 p. m.] **Tú:** Jajajaaj

[11:14 p. m.] **Vale 🌙:** Ya voy a salir

[11:14 p. m.] **Tú:** Llegué re muerto

[11:14 p. m.] **Tú:** Como te fue

[11:14 p. m.] **Tú:**
> _Vale 🌙: Imagen_
Algo diferente con postre

[11:14 p. m.] **Tú:** Que rico

[11:14 p. m.] **Tú:**
> _Vale 🌙: Video_
Y esa mamasota

[11:14 p. m.] **Tú:** Cuál es

[11:14 p. m.] **Tú:** Estás como negra

[11:15 p. m.] **Tú:** Mucho sol

[11:15 p. m.] **Tú:** Y sudada

[11:15 p. m.] **Tú:** Avisas cuando estés en la casita entonces

[11:56 p. m.] **Vale 🌙:** Ya amor esque llegué a almorzar por que está ese no me comí lo que me dieron completo

[11:56 p. m.] **Vale 🌙:**
> _Tú: Estás como negra_
Yk te dije

[11:57 p. m.] **Tú:**
> _Vale 🌙: Ya amor esque llegué a almorzar por que está ese no me comí lo que me dieron completo_
Ya llegaste

[11:57 p. m.] **Tú:** Verga y esa demora

[11:57 p. m.] **Vale 🌙:**
> _Tú: Ya llegaste_
Si amor. Que me puse able con mi aman y almorzar un poquito

[11:57 p. m.] **Tú:**
> _Vale 🌙: Yk te dije_
Así está linda

[11:57 p. m.] **Tú:** Acaramelada

[11:57 p. m.] **Tú:** Como la cebolla

[11:57 p. m.] **Vale 🌙:** Ksjsbsj

[11:57 p. m.] **Tú:** Me hace llorar pero cuando me la como que rica que está

[11:57 p. m.] **Tú:** Como dice Puerto Rico

[11:58 p. m.] **Tú:**
> _Vale 🌙: Si amor. Que me puse able con mi aman y almorzar un poquito_
Almorzar

[11:58 p. m.] **Tú:** O cenar

[11:58 p. m.] **Tú:** Tu mamá hasta qué hora trabaja

[11:58 p. m.] **Vale 🌙:**
> _Tú: Tu mamá hasta qué hora trabaja_
Normalmente astas las 4

[11:59 p. m.] **Vale 🌙:** Aveses asta más tarde pero simpre le pagan lo mismo

---

## 9 de septiembre de 2026

[12:02 a. m.] **Tú:**
> _Vale 🌙: Normalmente astas las 4_
Ella sale tu entras

[12:02 a. m.] **Tú:** Y tu hermana como le hacen

[12:02 a. m.] **Tú:** Estudia muy lejos o que

[12:02 a. m.] **Tú:**
> _Vale 🌙: Aveses asta más tarde pero simpre le pagan lo mismo_
Uy no

[12:03 a. m.] **Tú:** Tu mamá como puede hacer es o

[12:03 a. m.] **Tú:** Ósea durar más por el mismo pago

[12:03 a. m.] **Vale 🌙:** Pues yo la recojo y de hay salgo para el trabajo

[12:03 a. m.] **Vale 🌙:** Cuando entro temprano le mandamos una moto

[12:03 a. m.] **Vale 🌙:** O el novio de mi mamá la recoje

[12:05 a. m.] **Tú:**
> _Vale 🌙: Cuando entro temprano le mandamos una moto_
A quien a tu hermana o a tu mami

[12:05 a. m.] **Tú:** Pero igual ella sabe llegar ya sola a la casa no

[12:05 a. m.] **Tú:** Tu hermana

[12:08 a. m.] **Vale 🌙:**
> _Tú: A quien a tu hermana o a tu mami_
A mi hermana

[12:08 a. m.] **Vale 🌙:** Si pero ami mi mamá no le gusta

[12:23 a. m.] **Tú:**
> _Vale 🌙: A mi hermana_
Y tu mami se va sola o la lleva el marido

[12:23 a. m.] **Tú:** Ella trabaja por sectores lo que me dijiste la otra vez

[12:23 a. m.] **Tú:** Ósea también trabaja así

[12:23 a. m.] **Tú:** Si le toca quedarme ma tiempo por el mismo valor lo hace

[12:23 a. m.] **Tú:** Supongo que para Martener el trabajo

[12:23 a. m.] **Tú:** Así le toca muy duro la verdad

[12:24 a. m.] **Tú:** Y que te dice tu mami al respecto

[12:24 a. m.] **Tú:**
> _Vale 🌙: Si pero ami mi mamá no le gusta_
Pero ya debería de ir siendo hora

[12:24 a. m.] **Tú:** Más que todo porque es una carga económica más

[12:24 a. m.] **Tú:** Estar en esa llevadera

[12:25 a. m.] **Tú:** A cómo lo veo yo no sé qué opinas tú

[12:25 a. m.] **Tú:** Eso le serviría al mes para ahorrar un poco más

[12:26 a. m.] **Tú:** Ella que vende ropa quiere hacer su floristería

[12:26 a. m.] **Tú:** Para más materia les

[12:26 a. m.] **Tú:** Lo visual del local

[12:26 a. m.] **Tú:** Y eso que no me mandaste foto cuando llegaste

[12:26 a. m.] **Tú:** [Sticker]

[12:29 a. m.] **Tú:** Ahh pero todavía no llegas a la casa yo pensé que si

[12:41 a. m.] **Tú:** Descansa bb

[12:41 a. m.] **Tú:** Hablamos mañana

[12:41 a. m.] **Tú:** Ten lindos sueños

[12:58 a. m.] **Vale 🌙:**
> _Tú: Y que te dice tu mami al respecto_
No pues varses que queda por que se marcha aya

[12:58 a. m.] **Vale 🌙:**
> _Tú: Sticker_
Por que todos están durmiendo y la verdad se me olvidó

[12:59 a. m.] **Vale 🌙:**
> _Tú: Ahh pero todavía no llegas a la casa yo pensé que si_
Hace ratos estoy en la casa amor

[4:27 p. m.] **Tú:** Hola mi niña como estás

[4:27 p. m.] **Tú:** Ya despertaste o qué

[4:28 p. m.] **Tú:** Acabo de llegar a la casa

[4:28 p. m.] **Tú:** _Eliminaste este mensaje._

[4:29 p. m.] **Tú:** Cómo te fue en tu día de descanso

[4:29 p. m.] **Tú:**
> _Vale 🌙: No pues varses que queda por que se marcha aya_
Que

[4:29 p. m.] **Tú:**
> _Vale 🌙: Por que todos están durmiendo y la verdad se me olvidó_
Aja

[4:29 p. m.] **Tú:** Se le están perdiendo las costumbres

[4:30 p. m.] **Tú:**
> _Vale 🌙: Hace ratos estoy en la casa amor_
Mmm

[4:30 p. m.] **Tú:** [Imagen]

[4:30 p. m.] **Tú:** Así me aparece últimamente

[4:31 p. m.] **Tú:** _Eliminaste este mensaje._

[5:51 p. m.] **Tú:** Dónde andas

[6:07 p. m.] **Vale 🌙:** Más abajoto del trabajo de mi mama

[6:14 p. m.] **Tú:** Y eso que andas haciendo  por alla

[6:28 p. m.] **Vale 🌙:** [Imagen]

[6:29 p. m.] **Vale 🌙:** Estaba comprando unos platos que faltaban

[6:45 p. m.] **Tú:** Dale me avisas cuando estés libre

[6:45 p. m.] **Tú:** Quiero hablar algo

[6:49 p. m.] **Vale 🌙:** Vale amor

[7:25 p. m.] **Vale 🌙:**
> _Tú: Imagen_
Que tiene que ver en ahorro de batería

[7:25 p. m.] **Vale 🌙:**
> _Tú: Ya despertaste o qué_
Me levanté ala 1 del medio día a eso de las tres salí ayude buscar lo de la decoración del cumple de Ema y el inflador

[7:25 p. m.] **Vale 🌙:**
> _Tú: Que_
Mi mamá se amaña aveses acá y se queda de mas

[7:33 p. m.] **Tú:** Tomate tu tiempo

[7:33 p. m.] **Tú:**
> _Vale 🌙: Que tiene que ver en ahorro de batería_
Que aveces molesta, como no le diste todos los permisos  a la aplicación  no lee bien eso

[7:33 p. m.] **Tú:** Cuando esta en modo ahorro

[7:34 p. m.] **Tú:** Cambialo

[7:34 p. m.] **Tú:** O que no afecte en la aplicación y ya tienes en modo ahorro activado

[7:34 p. m.] **Tú:**
> _Vale 🌙: Me levanté ala 1 del medio día a eso de las tres salí ayude buscar lo de la decoración del cumple de Ema y el inflador_
Que chevere

[7:34 p. m.] **Tú:** Y hasta donde te toco ir

[7:35 p. m.] **Vale 🌙:**
> _Tú: Cuando esta en modo ahorro_
Amor no sabía que eso afectaba la aplicación y yo lo mantengo en modo ahorro para que no se me descargue tan rápido

[8:06 p. m.] **Vale 🌙:**
> _Tú: Y hasta donde te toco ir_
Popular uno

[8:06 p. m.] **Vale 🌙:** Pero venimos en el carro

[9:36 p. m.] **Vale 🌙:** Ya vamos subiendo para la casa

[9:36 p. m.] **Vale 🌙:** Nos dieron coronas de recordatorio

[9:36 p. m.] **Tú:**
> _Vale 🌙: Ya vamos subiendo para la casa_
Dale bb

[9:36 p. m.] **Tú:** Cuido por ahí

[9:36 p. m.] **Tú:** Me avisas cuando llegues

[9:37 p. m.] **Tú:** [Imagen]

[9:37 p. m.] **Vale 🌙:** Mañana entro antes de medio día asta el sierre

[9:45 p. m.] **Vale 🌙:** Ya ellegur

[9:47 p. m.] **Vale 🌙:** [Imagen]

[9:56 p. m.] **Tú:**
> _Vale 🌙: Mañana entro antes de medio día asta el sierre_
Medio dia

[9:56 p. m.] **Tú:** Te toca

[9:56 p. m.] **Tú:** Bueno ya con eso te escribiré  cuando salgas

[9:56 p. m.] **Tú:**
> _Vale 🌙: Ya ellegur_
Como te fue

[9:57 p. m.] **Tú:**
> _Vale 🌙: Imagen_
Mi propia princesa

[9:58 p. m.] **Tú:** Esa va pa fondo

[10:00 p. m.] **Tú:**
> _Vale 🌙: Amor no sabía que eso afectaba la aplicación y yo lo mantengo en modo ahorro para que no se me descargue tan rápido_
Sii pues dale prioridades en los ajuste

[10:00 p. m.] **Tú:** Y cuando le pongas modo ahorro no afecta

[10:04 p. m.] **Tú:** [Imagen]

[10:04 p. m.] **Vale 🌙:**
> _Tú: Medio dia_
A las 11 ya estoy adentro

[10:05 p. m.] **Vale 🌙:**
> _Tú: Como te fue_
Bien amor leyendo en contrsto bien

[10:05 p. m.] **Vale 🌙:**
> _Tú: Y cuando le pongas modo ahorro no afecta_
A bueno amor ahora miro eso

[10:05 p. m.] **Vale 🌙:**
> _Tú: Imagen_
Awww te amo

[10:06 p. m.] **Tú:**
> _Vale 🌙: Bien amor leyendo en contrsto bien_
Estás que

[10:06 p. m.] **Tú:** Leyendo el contrato

[10:06 p. m.] **Tú:** Ya te dieron contrato

[10:06 p. m.] **Tú:** A término idefinifo

[10:06 p. m.] **Tú:**
> _Vale 🌙: A las 11 ya estoy adentro_
Bueno

[10:06 p. m.] **Tú:** Yo mañana salgo temprano

[10:06 p. m.] **Tú:** Y no voy a tener señal en todo el día

[10:07 p. m.] **Tú:**
> _Vale 🌙: A bueno amor ahora miro eso_
Bueno

[10:10 p. m.] **Vale 🌙:**
> _Tú: A término idefinifo_
No pues como si fuera temporada por ahora está asta diciembre

[11:07 p. m.] **Tú:**
> _Vale 🌙: No pues como si fuera temporada por ahora está asta diciembre_
Pero bueno

[11:07 p. m.] **Tú:** No importa

[11:08 p. m.] **Tú:** Tú a lo que vas

[11:08 p. m.] **Tú:** No te achuntes ni nada si dice eso

[11:08 p. m.] **Tú:** Igual si le metes moral para que te dejen el otro año

[11:08 p. m.] **Tú:** O me vienes a visitar en mi cumple

[11:08 p. m.] **Tú:** Jsjsjsj

[11:10 p. m.] **Vale 🌙:** Si amor

[11:11 p. m.] **Vale 🌙:** Pues igual yo necesito es trabajo asta diciembre para comprar la ropita y ir a verte jsjsj

[11:11 p. m.] **Tú:**
> _Vale 🌙: Pues igual yo necesito es trabajo asta diciembre para comprar la ropita y ir a verte jsjsj_
No necesitas ropa para verme

[11:11 p. m.] **Tú:** No te preocupes

[11:11 p. m.] **Tú:** Jajajajak

[11:12 p. m.] **Tú:** Pues voy a ver si en el pueblo me va bien

[11:12 p. m.] **Tú:** Y voy yo

[11:12 p. m.] **Tú:** Un tiempo y después vienes tú

[11:12 p. m.] **Tú:**
> _Vale 🌙: Pues igual yo necesito es trabajo asta diciembre para comprar la ropita y ir a verte jsjsj_
Qué bueno mi vida

[11:12 p. m.] **Tú:** Qué tal la nocge

[11:12 p. m.] **Tú:** Si le hago falta o que

[11:12 p. m.] **Tú:** Ya me rasca mano y no hay una boca sin dientes que me quiete el ardor

[11:13 p. m.] **Vale 🌙:** Obio que me haces falta eso de llegar del trabajo y no tener a quien ver jugar micraf y peliar con los amigos por llamada no está tan chévere

[11:13 p. m.] **Tú:** Pa que vea

[11:13 p. m.] **Tú:** Único y diferente

[11:13 p. m.] **Tú:** Cantante caciones gays

[11:13 p. m.] **Tú:** Y hablando como uno

[11:14 p. m.] **Tú:** Pero culeando como caballo

[11:14 p. m.] **Tú:** Porque mi mujer le gusta gritar

[11:14 p. m.] **Vale 🌙:** Que rico papi

[11:14 p. m.] **Tú:**
> _Vale 🌙: Que rico papi_
No digas eso, que mira lo que ocasionas

[11:15 p. m.] **Tú:** _Esperando el mensaje… Esto puede demorar un poco._

[11:15 p. m.] **Tú:** Y con tu pijama jajaj

[11:15 p. m.] **Vale 🌙:** Amor 😳

[11:15 p. m.] **Tú:** Ya para huélerte

[11:15 p. m.] **Tú:**
> _Vale 🌙: Amor 😳_
Mami tú sabes que si tú me dices algo rico yo me antojo

[11:16 p. m.] **Vale 🌙:** Hay amor tú también me antojas

[11:16 p. m.] **Vale 🌙:** Te extraño a ti y tu vergota

[11:16 p. m.] **Tú:**
> _Vale 🌙: Hay amor tú también me antojas_
Bueno vamos a desquitarnos un rato

[11:16 p. m.] **Tú:** Escoge video o audio

[11:16 p. m.] **Tú:** Pa empezar

[11:17 p. m.] **Vale 🌙:**
> _Tú: Bueno vamos a desquitarnos un rato_
Amor no

[11:17 p. m.] **Vale 🌙:** Mi hermana está al lado mío

[11:17 p. m.] **Tú:**
> _Vale 🌙: Te extraño a ti y tu vergota_
Esa tota ya hace falta sin el olor en mis dedos ya no es lo mismo dormir así

[11:17 p. m.] **Tú:** Se siente que no estoy donde debo de estar

[11:18 p. m.] **Tú:**
> _Vale 🌙: Mi hermana está al lado mío_
Eso no es problema tú dime cuando y te mando lo que quieras amor

[11:18 p. m.] **Tú:** Un buenas noches

[11:18 p. m.] **Tú:** Un video audios texto

[11:18 p. m.] **Tú:** Diciendo lo que quieres poemas brincando

[11:18 p. m.] **Tú:** Riendo con filtro tú me dirás

[11:19 p. m.] **Tú:** Ya tu imaginación verá hasta donde quiere llegar

[11:21 p. m.] **Tú:** Que quiere mi amor de buenas noches

[11:24 p. m.] **Vale 🌙:**
> _Tú: Riendo con filtro tú me dirás_
Te adoro mi amor me haces la mujer más feliz de la tierra

[11:24 p. m.] **Vale 🌙:**
> _Tú: Diciendo lo que quieres poemas brincando_
Si eso me gusta

[11:27 p. m.] **Tú:**
> _Vale 🌙: Te adoro mi amor me haces la mujer más feliz de la tierra_
Ahorita te lo mando

[11:27 p. m.] **Tú:** Lo quieres con ropa o desnudo

[11:27 p. m.] **Tú:** Jajajssk

[11:27 p. m.] **Tú:** [Sticker]

[11:37 p. m.] **Vale 🌙:** Hay jsjsj como quieras Mi amor asta en pijamas despeinado y sin cepillar me encantas

---

## 10 de septiembre de 2026

[12:05 a. m.] **Tú:** teengop algo mejor https://anhjs01.github.io/protectovl/

[12:05 a. m.] **Tú:** para que lo veas todos los dias amor mio

[12:07 a. m.] **Tú:** Me faltan detallitos

[6:40 a. m.] **Vale 🌙:** Te amo ami amor

[6:40 a. m.] **Vale 🌙:** Ahora lo veo

[8:01 a. m.] **Vale 🌙:**
> _Tú: teengop algo mejor https://anhjs01.github.io/protectovl/_
[Sticker]

[8:01 a. m.] **Vale 🌙:** Hay amor es lo más lindo que alguien a echo por mí te amo en este y todos los universos

[8:34 a. m.] **Vale 🌙:** [Video] Menos días

[5:56 p. m.] **Vale 🌙:**
> _Tú: https://corazon-galactico-dia-de-la-novia.netlify.app/_
Te iper mega adoro

[7:07 p. m.] **Tú:** Hola Mor

[7:07 p. m.] **Tú:** Cómo estás

[7:07 p. m.] **Tú:** Ando re cansando

[7:07 p. m.] **Tú:** Acabo de llegar a la casa

[9:01 p. m.] **Tú:** [Video]

[10:20 p. m.] **Tú:** Ya me bañé y me puse tu pijama

[10:20 p. m.] **Tú:** Estoy medio muerto pero me da

[10:20 p. m.] **Tú:** Hasta que llegues a la casa

[10:20 p. m.] **Tú:** Si algo hacemos llamada un ratico

[10:20 p. m.] **Tú:** O hablamos

[10:21 p. m.] **Tú:** [Mensaje de album]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Video]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Video]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Video]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Video]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Mensaje de unknown]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Video]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Mensaje de unknown]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Mensaje de unknown]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Mensaje de unknown]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Imagen]

[10:21 p. m.] **Tú:** [Mensaje de unknown]

[10:21 p. m.] **Tú:** [Mensaje de unknown]

[10:21 p. m.] **Tú:** [Mensaje de unknown]

[10:21 p. m.] **Tú:** [Mensaje de unknown]

[10:21 p. m.] **Tú:** [Mensaje de unknown]

[10:21 p. m.] **Tú:** [Mensaje de unknown]

[10:21 p. m.] **Tú:** [Mensaje de unknown]

[10:21 p. m.] **Tú:** [Mensaje de unknown]

[10:21 p. m.] **Tú:** [Mensaje de unknown]

[10:21 p. m.] **Tú:** [Mensaje de unknown]

[10:21 p. m.] **Tú:** [Mensaje de unknown]

[10:22 p. m.] **Tú:** [Mensaje de unknown]

[10:22 p. m.] **Tú:** [Mensaje de unknown]

[10:22 p. m.] **Tú:** [Mensaje de unknown]

[10:22 p. m.] **Tú:** [Mensaje de unknown]

[10:22 p. m.] **Tú:** [Mensaje de unknown]

[10:22 p. m.] **Tú:** [Mensaje de unknown]

[10:22 p. m.] **Tú:** [Mensaje de unknown]

[10:22 p. m.] **Tú:** [Mensaje de unknown]

[10:22 p. m.] **Tú:** [Mensaje de unknown]

[10:22 p. m.] **Tú:** [Mensaje de unknown]

[10:22 p. m.] **Tú:** [Mensaje de unknown]

[10:22 p. m.] **Tú:** [Mensaje de unknown]

[10:22 p. m.] **Tú:** [Mensaje de unknown]

[10:22 p. m.] **Tú:** [Mensaje de unknown]

[10:22 p. m.] **Tú:** [Mensaje de unknown]

[10:22 p. m.] **Tú:** [Mensaje de unknown]

[10:22 p. m.] **Tú:** [Mensaje de unknown]

[10:22 p. m.] **Tú:** [Mensaje de unknown]

[10:22 p. m.] **Tú:** [Mensaje de unknown]

[10:22 p. m.] **Tú:** [Mensaje de unknown]

[10:25 p. m.] **Tú:** [Mensaje de unknown]

[10:25 p. m.] **Tú:** [Mensaje de unknown]

[10:25 p. m.] **Tú:** [Mensaje de unknown]

[10:25 p. m.] **Tú:** [Mensaje de unknown]

[10:25 p. m.] **Tú:** [Mensaje de unknown]

[10:33 p. m.] **Tú:**
> _Vale 🌙: Imagen: No puedo explicar lo mucho que admiro el tiempo que se toma en amarme cada día 🥹_
Pa que vea eso era una parte del o que quería que habláramos igual me toca irlo actualizando con el tiempo para que tenga más cositas

[10:34 p. m.] **Tú:** Pero amo

[10:35 p. m.] **Tú:** Es un caledario de adviento se supone que debe de ser uno por día jajakaksks

[10:35 p. m.] **Tú:** Ya abriste dos
